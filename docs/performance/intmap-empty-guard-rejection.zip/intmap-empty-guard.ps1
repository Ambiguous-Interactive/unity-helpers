$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'intmap-empty-guard'
$destination = Join-Path $PSScriptRoot 'intmap-empty-guard-result'
$remote = '/tmp/uh-20261113b-intmap-empty-guard'
$container = '3aa9e4b2216a'
$code = 1
@{pid=$PID;startUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content(Join-Path $PSScriptRoot 'intmap-empty-guard-identity.json')
try {
    & docker exec $container test -e $remote
    if ($LASTEXITCODE -eq 0) { throw 'Owned remote path already exists; refusing overwrite' }
    & docker cp $source "${container}:$remote" *> (Join-Path $PSScriptRoot 'intmap-empty-guard-copy.log')
    if ($LASTEXITCODE -ne 0) { throw 'Could not copy the owned benchmark directory' }
    & docker exec $container python3 "$remote/measure.py" --runtime net10 --processes 2 *> (Join-Path $PSScriptRoot 'intmap-empty-guard-run.log')
    $code = $LASTEXITCODE

} finally {
    & docker cp "${container}:$remote" $destination *> (Join-Path $PSScriptRoot 'intmap-empty-guard-return.log')
    @{ exitCode=$code; captureCopyExit=$LASTEXITCODE } | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'intmap-empty-guard-controller.json')
}
exit $code
