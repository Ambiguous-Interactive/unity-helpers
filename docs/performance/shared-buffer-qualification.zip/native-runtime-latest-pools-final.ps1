$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113b-buffers'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
@{pid=$PID;startUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content(Join-Path $PSScriptRoot 'runtime-latest-pools-final-identity.json')
$inputs=@('Runtime/Utils/Buffers.cs','Runtime/Utils/RollingHighWaterMark.cs','Runtime/Utils/PoolPurgeSettings.cs','Tests/Runtime/Pool/GlobalPoolRegistryTests.cs','Tests/Runtime/Pool/WallstopGenericPoolTests.cs','Runtime/Core/Helper/LatestWriteFile.cs','Runtime/Core/Threading/SingleThreadedThreadPool.cs','Tests/Runtime/Helper/LatestWriteFileTests.cs','Tests/Runtime/Core/Threading/SingleThreadedThreadPoolExceptionTests.cs')
$before=@{};foreach($source in $inputs){$before[$source]=(Get-FileHash(Join-Path $repository $source)).Hash}
$code=1
try {
 $artifacts=Join-Path $PSScriptRoot 'runtime-latest-pools-final'
 & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime' -TestFilter 'WallstopStudios.UnityHelpers.Tests.Runtime.Pool;WallstopStudios.UnityHelpers.Tests.Helper.LatestWriteFileTests;WallstopStudios.UnityHelpers.Tests.Core.Threading.SingleThreadedThreadPool' -TestCategory '!Performance;!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot 'runtime-latest-pools-final-driver.log')
 if($LASTEXITCODE -ne 0){throw "Native tests failed $LASTEXITCODE"}
 [xml]$xml=Get-Content(Join-Path $artifacts 'results.xml') -Raw
 $cases=@($xml.SelectNodes('//test-case'))
 if($cases.Count -lt 300 -or @($cases|Where-Object result -eq 'Failed').Count -or @($xml.SelectNodes('//test-suite[@result="Failed"]')).Count){throw 'Missing or failing cases/suites'}
 $newWriterCases=@($cases|Where-Object fullname -match 'LatestWriteFileTests')
 $newExceptionCases=@($cases|Where-Object fullname -match 'SingleThreadedThreadPoolExceptionTests')
 if($newWriterCases.Count -ne 16 -or $newExceptionCases.Count -ne 9 -or @($newWriterCases|Where-Object result -ne 'Passed').Count -or @($newExceptionCases|Where-Object result -ne 'Passed').Count){throw 'Missing or failing new feature cases'}
 $receipt=Get-Content(Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw|ConvertFrom-Json
 if($receipt.Process.RawExitCode -ne 0 -or -not $receipt.Process.StandardOutputEndObserved -or -not $receipt.Process.StandardErrorEndObserved -or $receipt.Process.OutputDrainStopped){throw 'Unhealthy process receipt'}
 $after=@{};foreach($source in $inputs){$after[$source]=(Get-FileHash(Join-Path $repository $source)).Hash;if($after[$source] -ne $before[$source]){throw 'Input source changed'}}
 $code=0
} catch { $_|Out-String|Set-Content(Join-Path $PSScriptRoot 'runtime-latest-pools-final-controller.log') }
finally { @{exitCode=$code;before=$before;after=$after;caseCount=$cases.Count;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json -Depth 6|Set-Content(Join-Path $PSScriptRoot 'runtime-latest-pools-final-result.json') }
exit $code
