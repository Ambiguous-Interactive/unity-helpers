$ErrorActionPreference='Stop'
$repository=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project=Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113b-buffers'
$pwsh=Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
@{pid=$PID;startUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content(Join-Path $PSScriptRoot 'paired-shared-identity.json')
$paths=@('Runtime/Utils/Buffers.cs','Runtime/Utils/RollingHighWaterMark.cs')
$fixed=@('Runtime/Utils/PoolPurgeSettings.cs','Runtime/Utils/LocalPool.cs','Runtime/Utils/ThreadLocalArrayPool.cs','Runtime/Utils/DisposalLease.cs','Tests/Runtime/Performance/LocalPoolPerformanceTests.cs','Tests/Runtime/Pool/GlobalPoolRegistryTests.cs','Tests/Runtime/Pool/WallstopGenericPoolTests.cs')
$fixedHashes=@{};foreach($source in $fixed){$fixedHashes[$source]=(Get-FileHash(Join-Path $repository $source)).Hash}
$records=@();$code=1
try {
 $sequence=@('baseline','candidate','candidate','baseline','baseline','candidate')
 for($index=0;$index -lt $sequence.Count;$index++) {
  $variant=$sequence[$index];$number=$index+1
  foreach($source in $paths){
   $stem=[IO.Path]::GetFileNameWithoutExtension($source)
   $suffix=if($variant -eq 'baseline'){'baseline.cs.txt'}else{'candidate2-final.cs.txt'}
   [IO.File]::WriteAllBytes((Join-Path $repository $source),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "$stem.$suffix")))
  }
  $before=@{};foreach($source in ($paths+$fixed)){$before[$source]=(Get-FileHash(Join-Path $repository $source)).Hash;if($fixed -contains $source -and $before[$source] -ne $fixedHashes[$source]){throw "Fixed source changed: $source"}}
  $artifacts=Join-Path $PSScriptRoot "shared-paired-$number-$variant"
  & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime;WallstopStudios.UnityHelpers.Tests.Runtime.Performance' -TestFilter 'WallstopStudios.UnityHelpers.Tests.Utils.LocalPoolTests;WallstopStudios.UnityHelpers.Tests.Utils.ThreadLocalArrayPoolTests;WallstopStudios.UnityHelpers.Tests.Runtime.Performance.LocalPoolPerformanceTests' -TestCategory '!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot "shared-paired-$number-$variant-driver.log")
  if($LASTEXITCODE -ne 0){throw "Native paired command failed: $number/$variant exit $LASTEXITCODE"}
  [xml]$xml=Get-Content(Join-Path $artifacts 'results.xml') -Raw
  $cases=@($xml.SelectNodes('//test-case'))
  if($cases.Count -ne 33 -or @($cases|Where-Object result -ne 'Passed').Count -or @($xml.SelectNodes('//test-suite[@result="Failed"]')).Count){throw 'Missing or failing case/suite'}
  $receipt=Get-Content(Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw|ConvertFrom-Json
  $healthy=$receipt.Process.RawExitCode -eq 0 -and $receipt.Process.StandardOutputEndObserved -and $receipt.Process.StandardErrorEndObserved -and -not $receipt.Process.OutputDrainStopped
  if(-not $healthy){throw 'Unhealthy process/output receipt'}
  $text=Get-Content(Join-Path $artifacts 'results.xml') -Raw
  $rows=@([regex]::Matches($text,'LOCALPOOL,\d+,[A-Za-z]+,\d+,[0-9.Ee+-]+,[0-9.Ee+-]+'))
  if($rows.Count -ne 147){throw 'Expected 147 timing rows'}
  $module=[regex]::Match($text,'LOCALPOOL_MODULE,([0-9a-f-]{36})').Groups[1].Value
  $dll=Join-Path $project 'Library/ScriptAssemblies/WallstopStudios.UnityHelpers.dll'
  $stream=[IO.File]::OpenRead($dll)
  try {
   $pe=[Reflection.PortableExecutable.PEReader]::new($stream)
   try {$metadata=[Reflection.Metadata.PEReaderExtensions]::GetMetadataReader($pe);$built=$metadata.GetGuid($metadata.GetModuleDefinition().Mvid).ToString()}finally{$pe.Dispose()}
  }finally{$stream.Dispose()}
  if($module -cne $built){throw 'Loaded runtime MVID differs from captured DLL'}
  Copy-Item $dll (Join-Path $artifacts 'qualified-runtime.dll')
  $after=@{};foreach($source in ($paths+$fixed)){$after[$source]=(Get-FileHash(Join-Path $repository $source)).Hash;if($after[$source] -ne $before[$source]){throw "Source changed during capture: $source"}}
  $records+=@{index=$number;variant=$variant;cases=$cases.Count;rows=@($rows|ForEach-Object Value);healthy=$healthy;module=$module;dllSha256=(Get-FileHash $dll).Hash;before=$before;after=$after}
  $records|ConvertTo-Json -Depth 8|Set-Content(Join-Path $PSScriptRoot 'paired-shared-live.json')
 }
 $code=0
}catch{$_|Out-String|Set-Content(Join-Path $PSScriptRoot 'paired-shared-controller.log')}
finally{
 foreach($source in $paths){$stem=[IO.Path]::GetFileNameWithoutExtension($source);[IO.File]::WriteAllBytes((Join-Path $repository $source),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "$stem.candidate2-final.cs.txt")))}
 @{exitCode=$code;records=$records;fixedHashes=$fixedHashes;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json -Depth 8|Set-Content(Join-Path $PSScriptRoot 'paired-shared-result.json')
}
exit $code
