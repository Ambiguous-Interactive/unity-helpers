$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'intmap-inline-serial'
$destination = Join-Path $PSScriptRoot 'intmap-inline-serial-result'
$remote = '/tmp/uh-20261112c-intmap-inline-serial'
$container = '3aa9e4b2216a'
$code = 1
try {
    & docker exec $container test -e $remote
    if ($LASTEXITCODE -eq 0) { throw 'Owned remote path already exists; refusing overwrite' }
    & docker cp $source "${container}:$remote" *> (Join-Path $PSScriptRoot 'intmap-inline-serial-copy.log')
    if ($LASTEXITCODE -ne 0) { throw 'Could not copy the owned benchmark directory' }
    & docker exec $container python3 "$remote/measure.py" --runtime net10 --processes 3 *> (Join-Path $PSScriptRoot 'intmap-inline-serial-run.log')
    $code = $LASTEXITCODE
    if ($code -eq 0) {
        & docker exec $container python3 "$remote/measure.py" --runtime mono --processes 3 --reuse-build *> (Join-Path $PSScriptRoot 'intmap-inline-serial-mono.log')
        $code = $LASTEXITCODE
    }
} finally {
    & docker cp "${container}:$remote" $destination *> (Join-Path $PSScriptRoot 'intmap-inline-serial-return.log')
    @{ exitCode=$code; captureCopyExit=$LASTEXITCODE } | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'intmap-inline-serial-controller.json')
}
exit $code
