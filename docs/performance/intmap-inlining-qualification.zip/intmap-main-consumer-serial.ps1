$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'intmap-main-consumer-serial'
$destination = Join-Path $PSScriptRoot 'intmap-main-consumer-serial-result'
$remote = '/tmp/uh-20261112c-intmap-main-consumer-serial'
$container = '3aa9e4b2216a'
$code = 1
try {
    & docker exec $container test -e $remote
    if ($LASTEXITCODE -eq 0) { throw 'Owned remote path already exists; refusing overwrite' }
    & docker cp $source "${container}:$remote" *> (Join-Path $PSScriptRoot 'intmap-main-consumer-serial-copy.log')
    if ($LASTEXITCODE -ne 0) { throw 'Could not copy the owned benchmark directory' }
    & docker exec $container python3 "$remote/run.py" *> (Join-Path $PSScriptRoot 'intmap-main-consumer-serial-run.log')
    $code = $LASTEXITCODE
} finally {
    & docker cp "${container}:$remote" $destination *> (Join-Path $PSScriptRoot 'intmap-main-consumer-serial-return.log')
    @{ exitCode=$code; captureCopyExit=$LASTEXITCODE } | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'intmap-main-consumer-serial-controller.json')
}
exit $code
