using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;

internal static class Program
{
    private const int Rounds = 21;
    private const int TargetOps = 1 << 20;
    private const int ChurnOps = 1_000_000;
    private static long _sink;

    private static Dictionary<int, int> BuildDictionary(int[] keys)
    {
        Dictionary<int, int> map = new Dictionary<int, int>();
        for (int i = 0; i < keys.Length; i++) { map[keys[i]] = i + 1; }
        return map;
    }

    private static double HitDictionary(Dictionary<int, int> map, int[] keys, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            for (int i = 0; i < keys.Length; i++)
            {
                if (map.TryGetValue(keys[i], out int v)) { sum += v; }
            }
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * keys.Length);
    }

    private static double InsertDictionary(int[] keys, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            Dictionary<int, int> map = new Dictionary<int, int>();
            for (int i = 0; i < keys.Length; i++) { map[keys[i]] = i; }
            sum += map.Count;
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * keys.Length);
    }

    private static double IterateDictionary(Dictionary<int, int> map, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            foreach (KeyValuePair<int, int> pair in map) {{ sum += pair.Value; }}
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * map.Count);
    }

    private static double ChurnDictionary(out int capacity)
    {
        Dictionary<int, int> map = new Dictionary<int, int>();
        for (int k = 0; k < 8; k++) { map[k] = k; }
        Stopwatch watch = Stopwatch.StartNew();
        for (int k = 0; k < ChurnOps; k++)
        {
            map.Remove(k);
            map[k + 8] = k;
        }
        watch.Stop();
        _sink += map.Count;
        capacity = -1;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ChurnOps;
    }

    private static OldIntMap.IntMap<int> BuildIntMap371Baseline(int[] keys)
    {
        OldIntMap.IntMap<int> map = new OldIntMap.IntMap<int>();
        for (int i = 0; i < keys.Length; i++) { map.TrySet(keys[i], i + 1); }
        return map;
    }

    private static double HitIntMap371Baseline(OldIntMap.IntMap<int> map, int[] keys, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            for (int i = 0; i < keys.Length; i++)
            {
                if (map.TryGet(keys[i], out int v)) { sum += v; }
            }
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * keys.Length);
    }

    private static double InsertIntMap371Baseline(int[] keys, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            OldIntMap.IntMap<int> map = new OldIntMap.IntMap<int>();
            for (int i = 0; i < keys.Length; i++) { map.TrySet(keys[i], i); }
            sum += map.Count;
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * keys.Length);
    }

    private static double IterateIntMap371Baseline(OldIntMap.IntMap<int> map, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            foreach (KeyValuePair<int, int> pair in map) {{ sum += pair.Value; }}
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * map.Count);
    }

    private static double ChurnIntMap371Baseline(out int capacity)
    {
        OldIntMap.IntMap<int> map = new OldIntMap.IntMap<int>();
        for (int k = 0; k < 8; k++) { map.TrySet(k, k); }
        Stopwatch watch = Stopwatch.StartNew();
        for (int k = 0; k < ChurnOps; k++)
        {
            map.Remove(k, out _);
            map.TrySet(k + 8, k);
        }
        watch.Stop();
        _sink += map.Count;
        capacity = map.Capacity;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ChurnOps;
    }

    private static WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> BuildIntMapCurrent(int[] keys)
    {
        WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> map = new WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int>();
        for (int i = 0; i < keys.Length; i++) { map.TrySet(keys[i], i + 1); }
        return map;
    }

    private static double HitIntMapCurrent(WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> map, int[] keys, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            for (int i = 0; i < keys.Length; i++)
            {
                if (map.TryGet(keys[i], out int v)) { sum += v; }
            }
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * keys.Length);
    }

    private static double InsertIntMapCurrent(int[] keys, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> map = new WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int>();
            for (int i = 0; i < keys.Length; i++) { map.TrySet(keys[i], i); }
            sum += map.Count;
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * keys.Length);
    }

    private static double IterateIntMapCurrent(WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> map, int repeats)
    {
        long sum = 0;
        Stopwatch watch = Stopwatch.StartNew();
        for (int r = 0; r < repeats; r++)
        {
            foreach (KeyValuePair<int, int> pair in map) {{ sum += pair.Value; }}
        }
        watch.Stop();
        _sink += sum;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ((long)repeats * map.Count);
    }

    private static double ChurnIntMapCurrent(out int capacity)
    {
        WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> map = new WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int>();
        for (int k = 0; k < 8; k++) { map.TrySet(k, k); }
        Stopwatch watch = Stopwatch.StartNew();
        for (int k = 0; k < ChurnOps; k++)
        {
            map.Remove(k, out _);
            map.TrySet(k + 8, k);
        }
        watch.Stop();
        _sink += map.Count;
        capacity = map.Capacity;
        return watch.Elapsed.TotalMilliseconds * 1e6 / ChurnOps;
    }

    private static int[] Keys(string shape, int size, bool miss)
    {
        switch (shape)
        {
            case "dense":
                return Enumerable.Range(miss ? size : 0, size).ToArray();
            case "shift1024":
                return Enumerable.Range(0, size).Select(i => i * 1024 + (miss ? 512 : 0)).ToArray();
            case "sparse":
            {
                Random random = new Random(12345);
                HashSet<int> seen = new HashSet<int>();
                List<int> hits = new List<int>();
                while (hits.Count < size) { int k = random.Next(); if (seen.Add(k)) { hits.Add(k); } }
                if (!miss) { return hits.ToArray(); }
                List<int> misses = new List<int>();
                while (misses.Count < size) { int k = random.Next(); if (seen.Add(k)) { misses.Add(k); } }
                return misses.ToArray();
            }
            default:
                throw new ArgumentException(shape);
        }
    }

    private static void Main(string[] args)
    {
        string runtime = args.Length > 0 ? args[0] : "unknown";
        string[] arms = { "Dictionary", "IntMap371Baseline", "IntMapCurrent" };
        string[] shapes = { "dense", "sparse", "shift1024" };
        int[] sizes = { 8, 64, 1024 };
        string[] ops = { "hit", "miss", "insert", "iterate" };
        foreach (string shape in shapes)
        foreach (int size in sizes)
        {
            int[] keys = Keys(shape, size, false);
            int[] missKeys = Keys(shape, size, true);
            var mapDictionary = BuildDictionary(keys);
            var mapIntMap371Baseline = BuildIntMap371Baseline(keys);
            var mapIntMapCurrent = BuildIntMapCurrent(keys);
            int repeats = Math.Max(1, TargetOps / size);
            int insertRepeats = Math.Max(1, (TargetOps / 4) / size);
            foreach (string op in ops)
            {
                Dictionary<string, List<double>> samples = arms.ToDictionary(a => a, a => new List<double>());
                for (int round = -1; round < Rounds; round++)
                {
                    for (int j = 0; j < arms.Length; j++)
                    {
                        string arm = arms[(j + Math.Max(round, 0)) % arms.Length];
                        double ns = Run(arm, op, keys, missKeys, repeats, insertRepeats, mapDictionary, mapIntMap371Baseline, mapIntMapCurrent);
                        if (round >= 0) { samples[arm].Add(ns); }
                    }
                }
                foreach (string arm in arms) { Report(runtime, shape, size, op, arm, samples[arm], -1); }
            }
        }
        Dictionary<string, List<double>> churn = arms.ToDictionary(a => a, a => new List<double>());
        Dictionary<string, int> capacity = new Dictionary<string, int>();
        for (int round = -1; round < Rounds; round++)
        {
            for (int j = 0; j < arms.Length; j++)
            {
                string arm = arms[(j + Math.Max(round, 0)) % arms.Length];
                int cap;
                double ns = arm == "Dictionary" ? ChurnDictionary(out cap) : arm == "IntMap371Baseline" ? ChurnIntMap371Baseline(out cap) : ChurnIntMapCurrent(out cap);
                if (round >= 0) { churn[arm].Add(ns); capacity[arm] = cap; }
            }
        }
        foreach (string arm in arms) { Report(runtime, "churn8", 8, "churn", arm, churn[arm], capacity[arm]); }
        Console.Error.WriteLine(_sink);
    }

    private static double Run(string arm, string op, int[] keys, int[] missKeys, int repeats, int insertRepeats, Dictionary<int, int> mapDictionary, OldIntMap.IntMap<int> mapIntMap371Baseline, WallstopStudios.UnityHelpers.Core.DataStructure.IntMap<int> mapIntMapCurrent)
    {
        switch (arm + ":" + op)
        {
            case "Dictionary:hit": return HitDictionary(mapDictionary, keys, repeats);
            case "Dictionary:miss": return HitDictionary(mapDictionary, missKeys, repeats);
            case "Dictionary:insert": return InsertDictionary(keys, insertRepeats);
            case "Dictionary:iterate": return IterateDictionary(mapDictionary, repeats);
            case "IntMap371Baseline:hit": return HitIntMap371Baseline(mapIntMap371Baseline, keys, repeats);
            case "IntMap371Baseline:miss": return HitIntMap371Baseline(mapIntMap371Baseline, missKeys, repeats);
            case "IntMap371Baseline:insert": return InsertIntMap371Baseline(keys, insertRepeats);
            case "IntMap371Baseline:iterate": return IterateIntMap371Baseline(mapIntMap371Baseline, repeats);
            case "IntMapCurrent:hit": return HitIntMapCurrent(mapIntMapCurrent, keys, repeats);
            case "IntMapCurrent:miss": return HitIntMapCurrent(mapIntMapCurrent, missKeys, repeats);
            case "IntMapCurrent:insert": return InsertIntMapCurrent(keys, insertRepeats);
            case "IntMapCurrent:iterate": return IterateIntMapCurrent(mapIntMapCurrent, repeats);
            default: throw new ArgumentException(arm + op);
        }
    }

    private static void Report(string runtime, string shape, int size, string op, string arm, List<double> samples, int capacity)
    {
        samples.Sort();
        double min = samples[0];
        double median = samples[samples.Count / 2];
        Console.WriteLine(string.Format(CultureInfo.InvariantCulture,
            "{{\"runtime\":\"{0}\",\"shape\":\"{1}\",\"size\":{2},\"op\":\"{3}\",\"arm\":\"{4}\",\"min\":{5:F3},\"median\":{6:F3},\"capacity\":{7}}}",
            runtime, shape, size, op, arm, min, median, capacity));
    }
}
