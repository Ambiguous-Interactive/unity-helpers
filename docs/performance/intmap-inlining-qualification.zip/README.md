# IntMap inlining qualification

The hint is rejected and IntMap is unchanged. qualification-preregistration.md records the thresholds before the serial captures. qualification-analysis.json retains all expanded cell ratios and the failed retention decision. intmap-main-consumer-analysis.json evaluates restored main against the original consumer budgets without the hint.

The three result directories contain independent source/project/global.json inputs, raw row outputs, retained expanded per-round stderr samples, process receipts and payload hashes. The expanded 195-cell campaigns use64warm calls, >=20ms calibration and21rotated rounds in three processes/runtime. Churn retains summary/capacity results. The recovered consumer harness deliberately retains its original warmup/loop/sampling policy and111cells per process, so it is separate from the calibrated expanded corpus.

Replay in a new owned directory with new labels. Build the projects in Release with the recorded SDK and invoke measure.py for the expanded corpus (net10 then mono) or run.py for each original-consumer corpus. Preserve the sealed source/payload identities and do not overwrite these observations. Read the PowerShell controllers for the original Docker invocation. The host runtime versions and allowlisted runtime options are included; no CPU affinity or priority override was used. These are host observations, not Unity/player qualification.

The initial overlapping exploratory campaign is excluded from the retention decision and kept in local raw artifacts. All published serial processes have complete nonzero row sets, zero exits, stable source/payload hashes and both output stream ends. Main's original-budget failures stay open on issue1131.
