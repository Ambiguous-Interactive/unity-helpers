$ErrorActionPreference='Stop'
$container='3aa9e4b2216a'
& docker exec -w '/tmp/uh-20261112c-intmap-inline-serial' $container dotnet --info *> (Join-Path $PSScriptRoot 'intmap-host-dotnet-info.log')
if ($LASTEXITCODE -ne 0) { throw 'Could not capture owned .NET environment.' }
& docker exec $container mono --version *> (Join-Path $PSScriptRoot 'intmap-host-mono-info.log')
if ($LASTEXITCODE -ne 0) { throw 'Could not capture owned Mono environment.' }
& docker exec $container uname -a *> (Join-Path $PSScriptRoot 'intmap-host-kernel.log')
& docker exec $container python3 -c 'import os,json; print(json.dumps({k:os.environ.get(k) for k in ["DOTNET_TieredPGO","DOTNET_TieredCompilation","COMPlus_TieredPGO","MONO_ENV_OPTIONS"]}))' *> (Join-Path $PSScriptRoot 'intmap-host-runtime-options.json')
if ($LASTEXITCODE -ne 0) { throw 'Could not capture runtime option allowlist.' }
@{completedUtc=[DateTime]::UtcNow} | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'intmap-host-environment-result.json')
