namespace WallstopStudios.UnityHelpers.Core.Helper
{
    public static class Objects
    {
        public static int HashCode<T1>(T1 a) => a == null ? 0 : a.GetHashCode();
        public static int HashCode<T1, T2>(T1 a, T2 b) => HashCode(a) * 31 + HashCode(b);
        public static int HashCode<T1, T2, T3>(T1 a, T2 b, T3 c) => HashCode(a, b) * 31 + HashCode(c);
        public static int HashCode<T1, T2, T3, T4>(T1 a, T2 b, T3 c, T4 d) => HashCode(a, b, c) * 31 + HashCode(d);
    }
}
