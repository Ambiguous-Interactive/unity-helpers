Sprite atlas qualification probes, 2026-11-09.

Unity 6000.6.7f1, Windows x64, SpriteAtlas V2, StandaloneWindows64, readable uncompressed RGBA32, FullRect source sprites, tight packing off, rotation on, padding zero and 64-pixel maximum pages.

The first run uses the two-sprite source (RotationAtlasProbe-two.cs.probe) and rotation-probe.ps1. Six orthogonal shape pairs yield 12 packed Rectangle sprites with None rotation. The second run reuses only that owned temporary project, copies RotationAtlasProbe.cs.probe, and runs rotation-probe-three.ps1. Its six three-sprite groups yield 18 packed Rectangle sprites with None rotation. Both runs compare every extracted unrotated pixel with an independently generated source gradient, without resetting import settings to fabricate rotation.

Both editors exit zero and reach both output stream ends. Unity emits temporary-allocator and thread-abort teardown warnings; those remain in the logs. No actual rotated sprite was observed, so neither run qualifies issue #1135 or closes the SpriteArtBounds portion of #1113. The packer chooses separate pages even when a rotated arrangement would use one page. Do not repeat these shapes as a claimed positive rotation fixture.

The same fresh editor explicitly refreshes the package after a strict documentation build. The generated .artifacts/site contains a deployable index and 75 HTML files; no generated documentation path enters AssetDatabase. All 4,061 source metadata files captured before this build keep identical bytes after refresh. The local scripts derive their repository location; run only in an owned scratch editor project, never in a consumer project.
