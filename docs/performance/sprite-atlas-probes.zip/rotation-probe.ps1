$ErrorActionPreference='Stop'
$repository=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$base=Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261108'
$project=Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261109-pm-rotation'
if(Test-Path $project){throw 'The owned rotation project already exists; inspect it before reusing.'}
New-Item -ItemType Directory -Path (Join-Path $project 'Assets/Editor') -Force|Out-Null
New-Item -ItemType Directory -Path (Join-Path $project 'Packages') -Force|Out-Null
Copy-Item (Join-Path $base 'ProjectSettings') (Join-Path $project 'ProjectSettings') -Recurse
foreach($file in @('manifest.json','packages-lock.json')){Copy-Item (Join-Path $base ('Packages/'+$file)) (Join-Path $project ('Packages/'+$file))}
Copy-Item (Join-Path $PSScriptRoot 'RotationAtlasProbe.cs.probe') (Join-Path $project 'Assets/Editor/RotationAtlasProbe.cs')
$start=[Diagnostics.ProcessStartInfo]::new();$start.FileName='C:/Program Files/Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe'
$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
foreach($argument in @('-batchmode','-nographics','-projectPath',$project,'-executeMethod','SessionRotationQualification.RotationAtlasProbe.Run','-probeOutput',(Join-Path $PSScriptRoot 'rotation-probe-results.txt'),'-logFile',(Join-Path $PSScriptRoot 'rotation-probe-unity.log'),'-quit')){$start.ArgumentList.Add($argument)}
$launch=[DateTime]::UtcNow.ToString('o');$process=[Diagnostics.Process]::Start($start)
$stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync();$killed=$false
if(-not $process.WaitForExit(600000)){$killed=$true;$process.Kill($true);$process.WaitForExit()}
$stdout.Result|Set-Content (Join-Path $PSScriptRoot 'rotation-probe-stdout.log');$stderr.Result|Set-Content (Join-Path $PSScriptRoot 'rotation-probe-stderr.log')
@{LaunchUtc=$launch;EndUtc=[DateTime]::UtcNow.ToString('o');PID=$process.Id;ExitCode=$process.ExitCode;Killed=$killed;StdoutCompleted=$stdout.IsCompletedSuccessfully;StderrCompleted=$stderr.IsCompletedSuccessfully;Project=$project}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'rotation-probe-receipt.json')
exit $process.ExitCode
