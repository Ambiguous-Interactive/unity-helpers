# IntMap consumer harness evidence

Recovered from the DoxReloaded devcontainer's retained session-419 scratch directory on 2026-11-09. Original Program.cs SHA256: 1cee6c46c3ba3e451b97447067beb5725d02302dc2a9b84998a9d9c7c54194eb. Original results are historical captures; their parent exit/stream receipts were not retained here.

The replay preserves the original round schedule, operations, distributions, sizes and Objects hash shim. It substitutes original IntMapNew.cs (3.7.1) for the old arm, changing only its namespace to OldIntMap; current main ef48a1a94489f7474d3a651de3d90d2d8fe1e12b is the new arm. Program.cs changes only arm/method labels. No production IntMap change is made in this session.

Run replay/run.py with Python 3, SDK 10.0.403 and Mono 6.14.1 installed. It builds both Release targets, checks source and payload hashes before/after each process, captures both streams through EOF, requires exit zero and all 111 summaries, and retains all six observations. Replayed on Linux x64 in the existing DoxReloaded devcontainer. No CPU affinity or priority override. Default runtime settings; no explicit PGO environment override.

The original harness reports only each process's median and minimum, not individual round samples. It uses one warm-up and 21 rotating-order rounds, 1,048,576 target lookup/iteration operations (a quarter as many inserts), and 1,000,000 churn steps. Each process emits the same sink 228327948816. This sink is not a replacement for independent correctness tests.

The recovered protocol qualifies the named acceptance comparison only. It does not prove universal performance, Unity player behavior, or a 10% lookup/insertion bound: several cells exceed that bound. Issue #1131 remains open.
