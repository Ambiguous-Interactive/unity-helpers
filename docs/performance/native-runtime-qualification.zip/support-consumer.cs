namespace ConsumerVerification
{
    using System;
    using NUnit.Framework;
    using UnityEngine;
    using WallstopStudios.UnityHelpers.TestSupport;

    public sealed class SupportConsumerTests : UnityObjectTrackingTestBase
    {
        private static byte[] _sink;

        [Test]
        public void InheritedScopeTracksObjects()
        {
            GameObject first = Track(new GameObject(nameof(first)));
            GameObject second = new GameObject(nameof(second));
            TrackRange(new[] { second });
            EndObjectTrackingScope();
            Assert.IsTrue(first == null);
            Assert.IsTrue(second == null);
        }

        [Test]
        public void PublicProfilerCounterSeesRetainedControl()
        {
            Action allocate = () => _sink = new byte[32];
            Assert.That(ProfilerAllocationCounter.Measure(allocate, 8, 64, 2), Is.GreaterThan(0));
            Assert.That(_sink.Length, Is.EqualTo(32));
            Assert.That(ProfilerAllocationCounter.Measure(() => {}, 8, 64, 2), Is.Zero);
        }

        [Test]
        public void PublicAllocationProbeRunsItsControl()
        {
            Assert.That(AllocationProbe.Iterations, Is.GreaterThan(0));
            AllocationProbe.IgnoreWhenUnmeasurable();
            Assert.IsTrue(AllocationProbe.RecorderCanSeeAnAllocation());
        }
    }
}
