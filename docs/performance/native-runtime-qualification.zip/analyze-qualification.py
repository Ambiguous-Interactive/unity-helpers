import json,math,statistics,uuid,xml.etree.ElementTree as E
from pathlib import Path
root=Path(__file__).resolve().parent
out={}
editor=root/'editor-sync-support-paired-result.json'
if editor.exists():
 j=json.loads(editor.read_text()); rows=j['results']; assert len(rows)==6 and all(r['healthy'] and r['complete'] and r['cases']==113 for r in rows)
 names=[r['name'] for r in rows[0]['fixtures'] if not r['name'].endswith('.SynchronousEditorTestBaseTests')]
 assert len(names)==4
 result=[]; identities=None
 for r in rows:
  tree=E.parse(root/f"editor-sync-support-{r['arm']}-{r['index']}"/'results.xml'); cases=sorted(c.attrib['fullname'] for c in tree.findall('.//test-case'))
  if identities is None:identities=cases
  assert cases==identities
 for name in [*names,'sum106']:
  values={}
  for arm in ['baseline','candidate']:
   values[arm]=[sum(float(f['duration']) for f in r['fixtures'] if f['name'] in names and (name=='sum106' or f['name']==name)) for r in sorted(rows,key=lambda r:r['index']) if r['arm']==arm]
  ratios=[b/a for a,b in zip(values['baseline'],values['candidate'])]
  result.append({'fixture':name,'seconds':values,'baselineMedian':statistics.median(values['baseline']),'candidateMedian':statistics.median(values['candidate']),'pairedRatios':ratios})
 out['editor']=result
sprite=root/'sprite-rgb-serial-paired-result.json'
if sprite.exists():
 j=json.loads(sprite.read_text()); rows=j['results']; assert len(rows)==6 and all(r['healthy'] and r['complete'] and r['cases']==12 for r in rows)
 cells={};loaded_by_arm={}
 for row in rows:
  tree=E.parse(root/f"sprite-rgb-serial-{row['arm']}-{row['index']}"/'results.xml')
  for case in tree.findall('.//test-case'):
   lines=case.findtext('output').splitlines(); header=next(line for line in lines if line.startswith('SPRITE_REGION|')); parts=header.split('|');key=(parts[5],int(parts[1]),int(parts[2]),parts[3]);assert sum(line.startswith('SPRITE_REGION_ID|') for line in lines)==1
   loaded=next(line.split('|',1)[1] for line in lines if line.startswith('SPRITE_REGION_ID|'));uuid.UUID(loaded);loaded_by_arm.setdefault(row['arm'],set()).add(loaded)
   start=lines.index(header)+1;samples=[float(v) for v in lines[start:start+21]];assert len(samples)==21 and all(0<v and math.isfinite(v) for v in samples);assert all(not v.strip() or v.startswith('Saving results to:') for v in lines[start+21:])
   cells.setdefault(key,{})[(row['arm'],row['index'])]=statistics.median(samples)
 result=[]
 for key,vals in sorted(cells.items()):
  a=[vals['baseline',i] for i in [1,2,3]];b=[vals['candidate',i] for i in [1,2,3]];ratios=[y/x for x,y in zip(a,b)];result.append({'format':key[0],'texture':key[1],'region':key[2],'bounds':key[3],'baselineNs':a,'candidateNs':b,'baselineMedianNs':statistics.median(a),'candidateMedianNs':statistics.median(b),'pairedRatios':ratios})
 assert len(result)==12
 assert len(loaded_by_arm['baseline'])==1 and len(loaded_by_arm['candidate'])==1 and loaded_by_arm['baseline'].isdisjoint(loaded_by_arm['candidate'])
 out['sprite']=result
intmap=root/'intmap-inline-serial-result'
if (root/'intmap-inline-serial-controller.json').exists():
 controller=json.loads((root/'intmap-inline-serial-controller.json').read_text()); assert controller['exitCode']==0 and controller['captureCopyExit']==0
 result=[];runtime_means={}
 for runtime in ['net10','mono']:
  perprocess=[]; cells={}
  for i in [1,2,3]:
   receipt=json.loads((intmap/f'{runtime}-{i}.receipt.json').read_text());assert receipt['exit']==0 and receipt['rows']==195 and receipt['distinct']==195 and all(receipt[k] for k in ['stdout_eof','stderr_eof','sources_stable','payloads_stable'])
   rows=[json.loads(line) for line in (intmap/f'{runtime}-{i}.stdout.jsonl').read_text().splitlines()];assert len(rows)==195
   indexed={(r['shape'],r['size'],r['op'],r['arm']):r for r in rows}
   ratios=[]
   for row in rows:
    if row['arm']!='IntMapCurrent':continue
    key=(row['shape'],row['size'],row['op']);baseline=indexed[(*key,'IntMapMain')];ratio=row['median']/baseline['median'];cells.setdefault(key,[]).append(ratio)
    if row['op']=='insert':ratios.append(ratio)
   perprocess.append(math.exp(statistics.mean(math.log(x) for x in ratios)))
  mean=math.exp(statistics.mean(math.log(x) for x in perprocess));runtime_means[runtime]=mean
  for key,ratios in sorted(cells.items()):result.append({'runtime':runtime,'shape':key[0],'size':key[1],'op':key[2],'pairedProcessRatios':ratios,'medianRatio':statistics.median(ratios)})
 aggregate=math.exp(statistics.mean(math.log(x) for x in runtime_means.values()))
 regressions=[r for r in result if r['op'] in ['hit','miss','iterate','create'] and r['medianRatio']>1.10]
 out['intmap']={'cells':result,'runtimeInsertionGeomeans':runtime_means,'equalRuntimeInsertionGeomean':aggregate,'noninsertRegressions':regressions,'retain':aggregate<=.95 and all(x<1 for x in runtime_means.values()) and not regressions}
(root/'qualification-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k: v if k=='intmap' else len(v) for k,v in out.items()},indent=2))
