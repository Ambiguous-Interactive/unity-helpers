$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261112c-editor'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$variants = @(Get-Content (Join-Path $PSScriptRoot 'editor-sync-variants.json') -Raw | ConvertFrom-Json)
$otherSources = @('Runtime/TestSupport/UnityObjectTrackingTestBase.cs','Runtime/TestSupport/AllocationProbe.cs','Runtime/TestSupport/ProfilerAllocationCounter.cs','Tests/Core/CommonTestBase.cs','Tests/Core/SynchronousEditorTestBase.cs','Tests/Core/Editor/SynchronousEditorTestBaseTests.cs','Tests/Core/Editor/SynchronousEditorTestAsset.cs','Runtime/Core/Random/WeightedIndexTable.cs','Runtime/Core/DataStructure/IntMap.cs','Runtime/Utils/SpriteMaskReader.cs')
$identities = @{}
foreach ($relative in $otherSources) { $identities[$relative] = (Get-FileHash (Join-Path $repository $relative) -Algorithm SHA256).Hash }
$known = @{}
foreach ($variant in $variants) {
    $known[$variant.relative] = @((Get-FileHash (Join-Path $PSScriptRoot $variant.baseline)).Hash,(Get-FileHash (Join-Path $PSScriptRoot $variant.candidate)).Hash,(Get-FileHash (Join-Path $PSScriptRoot $variant.restore)).Hash)
}
$results = @()
try {
    foreach ($index in 1..3) {
        $arms = if ($index -eq 2) { @('candidate','baseline') } else { @('baseline','candidate') }
        foreach ($arm in $arms) {
            foreach ($relative in $otherSources) { if ($identities[$relative] -ne (Get-FileHash (Join-Path $repository $relative) -Algorithm SHA256).Hash) { throw "Frozen source changed: $relative" } }
            foreach ($variant in $variants) {
                $path = Join-Path $repository $variant.relative
                if ((Get-FileHash $path).Hash -notin $known[$variant.relative]) { throw "Variant changed outside experiment: $path" }
                [IO.File]::WriteAllBytes($path,[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $variant.$arm)))
            }
            $before = @{}
            foreach ($variant in $variants) { $before[$variant.relative]=(Get-FileHash (Join-Path $repository $variant.relative)).Hash }
            $artifacts = Join-Path $PSScriptRoot "editor-sync-support-$arm-$index"
            & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Editor.Attributes;WallstopStudios.UnityHelpers.Tests.Editor.Sprites.Animation;WallstopStudios.UnityHelpers.Tests.Core.Editor' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter 'WallstopStudios.UnityHelpers.Tests.Attributes.WShowIfPropertyDrawerTests;WallstopStudios.UnityHelpers.Tests.Attributes.WGroupLayoutBuilderTests;WallstopStudios.UnityHelpers.Tests.Attributes.AnimationEventHelpersTests;WallstopStudios.UnityHelpers.Tests.Sprites.SpriteAnimationHelpersTests;WallstopStudios.UnityHelpers.Tests.Core.TestUtils.SynchronousEditorTestBaseTests' -TestCategory '!Performance;!Stress' *> (Join-Path $PSScriptRoot "editor-sync-support-$arm-$index-driver.log")
            $exitCode=$LASTEXITCODE
            $after=@{}
            foreach ($variant in $variants) { $after[$variant.relative]=(Get-FileHash (Join-Path $repository $variant.relative)).Hash; if ($before[$variant.relative] -ne $after[$variant.relative]) { throw 'Variant changed during capture' } }
            $observation=Get-Content (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
            [xml]$xml=Get-Content (Join-Path $artifacts 'results.xml') -Raw
            $cases=@($xml.SelectNodes('//test-case'))
            $healthy=$observation.Process.RawExitCode -eq 0 -and $observation.Process.StandardOutputEndObserved -and $observation.Process.StandardErrorEndObserved -and -not $observation.Process.OutputDrainStopped
            $complete=$xml.'test-run'.result -eq 'Passed' -and $cases.Count -eq 113 -and @($cases|Where-Object result -ne 'Passed').Count -eq 0
            $log = Get-Content (Join-Path $artifacts 'unity.log') -Raw
            $loaded = @()
            foreach ($variant in $variants) {
                $className = [IO.Path]::GetFileNameWithoutExtension($variant.relative)
                $matches = [regex]::Matches($log,'EDITOR_SYNC_VARIANT\|([^|\r\n]+)\|([^|\r\n]+)\|([0-9a-f-]{36})')
                $gate = @($matches | Where-Object { $_.Groups[1].Value.EndsWith('.' + $className) })
                if ($gate.Count -ne 1) { throw "Missing/duplicate loaded fixture gate: $className" }
                $expectedBase = if ($arm -eq 'baseline') { 'WallstopStudios.UnityHelpers.Tests.Core.CommonTestBase' } elseif ($className -eq 'AnimationEventHelpersTests') { 'System.Object' } else { 'WallstopStudios.UnityHelpers.Tests.Core.SynchronousEditorTestBase' }
                if ($gate[0].Groups[2].Value -cne $expectedBase) { throw "Loaded fixture has wrong base: $className" }
                $loaded += @{type=$gate[0].Groups[1].Value;base=$gate[0].Groups[2].Value;mvid=$gate[0].Groups[3].Value}
            }
            $fixtureRows=@($xml.SelectNodes('//test-suite[@type="TestFixture"]') | ForEach-Object { @{ name=$_.fullname;duration=[double]$_.duration;count=[int]$_.testcasecount } })
            $results += @{ arm=$arm;index=$index;exitCode=$exitCode;before=$before;after=$after;healthy=$healthy;complete=$complete;cases=$cases.Count;fixtures=$fixtureRows;loaded=$loaded;otherSources=$identities }
            $results | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $PSScriptRoot 'editor-sync-support-paired-live.json')
            if ($exitCode -ne 0 -or -not $healthy -or -not $complete) { throw "Capture $arm/$index is incomplete or unhealthy" }
        }
    }
    @{ completedUtc=[DateTime]::UtcNow;results=$results } | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $PSScriptRoot 'editor-sync-support-paired-result.json')
} finally {
    foreach ($variant in $variants) {
        $path=Join-Path $repository $variant.relative
        if ((Get-FileHash $path).Hash -in $known[$variant.relative]) { [IO.File]::WriteAllBytes($path,[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $variant.restore))) }
        else { Write-Error "Source changed outside experiment; leaving it untouched: $path" }
    }
}
