$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261112c'
$consumer = Join-Path $project 'Assets/SupportConsumer'
New-Item -ItemType Directory -Path $consumer -Force | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'support-consumer.cs') (Join-Path $consumer 'SupportConsumerTests.cs')
@{ name='SupportConsumer'; references=@('WallstopStudios.UnityHelpers.TestSupport'); overrideReferences=$true; precompiledReferences=@('nunit.framework.dll'); autoReferenced=$false; defineConstraints=@('UNITY_INCLUDE_TESTS'); includePlatforms=@() } | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $consumer 'SupportConsumer.asmdef')
$inputs=@('Runtime/TestSupport/AllocationProbe.cs','Runtime/TestSupport/ProfilerAllocationCounter.cs','Runtime/TestSupport/UnityObjectTrackingTestBase.cs','Runtime/TestSupport/WallstopStudios.UnityHelpers.TestSupport.asmdef')
$before=@($inputs | ForEach-Object { @{path=$_;sha256=(Get-FileHash (Join-Path $repository $_)).Hash} })
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
& $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'SupportConsumer' -RepoRoot $repository -ProjectPath $project -ArtifactsPath (Join-Path $PSScriptRoot 'native-support-consumer-final') -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter 'ConsumerVerification.SupportConsumerTests' -TestCategory '!Performance;!Stress' *> (Join-Path $PSScriptRoot 'native-support-consumer-final-driver.log')
$exitCode=$LASTEXITCODE
$after=@($inputs | ForEach-Object { @{path=$_;sha256=(Get-FileHash (Join-Path $repository $_)).Hash} })
@{exitCode=$exitCode;completedUtc=[DateTime]::UtcNow;before=$before;after=$after} | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $PSScriptRoot 'native-support-consumer-final-result.json')
