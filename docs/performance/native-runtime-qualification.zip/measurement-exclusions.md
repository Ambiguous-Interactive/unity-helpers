# Measurement exclusion

The initial sprite-rgb-paired campaign overlapped the intmap-inline-set Docker campaign on the same Windows host. All its raw captures are preserved. They may establish functional outcomes and process completion, but are excluded from timing acceptance and performance claims. Repeat sprite timings only after the IntMap controller and all measured child handles are terminal. Do not relabel or overwrite this first campaign. Use a separate serial replay directory/controller and source/assembly identities.
