$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261112c'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$source = Join-Path $repository 'Runtime/Utils/SpriteMaskReader.cs'
$variants = @{ baseline=(Join-Path $PSScriptRoot 'SpriteMaskReader.original.cs');candidate=(Join-Path $PSScriptRoot 'SpriteMaskReader.candidate.cs') }
$knownHashes = @((Get-FileHash $variants.baseline).Hash,(Get-FileHash $variants.candidate).Hash)
$otherSources = @('Runtime/Utils/SpritePixelRegion.cs','Runtime/Utils/SpriteArtBounds.cs','Tests/Runtime/Utils/SpriteMaskReaderTests.cs','Tests/Runtime/Performance/SpriteRegionReadTimingTests.cs')
$identities = @{}
foreach ($relative in $otherSources) { $identities[$relative]=(Get-FileHash (Join-Path $repository $relative) -Algorithm SHA256).Hash }
$results = @()
$assemblyHashes = @{}
try {
foreach ($index in 1..3) {
    $arms=if ($index -eq 2) { @('candidate','baseline') } else { @('baseline','candidate') }
    foreach ($arm in $arms) {
        foreach ($relative in $otherSources) { if ($identities[$relative] -ne (Get-FileHash (Join-Path $repository $relative) -Algorithm SHA256).Hash) { throw "A frozen input changed: $relative" } }
        if ((Get-FileHash $source).Hash -notin $knownHashes) { throw 'Source changed outside the experiment.' }
        [IO.File]::WriteAllBytes($source, [IO.File]::ReadAllBytes($variants[$arm]))
        $before = (Get-FileHash $source -Algorithm SHA256).Hash
        $artifacts = Join-Path $PSScriptRoot "sprite-rgb-serial-$arm-$index"
        & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime.Performance' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter 'WallstopStudios.UnityHelpers.Tests.Utils.SpriteRegionReadTimingTests' -TestCategory '!Stress' *> (Join-Path $PSScriptRoot "sprite-rgb-serial-$arm-$index-driver.log")
        $exitCode = $LASTEXITCODE
        $after = (Get-FileHash $source -Algorithm SHA256).Hash
        $observation = Get-Content -LiteralPath (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
        [xml]$xml=Get-Content -LiteralPath (Join-Path $artifacts 'results.xml') -Raw
        $cases=@($xml.SelectNodes('//test-case'))
        $healthy = $observation.Process.RawExitCode -eq 0 -and $observation.Process.StandardOutputEndObserved -and $observation.Process.StandardErrorEndObserved -and -not $observation.Process.OutputDrainStopped
        $assembly = Join-Path $project 'Library/ScriptAssemblies/WallstopStudios.UnityHelpers.dll'
        $assemblyHash=(Get-FileHash $assembly -Algorithm SHA256).Hash
        if ($assemblyHashes.ContainsKey($arm) -and $assemblyHashes[$arm] -ne $assemblyHash) { throw 'Assembly inputs changed within an arm.' }
        $assemblyHashes[$arm]=$assemblyHash
        if ($assemblyHashes.Count -eq 2 -and $assemblyHashes.baseline -eq $assemblyHashes.candidate) { throw 'Both variants loaded the same assembly.' }
        $complete= $xml.'test-run'.result -eq 'Passed' -and $cases.Count -eq 12 -and @($cases | Where-Object result -ne 'Passed').Count -eq 0
        foreach ($case in $cases) {
            $output=[string]$case.SelectSingleNode('output').InnerText
            if ($output -notmatch 'SPRITE_REGION_ID\|' -or $output -notmatch 'SPRITE_REGION\|') { $complete=$false }
        }
        $results += @{ arm=$arm;index=$index;exitCode=$exitCode;before=$before;after=$after;healthy=$healthy;complete=$complete;cases=$cases.Count;assemblySha256=$assemblyHash;otherSources=$identities }
        $results | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'sprite-rgb-serial-paired-live.json')
        if ($exitCode -ne 0 -or $after -ne $before -or -not $healthy -or -not $complete) { throw "Capture $arm/$index lacks healthy, complete timing evidence." }
    }
}
@{ completedUtc=[DateTime]::UtcNow;results=$results } | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'sprite-rgb-serial-paired-result.json')
} finally {
    if ((Get-FileHash $source).Hash -in $knownHashes) { [IO.File]::WriteAllBytes($source, [IO.File]::ReadAllBytes($variants.candidate)) }
    else { throw 'Source changed outside the experiment; leaving it untouched.' }
}
