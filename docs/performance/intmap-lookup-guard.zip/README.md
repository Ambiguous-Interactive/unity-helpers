# IntMap reserved-key guard experiment

The old arm is current main at a86ec34b, normalized to LF and namespace
OldIntMap. The new arm removes only the redundant reserved-key comparison
in TryGet. Set and the indexer keep their reserved-key contracts.

Sources and 159 distinct cells per process are sealed in recorded/seal.json.
The capture contains three .NET 10 and three Mono processes with 21
rotating rounds, 64 warm calls and >=20 ms calibration for every arm.
Timed values have independent hit/miss/iteration checks. All six receipts
require exit zero, both stream ends and stable source and binary hashes.

Replay in an environment with the recorded SDK policy and Mono installed:
python3 measure.py --runtime net10 --processes 3
python3 measure.py --runtime mono --processes 3 --reuse-build
Recorded outputs are separate so a replay writes fresh receipts.
Compare candidate/main ratios within each process before combining them.
This does not replace the original consumer's 3.7.1 acceptance harness.
