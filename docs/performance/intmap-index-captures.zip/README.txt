IntMap comparison, 2026-11-09.

accepted-index-writes compares main 99e54b1e, the candidate, and Dictionary. It preserves the existing raw-key and zero-key lookup paths and only combines dense/reverse index writes in insertion and rebuild. Its insert and repeated-zero cells use 64 warm calls, >=20 ms calibration, rotating arm order and 21 raw rounds. Churn retains the original fixed-work protocol. Timer and per-call checksums are controls. Three fresh processes per runtime must finish with unchanged source/payload hashes, raw exit zero and both stream ends.

rejected-encoded-keys tests an earlier XOR-encoded representation with >=40 ms calibration. Two complete .NET processes expose regressions. The third process was deliberately stopped after rejection; its -15 exit and partial rows are excluded. No calibrated Mono claim is made for that rejected arm.

original-consumer-replay uses the recovered original Program.cs and the 3.7.1 baseline (verified against tag 3.7.1 after namespace/newline normalization), with the current source substituted. Original labels IntMap362 and IntMap371 now mean 3.7.1 baseline and current candidate respectively. consumer-362-control preserves an initial capture that used the original 3.6.2 source; it is excluded from 3.7.1 acceptance comparisons. Its short intervals and one warm-up limit conclusions; it has minima/medians instead of raw rounds.

Build each directory independently with its pinned global.json and run.py. Both target payload hashes, source identities, child PIDs and stream receipts are preserved. The hash shim is outside the timed operations. These are int-valued host observations, not Unity player or general workload qualification.
