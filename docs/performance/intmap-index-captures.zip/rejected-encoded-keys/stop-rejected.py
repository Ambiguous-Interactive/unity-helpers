import json,os,pathlib,signal
root=pathlib.Path('/tmp/uh-20261109-pm-intmap-qualified')
receipts=json.loads((root/'receipts.json').read_text())
assert len(receipts['processes'])>=2
matches=[]
for directory in pathlib.Path('/proc').iterdir():
    if not directory.name.isdigit(): continue
    try:
        command=(directory/'cmdline').read_bytes().split(b'\0')
        cwd=(directory/'cwd').resolve()
        if cwd==root and any(argument in (bytes(root/'bin/Release/net10.0/IntMapAb.dll'),bytes(root/'bin/Release/net48/IntMapAb.exe')) for argument in command):matches.append(int(directory.name))
    except (OSError,RuntimeError):pass
assert len(matches)==1,matches
(root/'rejected-stop.json').write_text(json.dumps({'reason':'Two completed calibrated .NET processes expose lookup, iteration and repeated-zero regressions; reject this candidate and stop remaining measurements.','targetPid':matches[0],'completedProcesses':len(receipts['processes'])},indent=2)+'\n')
os.kill(matches[0],signal.SIGTERM)
print('Stopped rejected measurement child',matches[0])
