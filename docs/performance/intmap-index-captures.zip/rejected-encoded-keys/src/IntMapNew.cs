// MIT License - Copyright (c) 2026 wallstop
// Full license text: https://github.com/wallstop/unity-helpers/blob/main/LICENSE

namespace WallstopStudios.UnityHelpers.Core.DataStructure
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// An int-keyed open-addressing hash map built for read-mostly lookups, where a
    /// <see cref="Dictionary{TKey, TValue}"/> pays for an interface it never needed.
    /// </summary>
    /// <typeparam name="TValue">The value type.</typeparam>
    /// <remarks>
    /// <para>
    /// Benchmark this map against <c>Dictionary&lt;int,int&gt;</c> for the caller's key distribution
    /// and miss rate. Earlier editor Mono measurements used the previous low-bit slot selection
    /// and do not establish a margin for this implementation. A miss walks occupied slots until
    /// it reaches an untouched slot; shared-low-bit keys therefore need their own controls.
    /// </para>
    /// <para>
    /// Keys are
    /// compared as encoded integers rather than routed through <see cref="IEqualityComparer{T}"/>.
    /// Table length stays a power of two, so slot position is one multiply and one
    /// shift instead of a division. Growth doubles the table when live entries reach one quarter of its slots.
    /// Removal closes probe-chain gaps in place without allocating replacement storage.
    /// </para>
    /// <para>
    /// A dense list of occupied slots supports O(Count) enumeration, including after removals.
    /// Slot positions share one ushort or int index array according to the table's capacity.
    /// The extra indexing storage trades memory for iteration speed. Removal may change order.
    /// If a growth allocation fails, the existing contents and enumerators remain valid.
    /// The two lowest key values remain reserved; see <see cref="MinimumAllowedKey"/>.
    /// </para>
    /// </remarks>
    public sealed class IntMap<TValue>
        : IReadOnlyDictionary<int, TValue>,
            IEnumerable<KeyValuePair<int, TValue>>
    {
        /// <summary>The smallest key a caller may store; everything lower is reserved.</summary>
        public const int MinimumAllowedKey = int.MinValue + 2;

        private const int DefaultInitialCapacity = 8;
        private const int MinimumTablePower = 4;
        private const int MaximumTablePower = 30;
        private const int LoadFactorDivisor = 4;
        private const int SparseClearDivisor = 64;

        // Fibonacci hashing uses the high product bits so shared low key bits do not form a cluster.
        private const uint KeyMultiplier = 0x9E37_79B9u;

        private const int EmptySlot = 0;
        private const int KeyEncodingMask = int.MinValue;

        /// <summary>Gets how many live entries the map holds.</summary>
        public int Count => _count;

        /// <summary>Gets whether the map holds no entries.</summary>
        public bool IsEmpty => _count == 0;

        /// <summary>Gets the number of slots in the underlying table.</summary>
        public int Capacity => _keys.Length;

        /// <summary>
        /// Gets the value stored under <paramref name="key"/>.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <exception cref="KeyNotFoundException">Thrown when the key is absent.</exception>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when <paramref name="key"/> falls below <see cref="MinimumAllowedKey"/>.
        /// </exception>
        public TValue this[int key]
        {
            get
            {
                Validate(key);
                int slot = FindSlot(key);
                if (_keys[slot] != EmptySlot)
                {
                    return _values[slot];
                }

                throw new KeyNotFoundException($"No value is stored under {key}.");
            }
            set
            {
                int validKey = Validate(key);
                SetInternal(validKey, value);
            }
        }

        /// <summary>Gets the stored keys, in unspecified order.</summary>
        /// <remarks>
        /// Returns the concrete <see cref="KeyView"/> rather than <see cref="IEnumerable{T}"/> so
        /// typed <c>foreach</c> binds the struct enumerator directly and allocates nothing; the
        /// <c>IReadOnlyDictionary</c> surface reaches this same view through its explicit
        /// interface implementation.
        /// </remarks>
        public KeyView Keys => new KeyView(this);

        /// <summary>Gets the stored values, in unspecified order.</summary>
        /// <remarks>
        /// Returns the concrete <see cref="ValueView"/> for the same reason <see cref="Keys"/>
        /// does: typed <c>foreach</c> must reach the struct enumerator without boxing.
        /// </remarks>
        public ValueView Values => new ValueView(this);

        IEnumerable<int> IReadOnlyDictionary<int, TValue>.Keys => Keys;

        IEnumerable<TValue> IReadOnlyDictionary<int, TValue>.Values => Values;

        private int[] _keys;
        private TValue[] _values;
        private ushort[] _compactIndices;
        private int[] _indices;
        private int _mask;
        private int _shift;
        private int _count;
        private ulong _version;

        /// <summary>
        /// Initializes an empty map sized for sixteen live entries before its first resize.
        /// </summary>
        public IntMap()
            : this(DefaultInitialCapacity) { }

        /// <summary>
        /// Initializes an empty map able to hold <paramref name="initialCapacity"/> entries without
        /// resizing.
        /// </summary>
        /// <param name="initialCapacity">How many live entries to make room for.</param>
        /// <remarks>
        /// The table reserves at least four slots per requested live entry and rounds up to a power of two.
        /// This keeps probe chains short at the cost of more storage.
        /// </remarks>
        public IntMap(int initialCapacity)
        {
            if (initialCapacity < 0)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(initialCapacity),
                    "Capacity must be positive."
                );
            }

            int power = SmallestSufficientPower(initialCapacity);
            if ((1L << power) / LoadFactorDivisor < initialCapacity)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(initialCapacity),
                    "Requested capacity exceeds what an int-keyed table can address."
                );
            }

            Rebuild(power);
        }

        private static uint Mix(int key)
        {
            return unchecked((uint)key * KeyMultiplier);
        }

        private static int SmallestSufficientPower(int capacityHint)
        {
            // Bound the power-of-two search before a 32-bit shift can wrap.
            int power = MinimumTablePower;
            while (
                power < MaximumTablePower
                && 0 < (long)capacityHint
                && (long)(1 << power) / LoadFactorDivisor <= (long)capacityHint
            )
            {
                ++power;
            }

            return power;
        }

        private static int PowerOf(int capacity)
        {
            int power = MinimumTablePower;
            while (1 << power < capacity)
            {
                ++power;
            }

            return power;
        }

        /// <summary>
        /// Stores <paramref name="value"/> under <paramref name="key"/>, replacing any prior value.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns>
        /// <c>true</c> when written; <c>false</c> when the key is reserved, in which case
        /// nothing was stored.
        /// </returns>
        /// <remarks>Replacing an existing value preserves the table storage, even at the occupancy limit.</remarks>
        public bool TrySet(int key, TValue value)
        {
            if (key < MinimumAllowedKey)
            {
                return false;
            }

            SetInternal(key, value);
            return true;
        }

        /// <summary>
        /// Gets the value stored under <paramref name="key"/>, if present.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="value">Receives the stored value, or the type's default on absence.</param>
        /// <returns><c>true</c> when the key is present.</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool TryGet(int key, out TValue value)
        {
            if (key < MinimumAllowedKey || _count == 0)
            {
                value = default(TValue);
                return false;
            }

            int[] keys = _keys;
            int slot = (int)(unchecked((uint)key * KeyMultiplier) >> _shift);
            key ^= KeyEncodingMask;
            while (true)
            {
                int stored = keys[slot];
                if (stored == key)
                {
                    value = _values[slot];
                    return true;
                }

                if (stored == EmptySlot)
                {
                    value = default(TValue);
                    return false;
                }

                slot = (slot + 1) & _mask;
            }
        }

        /// <summary>
        /// Removes <paramref name="key"/> and its value.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="value">Receives the removed value, or the type's default on absence.</param>
        /// <returns><c>true</c> when the key was present and is now gone.</returns>
        /// <remarks>
        /// Removal shifts displaced entries whose probe paths cross the deleted slot, closing
        /// the gap without allocating or rebuilding the table. Other keys remain reachable,
        /// including probe chains that wrap around the end of the table.
        /// </remarks>
        public bool Remove(int key, out TValue value)
        {
            if (key < MinimumAllowedKey || _count == 0)
            {
                value = default(TValue);
                return false;
            }

            int slot = FindSlot(key);
            if (_keys[slot] == EmptySlot)
            {
                value = default(TValue);
                return false;
            }

            TValue removed = _values[slot];
            int position = PositionAt(slot);
            int lastPosition = _count - 1;
            int lastSlot = OccupiedSlotAt(lastPosition);
            SetOccupiedSlot(position, lastSlot);
            SetPosition(lastSlot, position);
            CloseGap(slot);
            --_count;
            ++_version;
            value = removed;
            return true;
        }

        /// <summary>
        /// Reports whether <paramref name="key"/> is currently stored.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns><c>false</c> when absent or below <see cref="MinimumAllowedKey"/>.</returns>
        public bool ContainsKey(int key)
        {
            return TryGet(key, out _);
        }

        /// <summary>Drops every entry, keeping the current table.</summary>
        /// <remarks>
        /// Releases stored values and retains the table and occupied-slot indexing arrays.
        /// Sparse tables clear occupied slots; denser tables clear the backing arrays.
        /// </remarks>
        public void Clear()
        {
            if (_count != 0)
            {
                ClearEntries();
            }

            _count = 0;
            ++_version;
        }

        /// <inheritdoc />
        public Enumerator GetEnumerator()
        {
            return new Enumerator(this);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void ClearEntries()
        {
            int capacity = _keys.Length;
            if (_count < capacity / SparseClearDivisor)
            {
                int count = _count;
                for (int position = 0; position < count; ++position)
                {
                    int slot = OccupiedSlotAt(position);
                    _keys[slot] = EmptySlot;
                    _values[slot] = default;
                }
            }
            else
            {
                Array.Clear(_keys, 0, capacity);
                Array.Clear(_values, 0, capacity);
            }
        }

        private void SetInternal(int key, TValue value)
        {
            uint hash = Mix(key);
            int slot = SlotFor(hash);
            key ^= KeyEncodingMask;
            while (true)
            {
                int stored = _keys[slot];
                if (stored == key)
                {
                    _values[slot] = value;
                    ++_version;
                    return;
                }

                if (stored == EmptySlot)
                {
                    if (_keys.Length <= Count * LoadFactorDivisor)
                    {
                        Resize();
                        int originalKey = key ^ KeyEncodingMask;
                        SetInternal(originalKey, value);
                        return;
                    }

                    _keys[slot] = key;
                    _values[slot] = value;
                    SetEntryIndex(slot, _count);
                    ++_count;
                    ++_version;
                    return;
                }

                slot = NextSlot(slot);
            }
        }

        private void CloseGap(int gap)
        {
            int slot = NextSlot(gap);
            while (_keys[slot] != EmptySlot)
            {
                int displacedKey = _keys[slot] ^ KeyEncodingMask;
                uint hash = Mix(displacedKey);
                int home = SlotFor(hash);
                if (((gap - home) & _mask) < ((slot - home) & _mask))
                {
                    _keys[gap] = _keys[slot];
                    _values[gap] = _values[slot];
                    int position = PositionAt(slot);
                    SetPosition(gap, position);
                    SetOccupiedSlot(position, gap);
                    gap = slot;
                }
                slot = NextSlot(slot);
            }

            _keys[gap] = EmptySlot;
            _values[gap] = default(TValue);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void SetEntryIndex(int slot, int position)
        {
            int index = _keys.Length + position;
            if (_compactIndices != null)
            {
                _compactIndices[slot] = (ushort)position;
                _compactIndices[index] = (ushort)slot;
            }
            else
            {
                _indices[slot] = position;
                _indices[index] = slot;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private int PositionAt(int slot)
        {
            return _compactIndices != null ? _compactIndices[slot] : _indices[slot];
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void SetPosition(int slot, int position)
        {
            if (_compactIndices != null)
            {
                _compactIndices[slot] = (ushort)position;
            }
            else
            {
                _indices[slot] = position;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private int OccupiedSlotAt(int position)
        {
            int index = _keys.Length + position;
            return _compactIndices != null ? _compactIndices[index] : _indices[index];
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void SetOccupiedSlot(int position, int slot)
        {
            int index = _keys.Length + position;
            if (_compactIndices != null)
            {
                _compactIndices[index] = (ushort)slot;
            }
            else
            {
                _indices[index] = slot;
            }
        }

        private int FindSlot(int key)
        {
            uint hash = Mix(key);
            int slot = SlotFor(hash);
            key ^= KeyEncodingMask;
            while (true)
            {
                int stored = _keys[slot];
                if (stored == EmptySlot || stored == key)
                {
                    return slot;
                }

                slot = NextSlot(slot);
            }
        }

        private void Resize()
        {
            int currentPower = PowerOf(_keys.Length);
            int nextPower = currentPower + 1;

            if (MaximumTablePower < nextPower)
            {
                throw new InvalidOperationException("This map cannot grow past its largest table.");
            }

            Rebuild(nextPower);
        }

        private void Rebuild(int power)
        {
            int capacity = 1 << power;
            int[] oldKeys = _keys;
            TValue[] oldValues = _values;
            int[] keys = new int[capacity];
            TValue[] values = new TValue[capacity];
            int indexCapacity = capacity + capacity / LoadFactorDivisor;
            ushort[] compactIndices;
            int[] indices;
            if (capacity <= ushort.MaxValue + 1)
            {
                compactIndices = new ushort[indexCapacity];
                indices = null;
            }
            else
            {
                indices = new int[indexCapacity];
                compactIndices = null;
            }
            _keys = keys;
            _values = values;
            _compactIndices = compactIndices;
            _indices = indices;
            _mask = capacity - 1;
            _shift = 32 - power;
            _count = 0;
            ++_version;
            if (oldKeys == null)
            {
                return;
            }
            int oldKeysLength = oldKeys.Length;
            for (int index = 0; index < oldKeysLength; ++index)
            {
                int stored = oldKeys[index];
                if (stored == EmptySlot)
                {
                    continue;
                }
                int originalKey = stored ^ KeyEncodingMask;
                int slot = FindSlot(originalKey);
                _keys[slot] = stored;
                _values[slot] = oldValues[index];
                SetEntryIndex(slot, _count);
                ++_count;
            }
        }

        private int Validate(int key)
        {
            if (key < MinimumAllowedKey)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(key),
                    $"{key} falls below {nameof(MinimumAllowedKey)}, the smallest storable key."
                );
            }

            return key;
        }

        private int SlotFor(uint hash)
        {
            return (int)(hash >> _shift);
        }

        private int NextSlot(int slot)
        {
            return (slot + 1) & _mask;
        }

        bool IReadOnlyDictionary<int, TValue>.TryGetValue(int key, out TValue value)
        {
            return TryGet(key, out value);
        }

        IEnumerator<KeyValuePair<int, TValue>> IEnumerable<
            KeyValuePair<int, TValue>
        >.GetEnumerator()
        {
            return GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        /// <summary>Enumerates live key-value pairs in unspecified order.</summary>
        public struct Enumerator
            : IEnumerator<KeyValuePair<int, TValue>>,
                global::System.IEquatable<Enumerator>
        {
            /// <inheritdoc />
            public KeyValuePair<int, TValue> Current => _current;

            object IEnumerator.Current => _current;

            private readonly IntMap<TValue> _map;
            private readonly ulong _version;
            private readonly ushort[] _compactIndices;
            private readonly int[] _indices;
            private readonly int _entryOffset;
            private readonly int _end;
            private readonly int[] _keys;
            private int _slot;
            private KeyValuePair<int, TValue> _current;

            internal Enumerator(IntMap<TValue> map)
            {
                _map = map;
                _version = map._version;
                _compactIndices = map._compactIndices;
                _indices = map._indices;
                _entryOffset = map._keys.Length;
                _end = _entryOffset + map._count;
                _keys = map._keys;
                _slot = _entryOffset;
                _current = default(KeyValuePair<int, TValue>);
            }

            /// <inheritdoc />
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public bool MoveNext()
            {
                if (_version != _map._version)
                {
                    throw new InvalidOperationException("The map changed during enumeration.");
                }

                if (_slot < _end)
                {
                    int slot = _compactIndices != null ? _compactIndices[_slot] : _indices[_slot];
                    ++_slot;
                    _current = new KeyValuePair<int, TValue>(
                        _keys[slot] ^ KeyEncodingMask,
                        _map._values[slot]
                    );
                    return true;
                }

                return false;
            }

            /// <inheritdoc />
            public void Reset()
            {
                if (_version != _map._version)
                {
                    throw new InvalidOperationException("The map changed during enumeration.");
                }

                _slot = _entryOffset;
                _current = default(KeyValuePair<int, TValue>);
            }

            /// <inheritdoc />
            public void Dispose() { }

            /// <summary>Compares the stored fields with another value.</summary>
            public bool Equals(Enumerator other)
            {
                return EqualityComparer<IntMap<TValue>>.Default.Equals(_map, other._map)
                    && _version.Equals(other._version)
                    && _slot.Equals(other._slot)
                    && EqualityComparer<KeyValuePair<int, TValue>>.Default.Equals(
                        _current,
                        other._current
                    );
            }

            /// <inheritdoc />
            public override bool Equals(object obj)
            {
                return obj is Enumerator other && Equals(other);
            }

            /// <inheritdoc />
            public override int GetHashCode()
            {
                return global::WallstopStudios.UnityHelpers.Core.Helper.Objects.HashCode(
                    _map,
                    _version,
                    _slot,
                    _current
                );
            }
        }

        /// <summary>A live-keys view whose typed enumerator is a struct.</summary>
        /// <remarks>
        /// Like <see cref="Enumerator"/>, the walk fails fast on a version change: a resize swaps
        /// the slot storage, and an iterator that kept the old index would skip or repeat entries
        /// against new arrays instead of reporting the mutation.
        /// </remarks>
        public readonly struct KeyView : IEnumerable<int>, global::System.IEquatable<KeyView>
        {
            private readonly IntMap<TValue> _map;

            internal KeyView(IntMap<TValue> map)
            {
                _map = map;
            }

            /// <summary>Returns the struct enumerator; the typed foreach path allocates nothing.</summary>
            public KeyEnumerator GetEnumerator()
            {
                return new KeyEnumerator(_map);
            }

            /// <summary>Compares the stored fields with another value.</summary>
            public bool Equals(KeyView other)
            {
                return EqualityComparer<IntMap<TValue>>.Default.Equals(_map, other._map);
            }

            /// <inheritdoc />
            public override bool Equals(object obj)
            {
                return obj is KeyView other && Equals(other);
            }

            /// <inheritdoc />
            public override int GetHashCode()
            {
                return global::WallstopStudios.UnityHelpers.Core.Helper.Objects.HashCode(_map);
            }

            IEnumerator<int> IEnumerable<int>.GetEnumerator()
            {
                return GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }

        /// <summary>A live-values view whose typed enumerator is a struct.</summary>
        /// <remarks>
        /// Shares <see cref="KeyView"/>'s fail-fast contract and its no-boxing rationale.
        /// </remarks>
        public readonly struct ValueView : IEnumerable<TValue>, global::System.IEquatable<ValueView>
        {
            private readonly IntMap<TValue> _map;

            internal ValueView(IntMap<TValue> map)
            {
                _map = map;
            }

            /// <summary>Returns the struct enumerator; the typed foreach path allocates nothing.</summary>
            public ValueEnumerator GetEnumerator()
            {
                return new ValueEnumerator(_map);
            }

            /// <summary>Compares the stored fields with another value.</summary>
            public bool Equals(ValueView other)
            {
                return EqualityComparer<IntMap<TValue>>.Default.Equals(_map, other._map);
            }

            /// <inheritdoc />
            public override bool Equals(object obj)
            {
                return obj is ValueView other && Equals(other);
            }

            /// <inheritdoc />
            public override int GetHashCode()
            {
                return global::WallstopStudios.UnityHelpers.Core.Helper.Objects.HashCode(_map);
            }

            IEnumerator<TValue> IEnumerable<TValue>.GetEnumerator()
            {
                return GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }

        /// <summary>Enumerates live keys; fails fast when the map changes mid-walk.</summary>
        public struct KeyEnumerator : IEnumerator<int>, global::System.IEquatable<KeyEnumerator>
        {
            /// <inheritdoc />
            public int Current => _current;

            object IEnumerator.Current => _current;

            private readonly IntMap<TValue> _map;
            private readonly ulong _version;
            private readonly ushort[] _compactIndices;
            private readonly int[] _indices;
            private readonly int _entryOffset;
            private readonly int _end;
            private readonly int[] _keys;
            private int _slot;
            private int _current;

            internal KeyEnumerator(IntMap<TValue> map)
            {
                _map = map;
                _version = map._version;
                _compactIndices = map._compactIndices;
                _indices = map._indices;
                _entryOffset = map._keys.Length;
                _end = _entryOffset + map._count;
                _keys = map._keys;
                _slot = _entryOffset;
                _current = 0;
            }

            /// <inheritdoc />
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public bool MoveNext()
            {
                if (_version != _map._version)
                {
                    throw new InvalidOperationException("The map changed during enumeration.");
                }

                if (_slot < _end)
                {
                    int slot = _compactIndices != null ? _compactIndices[_slot] : _indices[_slot];
                    ++_slot;
                    _current = _keys[slot] ^ KeyEncodingMask;
                    return true;
                }

                return false;
            }

            /// <inheritdoc />
            public void Reset()
            {
                if (_version != _map._version)
                {
                    throw new InvalidOperationException("The map changed during enumeration.");
                }

                _slot = _entryOffset;
                _current = 0;
            }

            /// <inheritdoc />
            public void Dispose() { }

            /// <summary>Compares the stored fields with another value.</summary>
            public bool Equals(KeyEnumerator other)
            {
                return EqualityComparer<IntMap<TValue>>.Default.Equals(_map, other._map)
                    && _version.Equals(other._version)
                    && _slot.Equals(other._slot)
                    && _current.Equals(other._current);
            }

            /// <inheritdoc />
            public override bool Equals(object obj)
            {
                return obj is KeyEnumerator other && Equals(other);
            }

            /// <inheritdoc />
            public override int GetHashCode()
            {
                return global::WallstopStudios.UnityHelpers.Core.Helper.Objects.HashCode(
                    _map,
                    _version,
                    _slot,
                    _current
                );
            }
        }

        /// <summary>Enumerates live values; fails fast when the map changes mid-walk.</summary>
        public struct ValueEnumerator
            : IEnumerator<TValue>,
                global::System.IEquatable<ValueEnumerator>
        {
            /// <inheritdoc />
            public TValue Current => _current;

            object IEnumerator.Current => _current;

            private readonly IntMap<TValue> _map;
            private readonly ulong _version;
            private readonly ushort[] _compactIndices;
            private readonly int[] _indices;
            private readonly int _entryOffset;
            private readonly int _end;
            private int _slot;
            private TValue _current;

            internal ValueEnumerator(IntMap<TValue> map)
            {
                _map = map;
                _version = map._version;
                _compactIndices = map._compactIndices;
                _indices = map._indices;
                _entryOffset = map._keys.Length;
                _end = _entryOffset + map._count;
                _slot = _entryOffset;
                _current = default(TValue);
            }

            /// <inheritdoc />
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public bool MoveNext()
            {
                if (_version != _map._version)
                {
                    throw new InvalidOperationException("The map changed during enumeration.");
                }

                if (_slot < _end)
                {
                    int slot = _compactIndices != null ? _compactIndices[_slot] : _indices[_slot];
                    ++_slot;
                    _current = _map._values[slot];
                    return true;
                }

                return false;
            }

            /// <inheritdoc />
            public void Reset()
            {
                if (_version != _map._version)
                {
                    throw new InvalidOperationException("The map changed during enumeration.");
                }

                _slot = _entryOffset;
                _current = default(TValue);
            }

            /// <inheritdoc />
            public void Dispose() { }

            /// <summary>Compares the stored fields with another value.</summary>
            public bool Equals(ValueEnumerator other)
            {
                return EqualityComparer<IntMap<TValue>>.Default.Equals(_map, other._map)
                    && _version.Equals(other._version)
                    && _slot.Equals(other._slot)
                    && EqualityComparer<TValue>.Default.Equals(_current, other._current);
            }

            /// <inheritdoc />
            public override bool Equals(object obj)
            {
                return obj is ValueEnumerator other && Equals(other);
            }

            /// <inheritdoc />
            public override int GetHashCode()
            {
                return global::WallstopStudios.UnityHelpers.Core.Helper.Objects.HashCode(
                    _map,
                    _version,
                    _slot,
                    _current
                );
            }
        }
    }
}
