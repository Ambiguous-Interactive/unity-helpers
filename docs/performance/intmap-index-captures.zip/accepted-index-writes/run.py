import hashlib,json,pathlib,subprocess,time,os
root=pathlib.Path(__file__).resolve().parent
os.chdir(root)
files=[*root.glob('src/*.cs'),root/'IntMapAb.csproj',root/'global.json']
def hashes(): return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
before=hashes()
build=subprocess.run(['dotnet','build','-c','Release','--nologo'],capture_output=True)
(root/'build.stdout').write_bytes(build.stdout); (root/'build.stderr').write_bytes(build.stderr)
if build.returncode: raise SystemExit(build.returncode)
payloads=[root/'bin/Release/net10.0/IntMapAb.dll',root/'bin/Release/net48/IntMapAb.exe']
sealed={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in payloads}
receipts=[]
for runtime,command in [('net10',['dotnet',str(payloads[0]),'net10']),('mono',['mono',str(payloads[1]),'mono'])]:
    for process in range(1,4):
        start=time.monotonic(); child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE); stdout,stderr=child.communicate(); result=subprocess.CompletedProcess(command,child.returncode,stdout,stderr)
        prefix=f'{runtime}-{process}'; (root/f'{prefix}.stdout.jsonl').write_bytes(result.stdout); (root/f'{prefix}.stderr').write_bytes(result.stderr)
        rows=[json.loads(line) for line in result.stdout.splitlines()]
        receipt={'runtime':runtime,'process':process,'exit':result.returncode,'pid':child.pid,'stdout_eof':True,'stderr_eof':True,'seconds':time.monotonic()-start,'rows':len(rows),'inputs_stable':before==hashes(),'payloads_stable':sealed=={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in payloads}}
        receipts.append(receipt); (root/'receipts.json').write_text(json.dumps({'sources':before,'payloads':sealed,'processes':receipts},indent=2)+'\n')
        if result.returncode or len(rows)!=51 or not receipt['inputs_stable'] or not receipt['payloads_stable']: raise SystemExit('unqualified process')
(root/'done.json').write_text(json.dumps({'qualified_processes':len(receipts)})+'\n')
