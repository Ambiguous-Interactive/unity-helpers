from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
sources=[root/'scripts/readme_mirror.py',root/'scripts/tests/test_readme_mirror.py',root/'scripts/sync-readme-mirror.js',root/'scripts/lint-readme-mirror.js',root/'scripts/python~/uv.lock',root/'README.md',root/'docs/readme.md',out/'sync-readme-mirror.js']
def hashes():return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
commands={'original':['node',str(out/'sync-readme-mirror.js'),'--check','--verbose'],'python':['uv','run','--quiet','--project','scripts/python~','--locked','--no-dev','python','scripts/readme_mirror.py','--check','--verbose']}
rows=[]
for index in range(1,4):
 for arm in (['original','python'] if index%2 else ['python','original']):
  before=hashes();start=time.perf_counter()
  p=subprocess.Popen(commands[arm],cwd=root,env={**os.environ,'README_MIRROR_ROOT':str(root)},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  stdout,stderr=p.communicate(timeout=60);elapsed=time.perf_counter()-start
  (out/f'readme-final-{arm}-{index}.stdout').write_bytes(stdout);(out/f'readme-final-{arm}-{index}.stderr').write_bytes(stderr)
  row={'arm':arm,'index':index,'pid':p.pid,'exitCode':p.returncode,'seconds':elapsed,'bothStreamsComplete':True,'sourcesStable':before==hashes(),'sources':before,'command':commands[arm]};rows.append(row)
  assert p.returncode==0 and row['sourcesStable'] and b'matches README.md.' in stdout,row
  print(arm,index,round(elapsed,4))
(out/'readme-final-paired-results.json').write_text(json.dumps(rows,indent=2)+'\n')
