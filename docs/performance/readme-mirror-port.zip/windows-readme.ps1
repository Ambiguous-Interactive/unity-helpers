$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
Push-Location $repository
try {
    $env:UV_PROJECT_ENVIRONMENT = Join-Path ([IO.Path]::GetTempPath()) 'uh-python-20261112b'
    $env:PYTHONUTF8 = '0'
    $env:PYTHONIOENCODING = 'cp1252'
    & uv run --quiet --project scripts/python~ --locked --python 3.11 python -c "import sys,locale;print(sys.version);print(locale.getencoding());print(sys.flags.utf8_mode)" *> (Join-Path $PSScriptRoot 'windows-readme-environment.log')
    if ($LASTEXITCODE -ne 0) { throw 'Could not inspect the native Python environment.' }
    $sources = @('scripts/readme_mirror.py','scripts/tests/test_readme_mirror.py','scripts/tests/fixtures/readme-mirror-v1.json','scripts/python~/uv.lock','scripts/lint-readme-mirror.js','scripts/sync-readme-mirror.js','scripts/tests/test-sync-readme-mirror.js','scripts/cli_encoding.py','package.json')
    $before = @{}
    foreach ($source in $sources) { $before[$source] = (Get-FileHash $source -Algorithm SHA256).Hash }
    & uv run --quiet --project scripts/python~ --locked --python 3.11 pytest scripts/tests/test_readme_mirror.py -q *> (Join-Path $PSScriptRoot 'windows-readme.log')
    $exitCode = $LASTEXITCODE
    $after = @{}
    foreach ($source in $sources) { $after[$source] = (Get-FileHash $source -Algorithm SHA256).Hash; if ($after[$source] -ne $before[$source]) { throw 'Sources changed during Windows test execution.' } }
    @{ exitCode=$exitCode; before=$before; after=$after; completedUtc=[DateTime]::UtcNow } | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'windows-readme-result.json')
} finally { Pop-Location }
