from pathlib import Path
import os,json,subprocess,hashlib,tempfile
root=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
results={}
with tempfile.TemporaryDirectory(prefix='uh-readme-controls-') as temporary:
 base=Path(temporary)
 for arm in ['original','python']:
  fixture=base/arm;fixture.mkdir();(fixture/'docs').mkdir();source=fixture/'README.md';mirror=fixture/'docs/readme.md';source.write_bytes(b'# Source\r\n');os.link(source,mirror)
  command=['node',str(out/'sync-readme-mirror.js')] if arm=='original' else ['uv','run','--quiet','--project','scripts/python~','--locked','--no-dev','python','scripts/readme_mirror.py']
  before=source.read_bytes();p=subprocess.run(command,cwd=root,env={**os.environ,'README_MIRROR_ROOT':str(fixture)},capture_output=True,timeout=60)
  results[arm]={'exit':p.returncode,'sourcePreserved':before==source.read_bytes(),'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
 assert results['original']['exit']==results['python']['exit']==0 and not results['original']['sourcePreserved'] and results['python']['sourcePreserved'],results
 fixture=base/'encoded';(fixture/'docs').mkdir(parents=True);(fixture/'README.md').write_text('# T\n[x](./docs/guide%20one.md)\n');(fixture/'docs/guide one.md').write_text('# Guide\n')
 program='const fs=require("fs");const path=require("path");const g=require(process.argv[1]);const r=process.env.README_MIRROR_ROOT;console.log(JSON.stringify(g.buildMirror(fs.readFileSync(path.join(r,"README.md"),"utf8"),p=>fs.readFileSync(path.join(r,p),"utf8"))))'
 p=subprocess.run(['node','-e',program,str(out/'sync-readme-mirror.js')],cwd=root,env={**os.environ,'README_MIRROR_ROOT':str(fixture)},capture_output=True,check=True,timeout=60)
 original=json.loads(p.stdout);assert '[x](./guide one.md)' in original['content']
 results['encodedOriginal']=original
 results['sourceSha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'sync-readme-mirror.js',root/'scripts/readme_mirror.py']}
(out/'readme-original-controls.json').write_text(json.dumps(results,indent=2)+'\n')
print('Original loses source hard link and decodes URL spaces; Python preserves source and has separate encoded-target regressions.')
