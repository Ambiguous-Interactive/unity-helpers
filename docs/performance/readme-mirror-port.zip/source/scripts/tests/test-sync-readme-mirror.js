#!/usr/bin/env node
"use strict";
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const root = path.resolve(__dirname, "..", "..");
const result = spawnSync(
  "uv",
  [
    "run",
    "--quiet",
    "--project",
    path.join(root, "scripts/python~"),
    "--locked",
    "pytest",
    path.join(root, "scripts/tests/test_readme_mirror.py"),
    "-q",
    ...process.argv.slice(2)
  ],
  { stdio: "inherit" }
);
if (result.error) {
  console.error(`Python tests could not start: ${result.error.message}`);
}
process.exit(result.status === null ? 1 : result.status);
