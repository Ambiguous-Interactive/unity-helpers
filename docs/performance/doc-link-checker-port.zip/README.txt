Documentation-link checker port, 2026-11-12. Base: main af80061e.

The original executable passes its complete 51-assertion suite. The capture JSONL retains 41 actual invocations. The current frozen corpus preserves their inputs and diagnostics. The typed Python suite adds CLI, path, language and real launcher controls, for 90 cases.

Native Windows passes 89 cases with one unsupported-filename skip, using Python 3.11.17, CP1252 and UTF-8 mode disabled. All ten source hashes match before and after. Ruff, formatting, strict mypy and Pyright pass all 129 registered Python sources.

Deliberate tightening: missing or external selected sources, empty Git inventories and scans with no supported source files fail. Targets must actually exist. Angle targets preserve spaces; decoded backslashes retain the old separator policy. The original inline-link limitation for parentheses remains; this is not a complete CommonMark parser.

The Format scan witness uses the exact original policy. It has no Markdown sources: the original exits zero and Python exits one. Both source hashes are recorded. Other regressions are covered by the typed tests and frozen corpus.

SUITE TIMING
Three alternating fresh process pairs compare the original 51 assertions with the expanded 90 Python cases. Original seconds: 7.957, 8.097, 7.806. Python seconds: 8.744, 6.997, 8.396. Commands include compatibility launchers and fixture Git setup. Source hashes stay fixed within every command. All commands exit zero and both output streams reach EOF.

These results do not establish a consistent suite speedup. Case counts differ. No full-checker, CI or Unity runtime speedup is claimed.

REPLAY
Overlay current/ into an isolated checkout of main af80061e. Place the root archive files under progress/.artifacts/doc-link-replay. Install locked uv tools and make Node, PowerShell and Git available. Run:
  python3 progress/.artifacts/doc-link-replay/measure-doc-link-suite.py
The script derives the repository from that directory layout. Keep a fresh directory for outputs. The raw original suite is preserved; its timing copy changes only the two script/helper locations to portable anchors. The original checker is unchanged.

The optional Windows script owns TEMP/uh-python-20261112. Choose a fresh task-specific environment for a replay alongside other work. A recorded Windows receipt applies only to its recorded source hashes. Generate metadata for newly overlaid files before opening Unity.

This archive contains one completed migration slice. Issue #859 remains open for other substantive PowerShell, Bash and JavaScript families and final consolidation. The strict source registry expects the full repository, not a standalone small project.
