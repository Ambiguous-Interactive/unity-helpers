from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent;fixture=out/'empty-scope-witness-final';fixture.mkdir(exist_ok=False);(fixture/'scripts').mkdir()
for original,name in [(out/'lint-doc-links.original.ps1','lint-doc-links.ps1'),(root/'scripts/comment-stripping.ps1','comment-stripping.ps1')]:
 (fixture/'scripts'/name).write_bytes(original.read_bytes())
(fixture/'program.cs').write_text('class Program {}\n')
subprocess.run(['git','init','-q',str(fixture)],check=True)
commands={'original':['pwsh','-NoProfile','-File',str(fixture/'scripts/lint-doc-links.ps1'),'-Mode','Format'],'python':['uv','run','--quiet','--project','scripts/python~','--locked','--no-dev','python','scripts/lint_doc_links.py','--repo-root',str(fixture),'--mode','Format']};results={}
for arm,command in commands.items():
 r=subprocess.run(command,cwd=root,capture_output=True,timeout=30);results[arm]={'exitCode':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
assert results['original']['exitCode']==0 and results['python']['exitCode']==1,results
assert 'No supported documentation source files' in results['python']['stderr']
results['sourceSha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'lint-doc-links.original.ps1',root/'scripts/lint_doc_links.py']}
(out/'doc-links-empty-scope-witness-final.json').write_text(json.dumps(results,indent=2)+'\n');print({arm:results[arm]['exitCode'] for arm in commands})
