from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
sources=['scripts/lint_doc_links.py','scripts/tests/test_doc_links.py','scripts/tests/fixtures/doc-links-v1.json','scripts/csharp_sources.py','scripts/cli_encoding.py','scripts/lint-doc-links.ps1','scripts/tests/test-lint-doc-links.ps1','scripts/run-doc-link-lint.js','scripts/python~/pyproject.toml','scripts/python~/uv.lock','package.json','scripts/comment-stripping.ps1']
sources += [str(out.relative_to(root)/name) for name in ['lint-doc-links.original.ps1','doc-links-original-suite-timing.ps1']]
def hashes():return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sources}
seal=hashes();results=[]
commands={'original':['pwsh','-NoProfile','-File',str(out/'doc-links-original-suite-timing.ps1')],'python':['uv','run','--quiet','--project','scripts/python~','--locked','pytest','scripts/tests/test_doc_links.py','-q']}
for index in range(1,4):
 for arm in ['original','python']:
  assert hashes()==seal
  start=time.perf_counter_ns()
  process=subprocess.Popen(commands[arm],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  stdout,stderr=process.communicate(timeout=180)
  elapsed=time.perf_counter_ns()-start
  assert hashes()==seal
  (out/f'doc-link-suite-{arm}-{index}.stdout').write_bytes(stdout)
  (out/f'doc-link-suite-{arm}-{index}.stderr').write_bytes(stderr)
  text=stdout.decode('utf-8-sig');assert process.returncode==0,(arm,text,stderr)
  assert ('90 passed' in text if arm=='python' else 'Tests passed: 51' in text),(arm,text[-800:])
  results.append({'arm':arm,'index':index,'pid':process.pid,'exitCode':process.returncode,'nanoseconds':elapsed,'stdoutEof':True,'stderrEof':True,'sourcesStable':True,'command':commands[arm]})
  (out/'doc-link-suite-timing-live.json').write_text(json.dumps({'sources':seal,'results':results},indent=2)+'\n')
  print(arm,index,round(elapsed/1e9,3),flush=True)
(out/'doc-link-suite-timing.json').write_text(json.dumps({'sources':seal,'results':results},indent=2)+'\n')
