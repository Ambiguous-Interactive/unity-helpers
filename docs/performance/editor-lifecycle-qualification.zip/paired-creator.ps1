$ErrorActionPreference='Stop'
$repository=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project=Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113b-editor'
$pwsh=Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$source='Tests/Editor/Tools/AnimationCreatorWindowTests.cs'
@{pid=$PID;startUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content(Join-Path $PSScriptRoot 'paired-creator-identity.json')
$fixed=@('Runtime/Utils/Buffers.cs','Runtime/Utils/RollingHighWaterMark.cs','Runtime/Utils/PoolPurgeSettings.cs')
$fixedHashes=@{};foreach($f in $fixed){$fixedHashes[$f]=(Get-FileHash(Join-Path $repository $f)).Hash}
$records=@();$canonical=$null;$code=1
try {
 $sequence=@('baseline','candidate','candidate','baseline','baseline','candidate')
 for($index=0;$index -lt $sequence.Count;$index++){
  $variant=$sequence[$index];$number=$index+1
  [IO.File]::WriteAllBytes((Join-Path $repository $source),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "AnimationCreatorWindowTests.$variant-measured.cs.txt")))
  $before=(Get-FileHash(Join-Path $repository $source)).Hash
  foreach($f in $fixed){if((Get-FileHash(Join-Path $repository $f)).Hash -ne $fixedHashes[$f]){throw "Fixed source changed before capture: $f"}}
  $artifacts=Join-Path $PSScriptRoot "creator-paired-$number-$variant"
  & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Editor.Tools' -TestFilter 'WallstopStudios.UnityHelpers.Tests.Tools.AnimationCreatorWindowTests' -TestCategory '!Performance;!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot "creator-paired-$number-$variant-driver.log")
  if($LASTEXITCODE -ne 0){throw "Native creator command failed: $number/$variant exit $LASTEXITCODE"}
  [xml]$xml=Get-Content(Join-Path $artifacts 'results.xml') -Raw
  $cases=@($xml.SelectNodes('//test-case'))
  if($cases.Count -ne 150 -or @($cases|Where-Object result -ne 'Passed').Count -or @($xml.SelectNodes('//test-suite[@result="Failed"]')).Count){throw 'Missing or failing case/suite'}
  $ids=@($cases|ForEach-Object fullname|Sort-Object)
  if($null -eq $canonical){$canonical=$ids}else{if(Compare-Object $canonical $ids){throw 'Different case identities'}}
  $receipt=Get-Content(Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw|ConvertFrom-Json
  $healthy=$receipt.Process.RawExitCode -eq 0 -and $receipt.Process.StandardOutputEndObserved -and $receipt.Process.StandardErrorEndObserved -and -not $receipt.Process.OutputDrainStopped
  if(-not $healthy){throw 'Unhealthy process/output receipt'}
  $text=Get-Content(Join-Path $artifacts 'results.xml') -Raw
  $module=[regex]::Match($text,'CREATOR_MODULE,([0-9a-f-]{36})').Groups[1].Value
  $dll=Join-Path $project 'Library/ScriptAssemblies/WallstopStudios.UnityHelpers.Tests.Editor.Tools.dll'
  $stream=[IO.File]::OpenRead($dll)
  try{$pe=[Reflection.PortableExecutable.PEReader]::new($stream);try{$metadata=[Reflection.Metadata.PEReaderExtensions]::GetMetadataReader($pe);$built=$metadata.GetGuid($metadata.GetModuleDefinition().Mvid).ToString()}finally{$pe.Dispose()}}finally{$stream.Dispose()}
  if($module -cne $built){throw 'Loaded test MVID differs from captured DLL'}
  Copy-Item $dll (Join-Path $artifacts 'qualified-tests.dll')
  $after=(Get-FileHash(Join-Path $repository $source)).Hash
  if($after -ne $before){throw 'Fixture source changed during capture'}
  foreach($f in $fixed){if((Get-FileHash(Join-Path $repository $f)).Hash -ne $fixedHashes[$f]){throw "Fixed source changed during capture: $f"}}
  $fixture=$xml.SelectSingleNode('//test-suite[@type="TestFixture"]')
  $caseSum=0.0;foreach($c in $cases){$caseSum += [double]::Parse($c.duration,[Globalization.CultureInfo]::InvariantCulture)}
  $records+=@{index=$number;variant=$variant;cases=$ids;healthy=$healthy;module=$module;dllSha256=(Get-FileHash $dll).Hash;before=$before;after=$after;fixtureSeconds=[double]::Parse($fixture.duration,[Globalization.CultureInfo]::InvariantCulture);caseSumSeconds=$caseSum}
  $records|ConvertTo-Json -Depth 8|Set-Content(Join-Path $PSScriptRoot 'paired-creator-live.json')
 }
 $code=0
}catch{$_|Out-String|Set-Content(Join-Path $PSScriptRoot 'paired-creator-controller.log')}
finally{
 [IO.File]::WriteAllBytes((Join-Path $repository $source),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'AnimationCreatorWindowTests.candidate-measured.cs.txt')))
 @{exitCode=$code;records=$records;fixedHashes=$fixedHashes;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json -Depth 8|Set-Content(Join-Path $PSScriptRoot 'paired-creator-result.json')
}
exit $code
