$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113b-editor'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
@{pid=$PID;startUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content(Join-Path $PSScriptRoot 'editor-animation-final-identity.json')
$inputs=@('Tests/Editor/Tools/AnimationCreatorWindowTests.cs','Tests/Editor/Tools/AnimationEventEditorViewModelTests.cs','Tests/Core/SynchronousEditorTestBase.cs','Runtime/TestSupport/UnityObjectTrackingTestBase.cs')
$before=@{};foreach($source in $inputs){$before[$source]=(Get-FileHash(Join-Path $repository $source)).Hash}
$code=1
try {
 $artifacts=Join-Path $PSScriptRoot 'editor-animation-final'
 & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Editor.Tools' -TestFilter 'WallstopStudios.UnityHelpers.Tests.Tools.AnimationCreatorWindowTests;WallstopStudios.UnityHelpers.Tests.Tools.AnimationEventEditorViewModelTests' -TestCategory '!Performance;!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot 'editor-animation-final-driver.log')
 if($LASTEXITCODE -ne 0){throw "Native tests failed $LASTEXITCODE"}
 [xml]$xml=Get-Content(Join-Path $artifacts 'results.xml') -Raw
 $cases=@($xml.SelectNodes('//test-case'))
 if($cases.Count -ne 175 -or @($cases|Where-Object result -ne 'Passed').Count -or @($xml.SelectNodes('//test-suite[@result="Failed"]')).Count){throw 'Missing or failing cases/suites'}
 $receipt=Get-Content(Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw|ConvertFrom-Json
 if($receipt.Process.RawExitCode -ne 0 -or -not $receipt.Process.StandardOutputEndObserved -or -not $receipt.Process.StandardErrorEndObserved -or $receipt.Process.OutputDrainStopped){throw 'Unhealthy process receipt'}
 $after=@{};foreach($source in $inputs){$after[$source]=(Get-FileHash(Join-Path $repository $source)).Hash;if($after[$source] -ne $before[$source]){throw 'Input source changed'}}
 $code=0
} catch { $_|Out-String|Set-Content(Join-Path $PSScriptRoot 'editor-animation-final-controller.log') }
finally { @{exitCode=$code;before=$before;after=$after;caseCount=$cases.Count;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json -Depth 6|Set-Content(Join-Path $PSScriptRoot 'editor-animation-final-result.json') }
exit $code
