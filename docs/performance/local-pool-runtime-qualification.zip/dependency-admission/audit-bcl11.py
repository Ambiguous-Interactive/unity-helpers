from pathlib import Path
import hashlib, json, urllib.request, zipfile, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent/'bcl11-admission';root.mkdir(exist_ok=True)
records=[]
for package in ['microsoft.bcl.asyncinterfaces','system.io.pipelines','system.text.encodings.web','system.text.json','system.collections.immutable']:
 url=f'https://api.nuget.org/v3-flatcontainer/{package}/11.0.0/{package}.11.0.0.nupkg'
 with urllib.request.urlopen(url,timeout=30) as response: data=response.read(32*1024*1024+1)
 if len(data)>32*1024*1024: raise RuntimeError('Unexpected oversized NuGet package')
 archive=root/(package+'.11.0.0.nupkg');archive.write_bytes(data)
 with zipfile.ZipFile(archive) as z:
  spec=ET.fromstring(z.read(next(n for n in z.namelist() if n.endswith('.nuspec'))))
  groups=[]
  for g in spec.findall('.//{*}group'):
   groups.append({'framework':g.get('targetFramework'),'dependencies':[d.attrib for d in g]})
  selected=[n for n in z.namelist() if n.startswith('lib/netstandard2.0/') and n.endswith(('.dll','.xml'))]
  assets={}
  for name in selected:
   payload=z.read(name);target=root/Path(name).name;target.write_bytes(payload);assets[name]=hashlib.sha256(payload).hexdigest()
  record={'package':package,'version':'11.0.0','url':url,'packageSha256':hashlib.sha256(data).hexdigest(),'groups':groups,'assets':assets,'runtimeQualification':False}
  records.append(record)
 (root/'admission.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps([{'package':r['package'],'netstandardAssets':list(r['assets']),'groups':r['groups']} for r in records],indent=2))
