#Requires -Version 5.1
[CmdletBinding(PositionalBinding = $false)]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d+\.\d+\.\d+f\d+$')]
    [string]$UnityVersion,

    [Parameter(Mandatory = $true)]
    [ValidateSet('editmode', 'playmode', 'standalone', 'export')]
    [string]$TestMode,

    [string]$AssemblyNames,

    [string]$LicenseSessionPath = '',

    [switch]$PrepareLicenseOnly,

    [string]$ExportPackagePath,

    [Parameter(Mandatory = $true)]
    [string]$ArtifactsPath,

    [string]$RepoRoot = $(if ($env:GITHUB_WORKSPACE) { $env:GITHUB_WORKSPACE } else { (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path }),

    [string]$ProjectPath,

    # Distinguishes generated projects that share a <version>-<mode> pair but are
    # compiled DIFFERENTLY -- today the SINGLE_THREADED and benchmark legs. Two
    # differently compiled Libraries must never share a directory, or each leg
    # invalidates the other's compiled assemblies on every run. Constrained to a
    # bare directory-name shape: this becomes a path segment, and a separator in it
    # would place the project outside the root the disk guard prunes.
    [ValidatePattern('^[A-Za-z0-9._-]*$')]
    [string]$ProjectScope,

    # EditMode and PlayMode run serially with the same package manifest and
    # scripting defines, so they can reuse one generated project's Library.
    # Standalone keeps its own project because it changes player build settings.
    [switch]$ShareEditorProject,

    # Root for the generated project and the UPM caches, OUTSIDE the repository.
    # CI sets this to a per-runner directory so `actions/checkout`'s
    # `git clean -ffdx` (which deletes the gitignored .artifacts tree, Library and
    # all) structurally cannot reach it. Unset locally: the project stays under
    # .artifacts/ where a developer expects a `git clean` to remove it.
    [string]$ProjectRoot = $env:UH_UNITY_PROJECT_ROOT,

    # Free-space floor for -ProjectRoot's volume, in GB. Below it, least-recently-
    # used sibling projects are deleted before this leg runs. Ignored when the
    # project is not persistent.
    [double]$ProjectRootMinimumFreeGb = 60,

    [string]$UnityEditorPath = $env:UNITY_EDITOR_PATH,

    [string]$TestFilter = '',

    [switch]$IsolateCompilationFixtures,

    [ValidateSet('All', 'Main', 'Isolated')]
    [string]$EditorPhaseGroup = 'All',

    # Optional diagnostic frozen-file/player provenance. No measurement eligibility.
    [string]$FrozenPlayerDeclarationPath = '',

    [ValidateSet('None', 'Direct', 'Debugger')]
    [string]$StandaloneBuildCapture = 'None',

    [switch]$StandaloneBuildDebuggerStandardHeap,

    [switch]$StandaloneBuildAttachToDirect,

    [switch]$StandaloneBuildAttachAfterStartup,

    [switch]$StandaloneBuildAttachAfterShutdown,

    [string]$TestCategory = $(if ($env:UH_UNITY_TEST_CATEGORY) { $env:UH_UNITY_TEST_CATEGORY } else { '' }),

    [switch]$IncludeComparisons,

    # Install the third-party DI-container packages (Reflex / VContainer / Zenject-
    # Extenject) from .github/integration-packages.json + the OpenUPM scoped
    # registry into the ephemeral manifest, so the Runtime/Integrations and
    # Tests/{Editor,Runtime}/Integrations asmdefs (gated on REFLEX_PRESENT /
    # VCONTAINER_PRESENT / ZENJECT_PRESENT versionDefines) compile and their tests
    # run. The integration test ASSEMBLIES must additionally be added to
    # -AssemblyNames by the caller (compute-unity-assemblies include-integrations).
    [switch]$IncludeIntegrations,

    # Extra GLOBAL scripting define symbols compiled into EVERY assembly (asmdef
    # assemblies included), e.g. SINGLE_THREADED to exercise the single-threaded
    # code paths. Empty by default so the DEFAULT (multi-threaded) behavior is
    # unchanged. Applied via a configure pass that sets PlayerSettings scripting
    # defines and lets Unity persist them BEFORE the -runTests pass loads the
    # project, because Unity in -batchmode does NOT recompile when defines change
    # mid-run -- the symbols must be in place from editor startup (Unity issue
    # tracker: define edits before project open are honored from 2021.1+, which the
    # Unity-6-only single-threaded leg satisfies). See New-ConfiguratorSource and
    # the configure-pass dispatch below.
    [string[]]$AdditionalScriptingDefines = @(),

    [switch]$ReleaseCodeOptimization,

    [ValidateSet('IL2CPP', 'Mono2x')]
    [string]$StandaloneScriptingBackend = 'IL2CPP',

    [ValidateSet('Disabled', 'Low', 'Medium', 'High')]
    [string]$ManagedStrippingLevel = 'Disabled',

    [switch]$EnableEditorGraphics,

    [switch]$ReleasePlayerBuild,

    [switch]$ForceFreshCompilationCache,

    # IL2CPP C++ compiler configuration for the standalone player build. 'Release' is
    # what CI passes on every leg: it is what a shipped player runs, so it is what the
    # IL2CPP-compat leg should validate, and 'Debug' costs real time -- the standalone
    # legs execute the same suite roughly 2x slower than the editor's Mono JIT (run
    # 31221618477: 2021.3 203.3s vs 91.7s, 6000.3 314.1s vs 122.1s).
    #
    # 'Debug' remains the escape hatch, and it was needed once. On run 31280555886 the
    # runners carried MSVC 14.51.36231 and all four standalone legs died with:
    #
    #   WallstopStudios.UnityHelpers.Tests.Runtime__13.cpp(8962):
    #       fatal error C1001: Internal compiler error.
    #
    # MSVC 14.51.36231 (VS 2026) at /Ox, Unity 6000.5.2f1, with the SSA common-
    # subexpression workaround flag already on the command line.
    #
    # Note the translation unit: it is the TEST assembly's generated C++, so this is a
    # property of compiling 8,700 tests into one player. That is evidence the ICE has
    # not been reproduced for a package-only build -- it is NOT proof a consumer is
    # safe, because IL2CPP inlines across assemblies and package code can land in that
    # same translation unit.
    #
    # That retry was run, and it failed. Run 31286672790 (2026-08-09), after the runners
    # were updated, still resolved MSVC 14.51.36231 -- the update did not move the
    # toolset Unity selects. Two translation units ICEd on the 2022.3 leg, not one:
    #
    #   WallstopStudios.UnityHelpers.Tests.Runtime__13.cpp(18446)
    #   WallstopStudios.UnityHelpers.Tests.Runtime__14.cpp(5076)
    #       fatal error C1001: Internal compiler error.
    #       (compiler file '...\Compiler\Utc\src\p2\main.cpp', line 262)
    #
    # Same compiler file and line as run 31280555886, so it is the same optimizer defect.
    # The line numbers moved (8962 -> 18446/5076) because the generated C++ shifted when
    # tests were added, not because anything in our source provokes it.
    #
    # STEERING THE TOOLSET WAS TRIED AND IS DISPROVEN. Both runners carry 14.42.34433
    # and 14.44.35207 beside the crashing 14.51.36231, which is merely the DEFAULT of the
    # Visual Studio 2026 installation Unity resolves -- so f4d1d040 set the environment
    # variable VCToolsVersion=14.44.35207 on every tier and restored 'Release'.
    #
    # Run 31288591021 answered it. The variable WAS set (it is in the job log), and the
    # compiler that ran anyway was:
    #
    #   ...\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe
    #
    # followed by the same C1001, twice. VCToolsVersion is an MSBuild/vcvars mechanism;
    # Bee resolves cl.exe itself and invokes it by absolute path, so the variable never
    # reaches the compile. The env var has been removed rather than left inert, because a
    # no-op that looks load-bearing is worse than no attempt at all.
    #
    # HOW BEE PICKS A TOOLSET, MEASURED (run 31290048422, 2026-08-09). This is the useful
    # result of the whole investigation, so it is written down rather than re-derived.
    #
    # VS 2026's Microsoft.VCToolsVersion.default.txt was repointed to 14.44.35207 on the
    # runners. msvc-toolchains.txt in that run's artifact confirms the repoint took:
    #
    #   Visual Studio Community 2026 (18.8.12023.21)
    #     default   = 14.44.35207
    #     installed = [14.42.34433, 14.44.35207, 14.51.36231]
    #
    # And Bee invoked ...\Tools\MSVC\14.51.36231\...\cl.exe anyway, then ICEd.
    #
    # So Bee does NOT read the default file. It enumerates VC\Tools\MSVC and takes the
    # HIGHEST version directory. Two consequences worth keeping:
    #
    #   * Repointing the default can never work, and neither can VCToolsVersion (already
    #     disproven, run 31288591021). Nothing that merely expresses a preference works.
    #   * The only install-side fix is to make 14.51 not exist on the box -- remove the
    #     v145 component from VS 2026, or remove its C++ workload so Unity resolves the
    #     2022 Build Tools installation, whose highest is 14.44.35207.
    #
    # THE DIRECTORY IS GONE (2026-08-09). 14.51.36231 was removed from both runners --
    # uninstalling the component alone did not delete it, so the directory was removed by
    # hand, and the C++ workload was then reinstalled on every Visual Studio. Both hosts
    # now top out at 14.44.35207. 'Release' is pinned again to test the one hypothesis
    # that survives: Bee takes the highest directory, and the highest is no longer the
    # one that ICEs.
    #
    # Known wrinkle, believed harmless: VS 2026's Microsoft.VCToolsVersion.default.txt
    # still names 14.51.36231, a directory that no longer exists. Bee is measured not to
    # read that file (run 31290048422), so it should not matter -- but if a leg fails
    # with a missing-toolset error rather than C1001, that dangling default is the first
    # suspect, and repointing it to 14.44.35207 is the fix.
    #
    # Check msvc-toolchains.txt in the artifact before the build result, as always: it
    # reports the installed directories, so it says whether the removal survived the
    # workload reinstall independently of whether the compile succeeded.
    #
    # If this ICEs on 14.44, the toolset is exonerated entirely and the defect is not
    # version-specific. Set both call sites in unity-tests.yml back to
    # `${{ matrix.test-mode == 'standalone' && 'Debug' || 'Release' }}` and the remaining
    # lever is PlayerSettings.SetAdditionalIl2CppArgs with --compiler-flags="/O1". See #374.
    #
    # THE DEFAULT FILE IS IGNORED TOO. The administrator repoint landed -- run 31290048422
    # shows, on the very host that then failed:
    #
    #   Visual Studio Community 2026  default=14.44.35207
    #                                 installed=[14.42.34433, 14.44.35207, 14.51.36231]
    #
    # and the compiler that ran was still ...\Tools\MSVC\14.51.36231\bin, with C1001 four
    # times. So Bee reads neither the environment variable nor the installation's declared
    # default; it resolves the highest version directory present under VC\Tools\MSVC.
    #
    # That narrows the remaining runner-side fix to exactly one action: UNINSTALL
    # 14.51.36231 from VS 2026. Un-defaulting it is not enough, and has now been measured
    # not to be enough. Note also what this does NOT show: 14.51 is not exonerated by the
    # repoint failing, because 14.51 is what compiled -- the toolset has never actually
    # been swapped out under an IL2CPP build.
    #
    # The general lesson, and the reason the check is written down: confirm which compiler
    # actually ran from the cl.exe path in the log, never from the env var being set. The
    # two disagreed here, and only the log said so.
    #
    # Inert for editmode/playmode and Mono (no IL2CPP player is built).
    [ValidateSet('Release', 'Debug')]
    [string]$Il2CppCompilerConfiguration = 'Release',

    [switch]$GenerateOnly,

    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$UnboundArguments
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'lib/compilation-fixture-results.ps1')
. (Join-Path $PSScriptRoot 'lib/license-session.ps1')
. (Join-Path $PSScriptRoot 'lib/test-result-evidence.ps1')
. (Join-Path $PSScriptRoot 'lib/wproto-player-provenance.ps1')
if ($IsolateCompilationFixtures -and $TestMode -ne 'editmode') {
    throw 'Compilation fixture isolation requires EditMode.'
}

# Adding a ValueFromRemainingArguments parameter is NOT enough on its own: with positional
# binding on, `pwsh -File <script> -AdditionalScriptingDefines a b` binds 'b' to whichever named
# parameter is positionally next, and the catch-all never sees it. Measured, not assumed.
# PositionalBinding = $false on the param block above is what makes every stray value land
# here; this then refuses it rather than guessing which array parameter it belonged to.
# Pass a comma-separated list instead. See .llm/skills/bash-pwsh-invocation.md.
if ($UnboundArguments -and 0 -lt $UnboundArguments.Count) {
    # Not Write-Error: under $ErrorActionPreference = 'Stop' that terminates with exit 1, so
    # the exit code would depend on where in the file this guard happens to sit. 64 is sysexits.h
    # EX_USAGE and, unlike 1 or 2, is not already used by these scripts for a real failure.
    [Console]::Error.WriteLine(
        "Unbound arguments: $($UnboundArguments -join ', '). Pass a comma-separated list " +
        "(-AdditionalScriptingDefines a,b,c) rather than space-separated values."
    )
    exit 64
}

if ($StandaloneBuildCapture -ne 'None' -and ($TestMode -ne 'standalone' -or $GenerateOnly -or [string]::IsNullOrWhiteSpace($FrozenPlayerDeclarationPath))) {
    throw 'Standalone build capture requires Standalone mode and a frozen declaration; it never runs the player.'
}

if ($StandaloneBuildDebuggerStandardHeap -and $StandaloneBuildCapture -ne 'Debugger') {
    throw 'Standard heap selection requires an evidence-only Standalone debugger build.'
}
if ($StandaloneBuildAttachToDirect -and ($StandaloneBuildCapture -ne 'Debugger' -or $StandaloneBuildDebuggerStandardHeap)) {
    throw 'Direct attachment requires the evidence-only debugger arm without a debugger launch heap request.'
}
if ($StandaloneBuildAttachAfterStartup -and -not $StandaloneBuildAttachToDirect) { throw 'Startup-delayed attachment requires Direct attachment.' }
if ($StandaloneBuildAttachAfterShutdown -and (-not $StandaloneBuildAttachToDirect -or $StandaloneBuildAttachAfterStartup)) { throw 'Shutdown-delayed attachment requires Direct attachment without startup selection.' }

if ($ForceFreshCompilationCache -and ($TestMode -ne 'standalone' -or $StandaloneScriptingBackend -ne 'IL2CPP')) {
    throw 'ForceFreshCompilationCache requires Standalone IL2CPP mode.'
}

# PowerShell 7.4 introduced $PSNativeCommandUseErrorActionPreference (stabilizing
# the native-error experimental feature). Its default is $false on current builds,
# so `& <native>` does NOT throw on a non-zero exit and our explicit checks run as
# written. However, a host profile or a future/different build could enable it,
# which would make `& <native>` THROW on a non-zero exit BEFORE our explicit
# `$LASTEXITCODE` check runs -- short-circuiting Invoke-UnityEditor's exit-code
# diagnostic and making the best-effort license return rely on its catch block
# instead of finishing. Pinning it $false makes LASTEXITCODE-based handling
# authoritative and identical across hosts/versions. (PS 5.1 lacks this variable;
# assigning it there is harmless, and the assignment is StrictMode-safe.)
$PSNativeCommandUseErrorActionPreference = $false

$PackageName = 'com.wallstop-studios.unity-helpers'
# Unity Accelerator (cache server) helpers live in a dot-sourceable library so
# they can be unit-tested with plain pwsh (run-ci-tests.ps1 itself has a
# mandatory param() block and a main, so it cannot be dot-sourced). This MUST
# happen before the Get-AcceleratorArguments call site and before any function
# that references ConvertTo-NormalizedAcceleratorEndpoint / Get-AcceleratorArguments
# / Test-AcceleratorReachable.
. (Join-Path $PSScriptRoot 'lib/accelerator.ps1')

# Single source of truth for the catastrophic-pattern list (shared with the two
# composite actions via Get-CatastrophicPatterns). Dot-sourced here; the array is
# assigned to $script:CatastrophicPatterns below.
. (Join-Path $PSScriptRoot 'lib/catastrophic-patterns.ps1')
. (Join-Path $PSScriptRoot 'lib/credential-redaction.ps1')
. (Join-Path $PSScriptRoot 'lib/native-evidence.ps1')
. (Join-Path $PSScriptRoot 'lib/test-framework-evidence.ps1')

# Resolves WHERE the generated project and its Library live, and prunes the
# persistent root when a self-hosted runner's disk gets tight. Dot-sourced for
# the same reason as the two libraries above.
. (Join-Path $PSScriptRoot 'lib/project-workspace.ps1')

function Write-CiError {
    param([Parameter(Mandatory = $true)][string]$Message)
    Write-Host "::error::$Message"
}

function Write-CiNotice {
    param([Parameter(Mandatory = $true)][string]$Message)
    Write-Host "::notice::$Message"
}

function Write-CiWarning {
    param([Parameter(Mandatory = $true)][string]$Message)
    Write-Host "::warning::$Message"
}

function Assert-NoUnityCompilerWarnings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$LogPath,
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$PackageRoot,
        [int]$MaximumReported = 25
    )

    if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        throw "$Label compiler-warning gate could not read '$LogPath'."
    }

    # A Unity project can contain third-party dependencies and this repository's own test
    # assemblies. Neither is shipped to package consumers. Gate the package's production source,
    # opt-in samples, and the small generated CI harness instead of claiming ownership of every
    # warning emitted anywhere in the host project.
    $packageRoot = [System.IO.Path]::GetFullPath($PackageRoot).TrimEnd('/', '\')
    $escapedPackageRoot = [regex]::Escape($packageRoot) -replace '(?:\\/|/)','[\\/]'
    $diagnosticSuffix = '\.cs\(\d+(?:,\d+){0,3}\):\s*warning\s+[A-Z][A-Z0-9]*\d{3,4}\s*:'
    $ownedSourcePattern = '(?i)(?:' +
        $escapedPackageRoot + '[\\/](?:Runtime|Editor|Styles|Samples~?)[\\/]|' +
        'Packages[\\/]com\.wallstop-studios\.unity-helpers[\\/](?:Runtime|Editor|Styles|Samples~?)[\\/]|' +
        'Library[\\/]PackageCache[\\/]com\.wallstop-studios\.unity-helpers(?:@[^\\/]+)?[\\/](?:Runtime|Editor|Styles|Samples~?)[\\/]|' +
        'Assets[\\/]WallstopStudios[\\/]UnityHelpers[\\/](?:Runtime|Editor|Styles|Samples)[\\/]|' +
        '^(?:Runtime|Editor|Styles|Samples~?)[\\/])[^\r\n]*?' + $diagnosticSuffix
    $harnessPattern = '(?i)Assets[\\/]Editor[\\/](?:UhCi[^\\/]*|UnityHelpersPackageExporter)' + $diagnosticSuffix
    $generatedSourcePattern = '(?i)Library[\\/]Bee[\\/][^\r\n]*WallstopStudios\.UnityHelpers(?![A-Za-z0-9_])[^\r\n]*?' + $diagnosticSuffix
    $sourceLessDiagnosticPrefix = '(?i)^\s*(?:[^\r\n]*?\bCSC\s*:\s*)?warning\s+[A-Z][A-Z0-9]*\d{3,4}\s*:'
    $packageAttributedSourceLessPattern = $sourceLessDiagnosticPrefix + '[^\r\n]*(?:WallstopStudios\.UnityHelpers(?![A-Za-z0-9_])|com\.wallstop-studios\.unity-helpers(?![A-Za-z0-9_-]))'
    $logLines = @(Get-Content -LiteralPath $LogPath -ErrorAction Stop)
    $warnings = @(
        $logLines |
            Where-Object {
                $_ -notmatch '(?i)[\\/]Tests[\\/]' -and
                ($_ -match $ownedSourcePattern -or $_ -match $harnessPattern -or $_ -match $generatedSourcePattern -or $_ -match $packageAttributedSourceLessPattern)
            } |
            ForEach-Object { ("$_").Trim() } |
            Sort-Object -Unique
    )

    Write-Host "[compiler-warnings] Scanned $($logLines.Count) $Label log line(s); found $($warnings.Count) unique package, sample, or CI-harness compiler warning(s)."
    if ($warnings.Count -lt 1) {
        return
    }

    foreach ($warning in @($warnings | Select-Object -First $MaximumReported)) {
        Write-CiError "$Label emitted a compiler warning: $(ConvertTo-UnitySafeLogText -Text $warning)"
    }
    if ($MaximumReported -lt $warnings.Count) {
        Write-CiError "$Label emitted $($warnings.Count - $MaximumReported) additional unique compiler warning(s); inspect $LogPath."
    }
    throw "$Label emitted $($warnings.Count) unique package, sample, or CI-harness compiler warning(s). Unity CI requires zero client-visible warnings on every supported editor."
}

# SINGLE SOURCE OF TRUTH for the catastrophic-pattern list that both
# Write-UnityCatastrophicErrorAnnotations (new ::error:: annotation surface)
# AND Write-UnityResultFailureDiagnostics (older line-numbered selected-line
# printer) scan for. Each entry has:
#   Label    : human-readable label written into the GitHub group/error line
#   Pattern  : the Select-String pattern (regex when UseSimple=false, literal
#              substring when UseSimple=true)
#   UseSimple: whether to invoke Select-String -SimpleMatch (literal substring,
#              cheaper) or as a regex
# Keeping this at $script: scope keeps the array deterministic and shared
# even when callers run from inside a try/finally or a child function.
#
# Patterns covered:
#   - PrecompiledAssemblyException -- "Multiple precompiled assemblies with
#     the same name" (the analyzer-DLL duplicate that motivated this
#     diagnostic; the runtime auto-copy that caused it has been removed).
#   - CompilationFailedException -- generic compile-failure path.
#   - error CS\d+ -- compiler errors (CS0246, CS0103, CS0117, etc).
#   - warning CS8032 -- "An instance of analyzer cannot be created" (analyzer
#     failed to instantiate; same class of issue).
#   - Package [id] cannot be found -- the test-project manifest declares a
#     UPM package id that does not exist (e.g. the non-existent
#     'com.unity.modules.grid'; declare com.unity.modules.tilemap for Grid usage).
#     UPM aborts resolution BEFORE compilation, so Unity exits non-zero with no
#     results.xml and no CS#### line. This pattern NAMES the offending id so the
#     operator does not have to read the raw Unity log; the fast
#     scripts/lint-unity-test-modules.ps1 lint is the pre-Unity guard that should
#     catch it first. NON-transient (a bad manifest, not a flaky UPM channel), so
#     it is a catastrophic pattern, not a retry signal.
#   - WaitForEndOfFrame "not evoked in batchmode" -- a [UnityTest] (or a coroutine it
#     drives) yielded WaitForEndOfFrame, which never resumes under -batchmode
#     -nographics. The PlayMode coroutine stalls and Unity Test Framework writes a
#     misleading total=0 results.xml (a generic "unexpected log" scan otherwise
#     mis-points at unrelated LogAssert-guarded errors). NON-transient; the
#     scripts/lint-tests.ps1 UNH012 rule is the pre-Unity guard that catches it first.
# Loaded from the single source of truth (scripts/unity/lib/catastrophic-patterns.ps1,
# dot-sourced above). Wrapped in @() so a single-entry future list stays an array.
$script:CatastrophicPatterns = @(Get-CatastrophicPatterns)

# CLASS-OF-ISSUE DIAGNOSTIC: when Unity exits non-zero, the operator's next
# question is "WHY did Unity fail?". The most common silent-killer answers are
# catastrophic compile-time errors -- the editor exits before running tests at
# all, leaving no NUnit XML. Surface these patterns as `::error::` annotations
# directly from the runner script so they ALWAYS show up in both the runner log
# and GitHub's error summary, independent of whether the workflow-level verify
# step also runs. Reusable at top-level so additional call sites can adopt it.
# Patterns come from the single-source-of-truth $script:CatastrophicPatterns
# array above; see Write-UnityResultFailureDiagnostics for the second consumer.
function Write-UnityCatastrophicErrorAnnotations {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$LogPath,
        [int]$MaxPerPattern = 5
    )

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return
    }

    foreach ($entry in $script:CatastrophicPatterns) {
        try {
            if ($entry.UseSimple) {
                $hits = @(
                    Select-String -LiteralPath $LogPath -SimpleMatch -Pattern $entry.Pattern -ErrorAction SilentlyContinue |
                        Select-Object -First $MaxPerPattern
                )
            } else {
                $hits = @(
                    Select-String -LiteralPath $LogPath -Pattern $entry.Pattern -ErrorAction SilentlyContinue |
                        Select-Object -First $MaxPerPattern
                )
            }
        } catch {
            # Best-effort; never throw from a diagnostic helper -- the caller is
            # already in the middle of a throw path.
            continue
        }

        if ($hits.Count -lt 1) {
            continue
        }

        Write-Host "::group::Catastrophic pattern: $($entry.Label)"
        foreach ($hit in $hits) {
            $line = ConvertTo-UnitySafeLogText -Text $hit.Line.Trim()
            Write-Host "::error::Pattern detected -- $($entry.Label):: $line"
            Write-Host "  $($hit.Path):$($hit.LineNumber): $line"
        }
        Write-Host "::endgroup::"
    }
}

# CLASS-OF-ISSUE DIAGNOSTIC: a leg whose tests all pass can still be running on a
# host whose Unity licensing client is broken. That leg then fails at
# return-unity-license, tens of minutes later, with an evidence classification that
# names the return rather than the cause (issue #657). The cause is in the editor
# log's first seconds. Emitted as ::warning::, never ::error::, because the suite
# result is honest and the fault is the machine's; NEVER throws, and the caller is
# not always on a failure path.
function Write-UnityEnvironmentWarningAnnotations {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$LogPath,
        [int]$MaxPerPattern = 3
    )

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        Write-Host "[environment-warnings] No editor log at '$LogPath'; nothing was scanned."
        return
    }

    $matched = 0
    foreach ($entry in @(Get-EnvironmentWarningPatterns)) {
        try {
            if ($entry.UseSimple) {
                $hits = @(
                    Select-String -LiteralPath $LogPath -SimpleMatch -Pattern $entry.Pattern -ErrorAction SilentlyContinue |
                        Select-Object -First $MaxPerPattern
                )
            } else {
                $hits = @(
                    Select-String -LiteralPath $LogPath -Pattern $entry.Pattern -ErrorAction SilentlyContinue |
                        Select-Object -First $MaxPerPattern
                )
            }
        } catch {
            continue
        }

        if ($hits.Count -lt 1) {
            continue
        }

        $matched = $matched + $hits.Count
        Write-Host "::group::Environment warning: $($entry.Label)"
        foreach ($hit in $hits) {
            $line = ConvertTo-UnitySafeLogText -Text $hit.Line.Trim()
            Write-Host "::warning::Runner environment -- $($entry.Label):: $line"
            Write-Host "  $($hit.Path):$($hit.LineNumber): $line"
        }
        Write-Host "::endgroup::"
    }

    # A scan that reports nothing must say it had something to look at, or "clean"
    # and "never ran" read identically (.llm/skills/honest-gates.md).
    $lineCount = @(Get-Content -LiteralPath $LogPath -ErrorAction SilentlyContinue).Count
    Write-Host "[environment-warnings] Scanned $lineCount log line(s) for $((Get-EnvironmentWarningPatterns).Count) pattern(s); $matched match(es)."
}

# CLASS-OF-ISSUE DIAGNOSTIC: a CS1069 "type ... forwarded to assembly
# 'UnityEngine.<X>Module'" (or its "Enable the built in package" sibling) and a
# CS0234 "'UI' does not exist in the namespace 'UnityEngine'" both mean the
# project manifest is MISSING a UnityEngine module/package the code uses -- the
# editor then fails compilation before any test runs and emits no NUnit
# results.xml. The raw CS#### line names the ASSEMBLY but NOT the UPM package id a
# human must add, so this best-effort scanner translates each missing module into
# the EXACT id to add to .github/unity-test-project-modules.json. The mapping is
# the (stable) Unity rule "UnityEngine.<Name>Module -> com.unity.modules.<name
# lowercased>" plus the one special case UnityEngine.UI -> com.unity.ugui, so it
# needs no lookup table and degrades gracefully for a module not seen before.
# NEVER throws (the caller is already on a failure path).
function Write-UnityMissingModuleAnnotations {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$LogPath,
        [int]$MaxModules = 25
    )

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return
    }

    # The "UnityEngine.<X>Module -> com.unity.modules.<x>" lowercase rule holds for
    # almost every module, but a handful of module assemblies have NO matching
    # com.unity.modules.<x> package id. Suggesting the naive lowercase id for those
    # (e.g. 'com.unity.modules.grid') tells the operator to add a non-existent id,
    # which makes UPM fail resolution ('Package [id] cannot be found') -- the exact
    # failure this diagnostic exists to prevent. Map those assemblies to the real
    # package id instead. See https://docs.unity3d.com/Manual/pack-build.html for
    # the authoritative list of real built-in package ids.
    $moduleAssemblyToPackage = @{
        'grid' = 'com.unity.modules.tilemap'  # UnityEngine.GridModule (Grid/GridLayout): no com.unity.modules.grid exists; declare com.unity.modules.tilemap.
    }
    $found = New-Object 'System.Collections.Generic.HashSet[string]'
    try {
        foreach ($hit in @(Select-String -LiteralPath $LogPath -Pattern 'forwarded to assembly [''"]?UnityEngine\.(\w+)Module' -ErrorAction SilentlyContinue)) {
            foreach ($m in $hit.Matches) {
                $assembly = $m.Groups[1].Value.ToLowerInvariant()
                if ($moduleAssemblyToPackage.ContainsKey($assembly)) {
                    [void]$found.Add($moduleAssemblyToPackage[$assembly])
                } else {
                    [void]$found.Add('com.unity.modules.' + $assembly)
                }
            }
        }
        # UnityEngine.UI (Image/Slider/ColorBlock) lives in the bundled com.unity.ugui
        # package, NOT a com.unity.modules.* built-in, and surfaces as CS0234 rather
        # than the CS1069 forward above.
        if (@(Select-String -LiteralPath $LogPath -Pattern "namespace name 'UI' does not exist in the namespace 'UnityEngine'" -ErrorAction SilentlyContinue).Count -gt 0) {
            [void]$found.Add('com.unity.ugui')
        }
    } catch {
        return
    }

    if ($found.Count -lt 1) {
        return
    }

    $modules = @($found | Sort-Object | Select-Object -First $MaxModules)
    Write-Host "::group::Missing Unity module dependencies"
    Write-Host "::error::Compilation referenced UnityEngine module(s) absent from the test-project manifest. Add to .github/unity-test-project-modules.json: $($modules -join ', ')"
    foreach ($id in $modules) {
        Write-Host "  - $id"
    }
    Write-Host "Both scripts/unity/run-ci-tests.ps1 (New-ManifestJson) and scripts/unity/create-test-project.sh consume that single source."
    Write-Host "::endgroup::"
}

function Test-UnityPackageManagerTransientFailure {
    param([string]$LogPath)

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return $false
    }

    try {
        $logText = Get-Content -LiteralPath $LogPath -Raw
    } catch {
        return $false
    }

    if (-not $logText) {
        return $false
    }

    return (
        $logText -match 'Cancelled resolving packages' -or
        $logText -match 'Failed to resolve packages:\s+operation cancelled' -or
        $logText -match 'IPCStream \(Upm-[^)]+\): IPC stream failed to read'
    )
}

function Test-UnityConfigurePackageManagerRetryableFailure {
    param([string]$LogPath)

    if (-not (Test-UnityPackageManagerTransientFailure -LogPath $LogPath)) {
        return $false
    }

    try {
        $logText = Get-Content -LiteralPath $LogPath -Raw
    } catch {
        return $false
    }

    # A configure can log an early UPM disconnect and still continue far enough to expose a real
    # compile/startup defect. Retry only when the UPM signal is the sole known failure class. The
    # shared catastrophic list keeps this exclusion aligned with the diagnostics that fail CI.
    foreach ($entry in $script:CatastrophicPatterns) {
        if ($entry.UseSimple) {
            if ($logText.IndexOf($entry.Pattern, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                return $false
            }
        } elseif ($logText -match $entry.Pattern) {
            return $false
        }
    }

    return $logText -notmatch 'Aborting batchmode'
}

function Write-UnityPackageManagerTransientFailureWarnings {
    param(
        [string]$LogPath,
        [int]$MaxLines = 12
    )

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return
    }

    $patterns = @(
        'Cancelled resolving packages',
        'Failed to resolve packages:\s+operation cancelled',
        'IPCStream \(Upm-[^)]+\): IPC stream failed to read'
    )

    try {
        $matches = @(
            Select-String -LiteralPath $LogPath -Pattern $patterns -ErrorAction SilentlyContinue |
                Select-Object -First $MaxLines
        )
    } catch {
        return
    }

    foreach ($match in $matches) {
        $line = ConvertTo-SingleLineDiagnostic -Text $match.Line
        Write-Host "::warning::Unity Package Manager transient package-resolution signal: $line"
    }
}

function Clear-UnityPackageManagerRetryState {
    param([Parameter(Mandatory = $true)][string]$Project)

    $packageCachePath = Join-Path $Project 'Library\PackageCache'
    $packageManagerPath = Join-Path $Project 'Library\PackageManager'
    $tempPath = Join-Path $Project 'Temp'
    $paths = @(
        $packageCachePath,
        $packageManagerPath,
        $tempPath
    )

    foreach ($envName in @('UPM_CACHE_ROOT', 'UPM_NPM_CACHE_PATH')) {
        $value = [Environment]::GetEnvironmentVariable($envName)
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            $paths += $value
        }
    }

    Write-Host "::group::Unity Package Manager retry cleanup"
    foreach ($path in ($paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)) {
        try {
            if (Test-Path -LiteralPath $path) {
                Write-Host "Removing $path"
                Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop
            } else {
                Write-Host "Already absent: $path"
            }
            New-Item -ItemType Directory -Force -Path $path -ErrorAction Stop | Out-Null
        } catch {
            Write-Host "::warning::Could not clear Unity Package Manager retry path '${path}': $($_.Exception.Message)"
        }
    }
    Write-Host "::endgroup::"
}

function Get-UnityCompilationCacheRepoRootComparison {
    if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
        return [System.StringComparison]::OrdinalIgnoreCase
    }

    return [System.StringComparison]::Ordinal
}

function Test-UnityCompilationCacheRepoRootMatch {
    param(
        [AllowNull()][string]$PreviousRepoRoot,
        [AllowNull()][string]$CurrentRepoRoot,
        [System.StringComparison]$Comparison = (Get-UnityCompilationCacheRepoRootComparison)
    )

    return [string]::Equals($PreviousRepoRoot, $CurrentRepoRoot, $Comparison)
}

function Get-UnityCompilationSourceInventory {
    param([Parameter(Mandatory = $true)][string]$RepoRoot)

    $normalizedRoot = [System.IO.Path]::GetFullPath($RepoRoot).TrimEnd(
        [System.IO.Path]::DirectorySeparatorChar,
        [System.IO.Path]::AltDirectorySeparatorChar
    )
    $sourceExtensions = @('.cs', '.asmdef', '.asmref', '.rsp')
    $inventoryEntries = @(
        # These are the source-bearing roots imported by the local UPM package and
        # its testable assemblies. Samples~/ and Generator~/ are not imported into
        # the ephemeral project and must not invalidate its warm compilation cache.
        foreach ($relativeRoot in @('Runtime', 'Editor', 'Styles', 'Tests')) {
            $sourceRoot = Join-Path $normalizedRoot $relativeRoot
            if (-not (Test-Path -LiteralPath $sourceRoot -PathType Container)) {
                continue
            }

            foreach ($source in @(Get-ChildItem -LiteralPath $sourceRoot -File -Recurse)) {
                if ($sourceExtensions -notcontains $source.Extension) {
                    continue
                }

                $fullPath = [System.IO.Path]::GetFullPath($source.FullName)
                $relativePath = $fullPath.Substring($normalizedRoot.Length).TrimStart(
                    [System.IO.Path]::DirectorySeparatorChar,
                    [System.IO.Path]::AltDirectorySeparatorChar
                )
                $relativePath.Replace([System.IO.Path]::DirectorySeparatorChar, '/')
            }
        }

        # Analyzer binaries and their Unity importer settings affect diagnostics without changing
        # a C# source path. Include both so a restored Library cannot silently reuse compilation
        # performed under a different warning policy.
        foreach ($relativePath in @(
                'Runtime/Analyzers/WallstopStudios.UnityHelpers.Analyzers.dll',
                'Runtime/Analyzers/WallstopStudios.UnityHelpers.Analyzers.dll.meta',
                'Runtime/Analyzers/WallstopStudios.UnityHelpers.Proto.Generator.dll',
                'Runtime/Analyzers/WallstopStudios.UnityHelpers.Proto.Generator.dll.meta',
                'Runtime/Analyzers/WallstopStudios.UnityHelpers.OdinMigration.Generator.dll',
                'Runtime/Analyzers/WallstopStudios.UnityHelpers.OdinMigration.Generator.dll.meta'
            )) {
            $fullPath = Join-Path $normalizedRoot $relativePath
            if (Test-Path -LiteralPath $fullPath -PathType Leaf) {
                $contentHash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash
                "$relativePath`t$contentHash"
            }
        }
    )

    return ((@('unity-compilation-inventory-v2') + @($inventoryEntries | Sort-Object -CaseSensitive)) -join "`n")
}

function Write-UnityCompilationSourceInventoryMarker {
    param(
        [Parameter(Mandatory = $true)][string]$Project,
        [Parameter(Mandatory = $true)][string]$RepoRoot
    )

    $libraryPath = Join-Path $Project 'Library'
    New-Item -ItemType Directory -Force -Path $libraryPath | Out-Null
    $sourceMarkerPath = Join-Path $libraryPath '.unity-helpers-source-inventory.txt'
    $currentSourceInventory = Get-UnityCompilationSourceInventory -RepoRoot $RepoRoot
    Set-Content -LiteralPath $sourceMarkerPath -Value $currentSourceInventory -Encoding utf8
    Write-Host "Wrote successful source-inventory marker: $sourceMarkerPath"
}

function Clear-StaleUnityCompilationCache {
    param(
        [Parameter(Mandatory = $true)][string]$Project,
        [Parameter(Mandatory = $true)][string]$RepoRoot,
        [switch]$Force
    )

    $libraryPath = Join-Path $Project 'Library'
    if (-not (Test-Path -LiteralPath $libraryPath -PathType Container)) {
        return
    }

    $markerPath = Join-Path $libraryPath '.unity-helpers-repo-root.txt'
    $sourceMarkerPath = Join-Path $libraryPath '.unity-helpers-source-inventory.txt'
    $currentRepoRoot = [System.IO.Path]::GetFullPath($RepoRoot).TrimEnd(
        [System.IO.Path]::DirectorySeparatorChar,
        [System.IO.Path]::AltDirectorySeparatorChar
    )
    $previousRepoRoot = ''
    if (Test-Path -LiteralPath $markerPath -PathType Leaf) {
        try {
            $previousRepoRoot = (Get-Content -LiteralPath $markerPath -Raw).Trim()
        } catch {
            $previousRepoRoot = ''
        }
    }

    $currentSourceInventory = Get-UnityCompilationSourceInventory -RepoRoot $RepoRoot
    $previousSourceInventory = $null
    if (Test-Path -LiteralPath $sourceMarkerPath -PathType Leaf) {
        try {
            $previousSourceInventory = (Get-Content -LiteralPath $sourceMarkerPath -Raw).Trim()
        } catch {
            $previousSourceInventory = $null
        }
    }

    $repoRootMatches = Test-UnityCompilationCacheRepoRootMatch `
        -PreviousRepoRoot $previousRepoRoot `
        -CurrentRepoRoot $currentRepoRoot
    $sourceInventoryMatches = (
        $null -ne $previousSourceInventory -and
        $previousSourceInventory -ceq $currentSourceInventory
    )
    if (-not $Force -and $repoRootMatches -and $sourceInventoryMatches) {
        return
    }

    $reasons = @()
    if ($Force) {
        $reasons += 'fresh compilation explicitly requested'
    }
    if (-not $repoRootMatches) {
        $reasons += if ([string]::IsNullOrWhiteSpace($previousRepoRoot)) {
            'repo-root marker is missing or unreadable'
        } else {
            "repo-root marker changed from '$previousRepoRoot' to '$currentRepoRoot'"
        }
    }
    if (-not $sourceInventoryMatches) {
        $reasons += if ($null -eq $previousSourceInventory) {
            'source-inventory marker is missing or unreadable'
        } else {
            'the package source path or analyzer inventory changed'
        }
    }

    Write-Host "::group::Unity compilation cache root check"
    Write-Host "Clearing Unity compilation cache because $($reasons -join '; ')."
    foreach ($relativePath in @(
            'Bee',
            'ScriptAssemblies',
            'PlayerScriptAssemblies',
            'Il2cppBuildCache'
        )) {
        $path = Join-Path $libraryPath $relativePath
        if (Test-Path -LiteralPath $path) {
            Write-Host "Removing $path"
            Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop
        } else {
            Write-Host "Already absent: $path"
        }
    }

    Set-Content -LiteralPath $markerPath -Value $currentRepoRoot -Encoding utf8
    Write-Host "Wrote repo-root marker: $markerPath"
    Write-Host "Deferring the source-inventory marker until Unity produces valid passing NUnit results."
    Write-Host "::endgroup::"
}

function Write-UnityPackageManagerDiagnostics {
    param(
        [string]$Project,
        [string]$LogPath
    )

    Write-Host "::group::Unity Package Manager diagnostics"
    try {
        foreach ($envName in @('UPM_CACHE_ROOT', 'UPM_NPM_CACHE_PATH', 'UPM_GIT_LFS_CACHE_PATH')) {
            Write-Host "${envName}: $([Environment]::GetEnvironmentVariable($envName))"
        }

        if ($Project) {
            foreach ($relativePath in @('Packages\manifest.json', 'Packages\packages-lock.json')) {
                $file = Join-Path $Project $relativePath
                if (Test-Path -LiteralPath $file -PathType Leaf) {
                    Write-Host "${relativePath}:"
                    Get-Content -LiteralPath $file -ErrorAction SilentlyContinue |
                        ForEach-Object { Write-Host "  $_" }
                } else {
                    Write-Host "${relativePath}: (missing)"
                }
            }

            $packageCache = Join-Path $Project 'Library\PackageCache'
            Write-Host "Library PackageCache: $packageCache"
            if (Test-Path -LiteralPath $packageCache -PathType Container) {
                Get-ChildItem -LiteralPath $packageCache -Force -ErrorAction SilentlyContinue |
                    Sort-Object Name |
                    Select-Object -First 80 |
                    ForEach-Object {
                        $kind = if ($_.PSIsContainer) { 'dir ' } else { 'file' }
                        Write-Host ("  [{0}] {1}" -f $kind, $_.Name)
                    }
            } else {
                Write-Host "  (missing)"
            }
        }

        if ($LogPath -and (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
            Write-Host "Package Manager failure log hits:"
            Select-String -LiteralPath $LogPath -Pattern @(
                'IPCStream \(Upm-[^)]+\): IPC stream failed to read',
                'Failed to resolve packages',
                'Cancelled resolving packages'
            ) -ErrorAction SilentlyContinue |
                Select-Object -First 40 |
                ForEach-Object {
                    Write-Host ("  line {0}: {1}" -f $_.LineNumber, (ConvertTo-UnitySafeLogText -Text $_.Line.Trim()))
                }
        }
    } catch {
        Write-Host "::warning::Could not collect Unity Package Manager diagnostics: $($_.Exception.Message)"
    }
    Write-Host "::endgroup::"
}

# The log line the Unity test runner emits once the run is over and results.xml has
# been flushed. Used as the completion sentinel so a Unity editor that deadlocks on
# shutdown AFTER this point is tree-killed within the grace window instead of blocking
# until the GitHub step's wall-clock timeout (the Unity 2021.3 -batchmode hang).
$script:EditorTestCompletionSentinel = 'Test run completed\. Exiting with code \d+'

function Get-EditorTestRunTimeoutSeconds {
    # Wall-clock backstop for a -runTests editor pass. The completion-sentinel grace is
    # the primary guard against the shutdown deadlock; this is the fallback for a run
    # that hangs WITHOUT ever logging completion (e.g. a mid-run deadlock or a compile
    # hang). MUST stay strictly BELOW the GitHub step's timeout-minutes for the
    # editmode/playmode legs (90 min in unity-tests.yml) so the watchdog tree-kills the
    # editor, persists the log, and returns the license seat BEFORE GitHub force-cancels
    # the job (which would lose the on-disk log and cascade the matrix). 4800s = 80 min
    # leaves 10 min of headroom. Honors UH_EDITOR_TEST_TIMEOUT_SECONDS; a non-integer or
    # negative override is ignored with a ::warning::; 0 is the explicit OPT-OUT
    # (unbounded). StrictMode-safe.
    param([int]$Default = 4800)

    if ($env:UH_EDITOR_TEST_TIMEOUT_SECONDS) {
        $parsed = 0
        if (
            [int]::TryParse($env:UH_EDITOR_TEST_TIMEOUT_SECONDS, [ref]$parsed) -and
            $parsed -ge 0
        ) {
            return $parsed
        }
        Write-Host "::warning::Ignoring invalid UH_EDITOR_TEST_TIMEOUT_SECONDS='$env:UH_EDITOR_TEST_TIMEOUT_SECONDS'; using $Default second(s)."
    }
    return $Default
}

function Get-EditorTestCompletionGraceSeconds {
    # How long to wait for the editor to exit on its own AFTER it logs the completion
    # sentinel before tree-killing it. Small (results are already written) but non-zero
    # so a normally-terminating editor is never killed mid-flush. Honors
    # UH_EDITOR_TEST_COMPLETION_GRACE_SECONDS; invalid/negative ignored with a
    # ::warning::; 0 means kill immediately on completion. StrictMode-safe.
    param([int]$Default = 120)

    if ($env:UH_EDITOR_TEST_COMPLETION_GRACE_SECONDS) {
        $parsed = 0
        if (
            [int]::TryParse($env:UH_EDITOR_TEST_COMPLETION_GRACE_SECONDS, [ref]$parsed) -and
            $parsed -ge 0
        ) {
            return $parsed
        }
        Write-Host "::warning::Ignoring invalid UH_EDITOR_TEST_COMPLETION_GRACE_SECONDS='$env:UH_EDITOR_TEST_COMPLETION_GRACE_SECONDS'; using $Default second(s)."
    }
    return $Default
}

function Get-EditorTestStallSeconds {
    # No-output stall window for a -runTests editor pass: tree-kill the editor if it emits
    # NO new log line for this many seconds WHILE TESTS ARE STILL RUNNING (before the
    # completion sentinel arms). This is the guard for a silent MID-RUN hang -- e.g. a
    # PlayMode test whose background coroutine throws and wedges the runner with zero
    # further output (the CircleLineRenderer SINGLE_THREADED hang that burned ~70 min of
    # total silence). The wall-clock backstop (Get-EditorTestRunTimeoutSeconds) alone
    # would let such a hang run to ~80 min; this fails it in minutes and returns the seat.
    #
    # MUST stay comfortably ABOVE the longest legitimately-silent phase of a HEALTHY run.
    # Measured on real CI logs: a COLD leg (first project open -> asset import + full
    # script compile + domain reload, all streamed via `-logFile -`) has a max quiet gap
    # of ~54s, and the longest quiet gap anywhere on a healthy leg is ~125s (a mid-run
    # Unity license entitlement re-resolution). 300s is ~2.4x the worst observed gap and
    # ~5.5x the worst COLD gap, so it never false-fires on a healthy run (cold or warm)
    # yet converts a fully-silent hang into a ~5 min fast-fail. The watchdog also emits a
    # throttled "still alive" heartbeat during any quiet stretch, so a near-threshold gap
    # is visible (and tunable) long before it could kill. Honors
    # UH_EDITOR_TEST_STALL_SECONDS; a non-integer or negative override is ignored with a
    # ::warning::; 0 is the explicit OPT-OUT (stall guard off, wall-clock only).
    # StrictMode-safe.
    param([int]$Default = 300)

    if ($env:UH_EDITOR_TEST_STALL_SECONDS) {
        $parsed = 0
        if (
            [int]::TryParse($env:UH_EDITOR_TEST_STALL_SECONDS, [ref]$parsed) -and
            $parsed -ge 0
        ) {
            return $parsed
        }
        Write-Host "::warning::Ignoring invalid UH_EDITOR_TEST_STALL_SECONDS='$env:UH_EDITOR_TEST_STALL_SECONDS'; using $Default second(s)."
    }
    return $Default
}

# UUM-153198 crashes during startup artifact pruning before managed tests load.
# A broken UDS memory pool can also stall the following Editor startup.
# Unity can explicitly refuse a corrupted ArtifactDB while returning zero.
# Match complete startup signatures before any managed test stream.
function Test-UnityArtifactDatabaseStartupFailure {
    param([string]$LogPath)

    if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $false }
    $log = [IO.File]::ReadAllText($LogPath)
    $pruningFailure = $log.Contains('========== OUTPUTTING STACK TRACE') -and
        $log.Contains('FindArtifactsToRemove') -and
        $log.Contains('GarbageCollectArtifactsFromDB')
    $sharedMemoryFailure = $log.Contains('[Error] Command buffer shared memory issue') -and
        $log.Contains('[Error] Tried to create a new semaphore handle') -and
        $log.Contains('uds_sharedmutex_init')
    $nativeInitializationFailure = ($pruningFailure -or $sharedMemoryFailure) -and
        $log.Contains('InitializeAssetDatabaseV2')
    $knownDatabaseRefusal = $log -match '(?m)^Exiting because Library/ArtifactDB is corrupted\. Relaunch Editor without batch mode to view additional options\.\r?$' -or
        $log.Contains("mdb_env_open failed on 'Library/ArtifactDB' with error: -30793 'MDB_INVALID: File is not an LMDB file'")
    return (($nativeInitializationFailure -or $knownDatabaseRefusal) -and
        -not $log.Contains('[uh-test-stream] RUN-STARTED') -and
        -not $log.Contains('error CS'))
}

function Reset-UnityArtifactDatabaseLibrary {
    param([Parameter(Mandatory = $true)][string]$Project)

    $library = Join-Path $Project 'Library'
    $marker = Join-Path $library '.unity-helpers-repo-root.txt'
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) {
        throw 'Artifact-database recovery requires a harness-owned Library marker.'
    }
    $repoMarker = [IO.File]::ReadAllText($marker)
    # Prune earlier harness-owned diagnostics when their files can be removed.
    foreach ($previous in @(Get-ChildItem -LiteralPath $Project -Directory -Force -Filter 'Library.artifact-database-failure-*')) {
        if ($previous.Name -cnotmatch '^Library\.artifact-database-failure-[0-9a-f]{32}$' -or
            ($previous.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
        try {
            $previousMarker = Join-Path $previous.FullName '.unity-helpers-repo-root.txt'
            if ((Test-Path -LiteralPath $previousMarker -PathType Leaf) -and
                [IO.File]::ReadAllText($previousMarker) -ceq $repoMarker) {
                Remove-Item -LiteralPath $previous.FullName -Recurse -Force -ErrorAction Stop
            }
        } catch {
            Write-CiWarning "Could not remove earlier failed Library '$($previous.FullName)': $($_.Exception.Message)"
        }
    }
    $retainedLibrary = Join-Path $Project ('Library.artifact-database-failure-' + [guid]::NewGuid().ToString('N'))
    Move-Item -LiteralPath $library -Destination $retainedLibrary -ErrorAction Stop
    $null = New-Item -ItemType Directory -Path $library
    [IO.File]::WriteAllText($marker, $repoMarker)
    Write-CiNotice "Retained failed Library for diagnosis: $retainedLibrary"
}

function Invoke-UnityEditorTestsWithPackageManagerRetry {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [Parameter(Mandatory = $true)][string]$ResultsPath,
        [Parameter(Mandatory = $true)][string]$Project
    )

    $completionGrace = Get-EditorTestCompletionGraceSeconds
    $runTimeout = Get-EditorTestRunTimeoutSeconds
    $runStall = Get-EditorTestStallSeconds

    $artifactDatabaseFailure = $null
    if (Test-Path -LiteralPath $LogPath -PathType Leaf) {
        Remove-Item -LiteralPath $LogPath -Force -ErrorAction Stop
    }
    try {
        $runExit = Invoke-UnityEditor `
            -EditorPath $EditorPath `
            -Arguments $Arguments `
            -Label $Label `
            -LogPath $LogPath `
            -CompletionPattern $script:EditorTestCompletionSentinel `
            -CompletionGraceSeconds $completionGrace `
            -TimeoutSeconds $runTimeout `
            -StallSeconds $runStall
    } catch {
        if (Test-Path -LiteralPath $ResultsPath -PathType Leaf) { throw }
        $artifactDatabaseFailure = Test-UnityArtifactDatabaseStartupFailure -LogPath $LogPath
        if (-not (Test-UnityConfigurePackageManagerRetryableFailure -LogPath $LogPath) -and
            -not $artifactDatabaseFailure) { throw }
        $runExit = 1
    }

    if (Test-Path -LiteralPath $ResultsPath -PathType Leaf) { return $runExit }
    if ($null -eq $artifactDatabaseFailure) {
        $artifactDatabaseFailure = Test-UnityArtifactDatabaseStartupFailure -LogPath $LogPath
    }
    if (-not $artifactDatabaseFailure -and -not (Test-UnityPackageManagerTransientFailure -LogPath $LogPath)) {
        return $runExit
    }

    $retryReason = 'UPM cancellation'
    if ($artifactDatabaseFailure) {
        $retryReason = 'startup artifact-database corruption'
        Write-CiWarning 'Unity failed while initializing its artifact database before tests loaded; retaining the failed Library and rebuilding once.'
    } else {
        Write-CiWarning 'Unity Package Manager canceled package resolution before NUnit results existed; clearing UPM state and retrying once.'
        Write-UnityPackageManagerTransientFailureWarnings -LogPath $LogPath
    }
    $firstAttemptLogPath = Join-Path (Split-Path -Parent $LogPath) ("{0}.first-attempt.log" -f [System.IO.Path]::GetFileNameWithoutExtension($LogPath))
    try {
        Copy-Item -LiteralPath $LogPath -Destination $firstAttemptLogPath -Force -ErrorAction Stop
        Write-CiNotice "Saved first failed Unity log before retry: $firstAttemptLogPath"
    } catch {
        Write-CiWarning "Could not preserve first failed Unity log before retry: $($_.Exception.Message)"
    }
    $observationPath = [IO.Path]::ChangeExtension($LogPath, 'execution-diagnostics.json')
    if (Test-Path -LiteralPath $observationPath -PathType Leaf) {
        try {
            Copy-Item -LiteralPath $observationPath -Destination ([IO.Path]::ChangeExtension($firstAttemptLogPath, 'execution-diagnostics.json')) -Force -ErrorAction Stop
        } catch {
            Write-CiWarning 'Could not preserve first failed Unity execution diagnostics before retry.'
        }
    }
    if ($artifactDatabaseFailure) {
        Reset-UnityArtifactDatabaseLibrary -Project $Project
    } else {
        Clear-UnityPackageManagerRetryState -Project $Project
    }

    foreach ($stalePath in @($ResultsPath, $LogPath)) {
        if (Test-Path -LiteralPath $stalePath -PathType Leaf) {
            Remove-Item -LiteralPath $stalePath -Force -ErrorAction Stop
        }
    }

    return Invoke-UnityEditor `
        -EditorPath $EditorPath `
        -Arguments $Arguments `
        -Label "$Label (retry 1 after $retryReason)" `
        -LogPath $LogPath `
        -CompletionPattern $script:EditorTestCompletionSentinel `
        -CompletionGraceSeconds $completionGrace `
        -TimeoutSeconds $runTimeout `
        -StallSeconds $runStall
}

# Holder for the ::stop-commands::<token> ... ::<token>:: fence token that wraps
# caller-controlled raw multi-line dumps (NUnit <message>/<stack-trace>). GitHub
# parses every stdout line for `::command::` directives; fencing the raw body
# disables that processing so an assertion message containing a line like
# `::error file=...::` or `::set-output name=x::` cannot inject a spurious
# workflow command. The token is NOT a fixed literal: a crafted message
# containing the exact `::<literal>::` close line could otherwise end the fence
# early and re-enable injection. Instead a FRESH random token is generated per
# enumeration via New-WorkflowCommandStopToken (mirroring GitHub's own
# @actions/core, which uses a random per-invocation delimiter) and the SAME
# value is used for the opening and closing fence lines. The matching fence in
# .github/actions/verify-unity-results/action.yml uses the same scheme.
$script:WorkflowCommandStopToken = $null

# Generate a fresh, unpredictable stop-commands fence token. A GUID 'N' form is
# 32 hex chars with no separators, so it can never collide with caller text and
# is regenerated each call so it is neither predictable nor committed.
function New-WorkflowCommandStopToken {
    return ('uh-stop-commands-{0}' -f [guid]::NewGuid().ToString('N'))
}

function New-UnityEditorTestPhases {
    param(
        [string]$ArtifactsPath,
        [string]$TestFilter,
        [string]$TestCategory,
        [switch]$IsolateCompilationFixtures,
        [ValidateSet('All', 'Main', 'Isolated')][string]$EditorPhaseGroup = 'All'
    )

    if ($EditorPhaseGroup -ne 'All' -and -not $IsolateCompilationFixtures) {
        throw 'An editor phase group requires compilation isolation.'
    }
    $fixture = 'WallstopStudios.UnityHelpers.Tests.Tools.OdinMigration.OdinMigrationDictionaryCompilationTests'
    if ($IsolateCompilationFixtures) {
        if (-not [string]::IsNullOrWhiteSpace($TestFilter)) {
            throw 'Compilation isolation cannot be combined with a caller test filter.'
        }
        if ($EditorPhaseGroup -ne 'Main') {
            [pscustomobject]@{
                ArtifactsPath = Join-Path $ArtifactsPath 'compilation'
                TestFilter = $fixture
                TestCategory = 'CompilationIsolation'
                RequiredFixture = $fixture
                RequirePassedTests = $true
            }
            foreach ($group in @(Get-UnityMigrationIsolationGroups)) {
                [pscustomobject]@{
                    ArtifactsPath = Join-Path $ArtifactsPath ('migration/' + $group.Name)
                    TestFilter = $group.Fixtures -join ';'
                    TestCategory = 'MigrationIsolation'
                    RequiredFixture = $group.Fixtures
                    RequirePassedTests = $true
                }
            }
        }
        $TestCategory = (@($TestCategory, '!CompilationIsolation', '!MigrationIsolation') |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join ';'
    }
    if ($EditorPhaseGroup -eq 'Isolated') { return }
    [pscustomobject]@{
        ArtifactsPath = $ArtifactsPath
        TestFilter = $TestFilter
        TestCategory = $TestCategory
        RequiredFixture = @()
        RequirePassedTests = -not [string]::IsNullOrWhiteSpace($TestFilter)
    }
}

function New-UnityEditorPhaseArguments {
    param([string[]]$Arguments, [string]$TestCategory, [string]$TestFilter, [string]$UnityVersion)

    $phaseArguments = @($Arguments)
    # UUM-135237 corrupts the heap when 6000.5 tears down an import worker
    # after the compilation-isolation fixture. Import the same assets in-process.
    if ($UnityVersion -match '^6000\.5\.' -and $TestCategory -ceq 'CompilationIsolation') {
        $phaseArguments += @('-refreshImportMode', 'InProcess')
    }
    if (-not [string]::IsNullOrWhiteSpace($TestCategory)) {
        $phaseArguments += @('-testCategory', $TestCategory)
    }
    if (-not [string]::IsNullOrWhiteSpace($TestFilter)) {
        $phaseArguments += @('-testFilter', $TestFilter)
    }
    return $phaseArguments
}

function Invoke-UnityEditorTestPhase {
    param(
        [string]$EditorPath,
        [string[]]$Arguments,
        [string]$Label,
        [string]$ArtifactsPath,
        [string]$Project,
        [string]$PackageRoot,
        [string[]]$RequiredFixture,
        [switch]$RequirePassedTests
    )

    New-Item -ItemType Directory -Force -Path $ArtifactsPath | Out-Null
    $phaseResults = Join-Path $ArtifactsPath 'results.xml'
    $phaseLog = Join-Path $ArtifactsPath 'unity.log'
    if (Test-Path -LiteralPath $phaseResults -PathType Leaf) {
        Remove-Item -LiteralPath $phaseResults -Force
    }
    $phaseArguments = @($Arguments) + @('-testResults', $phaseResults)
    $phaseExit = Invoke-UnityEditorTestsWithPackageManagerRetry `
        -EditorPath $EditorPath -Arguments $phaseArguments -Label $Label `
        -LogPath $phaseLog -ResultsPath $phaseResults -Project $Project
    Write-AnalyzerSetupDiagnostics -Project $Project -LogPath $phaseLog -Label $Label
    Test-NUnitResults -Path $phaseResults -Label $Label -LogPath $phaseLog `
        -Project $Project -UnityExitCode $phaseExit -RequirePassedTests:$RequirePassedTests
    if ($null -ne $RequiredFixture -and $RequiredFixture.Count -ne 0) {
        Assert-UnityCompilationFixtureResults -Path $phaseResults -FixtureName $RequiredFixture
    }
    Assert-NoUnityCompilerWarnings -LogPath $phaseLog -Label $Label -PackageRoot $PackageRoot
}

# Resolve an NUnit test-case / test-suite node's display name using
# XmlElement.GetAttribute, which returns '' for an ABSENT attribute instead of
# THROWING under Set-StrictMode -Version Latest (the dynamic `$node.fullname`
# property accessor throws "The property 'fullname' cannot be found" when the
# attribute is missing, which would degrade the whole failed-test enumeration to
# a generic warning for any NUnit XML lacking a fullname). Prefers fullname, then
# name, then a final '(unnamed test)' fallback.
function Get-NUnitNodeFullName {
    param([Parameter(Mandatory = $true)]$Node)

    $fullName = $Node.GetAttribute('fullname')
    if (-not $fullName) {
        $fullName = $Node.GetAttribute('name')
    }
    if (-not $fullName) {
        $fullName = '(unnamed test)'
    }
    return $fullName
}

# DIAGNOSTIC: when a Unity test run reports failures, the operator's next question
# is "WHICH tests failed and WHY?". The aggregate `failed=N` count alone is not
# actionable -- a real 2021.3 PlayMode run failed 1 of 697 tests and the logs
# never named it. This best-effort helper enumerates each failed test from the
# NUnit3 results XML and emits BOTH:
#   - a single-line `::error::` GitHub annotation per failed test (label +
#     fullname + first line of the failure message), and
#   - a `::group::Failed test: <fullname>` ... `::endgroup::` console block with
#     the full multi-line message and stack trace.
# It NEVER throws (the caller is already on a throw path; a diagnostic error must
# not mask the real test failure) and follows the structure of the other
# best-effort scanners (Write-UnityCatastrophicErrorAnnotations /
# Write-UnityResultFailureDiagnostics).
#
# Two classes of failed node are enumerated:
#   (1) Failed leaf cases: //test-case[@result='Failed'] -- the ordinary
#       assertion failure.
#   (2) Failed suites that carry their OWN direct <failure> child and whose
#       failure site is not Child. This is
#       the OneTimeSetUp / OneTimeTearDown failure shape (e.g.
#       SuiteWallClockBudgetTest's [OneTimeTearDown] Assert.Fail) -- a suite can
#       carry its OWN teardown failure message EVEN WHEN it also has a failed
#       child case, so we report on the direct <failure> regardless of failed
#       descendants. The fullname de-dup keeps a suite distinct from its child
#       cases (suite fullname differs from case fullname), so this never
#       double-prints; an aggregate-only suite (no direct <failure>) is still
#       skipped because its failure is just the roll-up of the child cases.
# De-duplicated by fullname so the same logical node is never printed twice, and
# capped at the first $MaxFailures (a truncation notice is printed -- no silent
# cap). Attribute reads use XmlElement.GetAttribute (returns '' when absent,
# never throws) so a results.xml lacking a fullname/name attribute does NOT
# degrade the whole enumeration to a generic warning under Set-StrictMode.
function Write-UnityFailedTestAnnotations {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Xml,
        [Parameter(Mandatory = $true)][string]$Label,
        [int]$MaxFailures = 50
    )

    try {
        $failedCases = @($Xml.SelectNodes("//test-case[@result='Failed']"))
        $failedSuites = @($Xml.SelectNodes("//test-suite[@result='Failed'][not(@site='Child')]"))

        # A failed suite is reported on its OWN merits whenever it carries a
        # direct <failure> child element. This captures the OneTimeSetUp /
        # OneTimeTearDown failure message even when the suite ALSO has a failed
        # descendant case (the teardown's own message would otherwise be lost).
        # An aggregate-only suite (no direct <failure>, just a roll-up of failed
        # children) is skipped. The fullname de-dup below keeps the suite
        # distinct from its child cases, so this never double-prints.
        $ownFailureSuites = @(
            foreach ($suite in $failedSuites) {
                $directFailure = $suite.SelectSingleNode('failure')
                if ($directFailure) {
                    $suite
                }
            }
        )

        $failedNodes = @($failedCases) + @($ownFailureSuites)
        if ($failedNodes.Count -lt 1) {
            return
        }

        # De-duplicate by fullname (fallback name) so the same logical test is
        # never printed twice.
        $seen = New-Object 'System.Collections.Generic.HashSet[string]'
        $uniqueNodes = New-Object 'System.Collections.Generic.List[object]'
        foreach ($node in $failedNodes) {
            $fullName = Get-NUnitNodeFullName -Node $node
            if ($seen.Add($fullName)) {
                $uniqueNodes.Add($node)
            }
        }

        $totalFailed = $uniqueNodes.Count
        $shown = @($uniqueNodes | Select-Object -First $MaxFailures)
        foreach ($node in $shown) {
            $fullName = Get-NUnitNodeFullName -Node $node

            $failureNode = $node.SelectSingleNode('failure')
            $message = ''
            $stackTrace = ''
            if ($failureNode) {
                $messageNode = $failureNode.SelectSingleNode('message')
                if ($messageNode) {
                    $message = $messageNode.InnerText
                }
                $stackNode = $failureNode.SelectSingleNode('stack-trace')
                if ($stackNode) {
                    $stackTrace = $stackNode.InnerText
                }
            }

            $firstMessageLine = ConvertTo-SingleLineDiagnostic -Text $message
            # The single-line ::error:: annotation stays OUTSIDE the fence so it
            # is still processed as a GitHub annotation. ConvertTo-SingleLineDiagnostic
            # already flattens it to one line, so an embedded `::error::`/`::set-output::`
            # token cannot start a NEW directive on its own line here.
            Write-Host "::error::${Label} failed test: $fullName -- $firstMessageLine"

            Write-Host "::group::Failed test: $fullName"
            # SECURITY: the raw NUnit <message>/<stack-trace> are caller-controlled
            # (an assertion message can contain ANY text). GitHub parses every
            # stdout line for `::command::` directives, so a message line like
            # `::error file=...::` or `::set-output name=x::` would inject a
            # spurious workflow command. Fence the raw multi-line dump with
            # ::stop-commands::<token> ... ::<token>:: so command processing is
            # disabled for the enclosed lines. The token is a FRESH random GUID
            # per dump (never a fixed literal) so a crafted message containing
            # the exact `::<literal>::` close line cannot end the fence early and
            # re-enable injection. The ::group::/::endgroup:: markers stay OUTSIDE
            # the fence so they are still processed.
            $script:WorkflowCommandStopToken = New-WorkflowCommandStopToken
            Write-Host "::stop-commands::$script:WorkflowCommandStopToken"
            if ($message) {
                Write-Host "Message:"
                Write-Host (ConvertTo-UnitySafeLogText -Text $message)
            } else {
                Write-Host "Message: (none recorded)"
            }
            if ($stackTrace) {
                Write-Host "Stack trace:"
                Write-Host (ConvertTo-UnitySafeLogText -Text $stackTrace)
            }
            Write-Host "::$script:WorkflowCommandStopToken::"
            Write-Host "::endgroup::"
        }

        if ($totalFailed -gt $shown.Count) {
            $omitted = $totalFailed - $shown.Count
            Write-CiNotice "${Label}: $omitted additional failed test(s) not shown (showing first $($shown.Count) of $totalFailed)."
        }
    } catch {
        # Best-effort; a diagnostic must never mask the real test failure.
        Write-Host "::warning::Could not enumerate failed tests for ${Label}: $($_.Exception.Message)"
    }
}

function Get-UnityFailedNodeCount {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)]$Xml)

    try {
        $failedCases = @($Xml.SelectNodes("//test-case[@result='Failed']"))
        $failedSuitesWithOwnFailure = @($Xml.SelectNodes("//test-suite[@result='Failed'][failure][not(@site='Child')]"))
        return $failedCases.Count + $failedSuitesWithOwnFailure.Count
    } catch {
        return 0
    }
}

function Write-UnityExecutionSymptomDiagnostics {
    [CmdletBinding()]
    param(
        [string]$LogPath,
        [Parameter(Mandatory = $true)][string]$Label,
        [int]$MaxLines = 80
    )

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return
    }

    $patterns = @(
        'Files generated by test without cleanup\.',
        'Found \d+ new files\.',
        '^\s+Assets[\\/]',
        'IgnoreFailingMessages:false',
        'Unhandled log message',
        'UnexpectedLogMessageException(?!\.cs)',
        'CleanupVerificationTask',
        'Test run completed\. Exiting with code 2',
        'One or more tests failed',
        'Unable to find (child|sibling|parent) component',
        'Can''t add ''.*'' to .* because',
        'EditorWindow\.ShowUtility',
        'd3d12: Unrecoverable GPU device error',
        'No graphic device is available to initialize the view',
        'AddCursorRect called outside an editor OnGUI'
    )

    try {
        $hits = @(
            Select-String -LiteralPath $LogPath -Pattern $patterns -ErrorAction SilentlyContinue |
                Select-Object -First $MaxLines
        )
        if ($hits.Count -lt 1) {
            return
        }

        Write-Host "::group::Unity execution symptom diagnostics ($Label)"
        foreach ($hit in $hits) {
            $line = ConvertTo-UnitySafeLogText -Text $hit.Line.Trim()
            Write-Host ("  line {0}: {1}" -f $hit.LineNumber, $line)
        }
        Write-Host "::endgroup::"

        $logText = Get-Content -LiteralPath $LogPath -Raw
        if ($logText -match 'Files generated by test without cleanup\.') {
            Write-CiError "Unity cleanup verification failed for ${Label}: one or more tests left generated files under Assets. See the generated-file lines above."
        }
        # `UnexpectedLogMessageException` also names a FILE in the test framework, and the
        # IL2CPP build size report lists it verbatim:
        #   0.2 kb  0.0% Packages/com.unity.test-framework/.../UnexpectedLogMessageException.cs
        # A bare substring match therefore reported 'the framework rejected an unexpected log' for
        # every Release standalone failure, whatever actually went wrong (run 31292390551, where
        # the real cause was a player crash). Exclude the source-file spelling only -- anything
        # narrower risks missing a genuine rejection.
        if ($logText -match 'Unhandled log message' -or $logText -match 'UnexpectedLogMessageException(?!\.cs)') {
            Write-CiError "Unity Test Framework rejected an unexpected log for ${Label}. Add a precise LogAssert.Expect for expected logs or fix the production log."
        }
        if ($logText -match 'EditorWindow\.ShowUtility' -or $logText -match 'd3d12: Unrecoverable GPU device error') {
            Write-CiError "Unity editor-window creation failed for ${Label}. CI-driven IMGUI tests should use TestIMGUIExecutor/offscreen UIElements instead of creating native EditorWindow surfaces."
        }
    } catch {
        Write-Host "::warning::Could not collect Unity execution symptom diagnostics for ${Label}: $($_.Exception.Message)"
    }
}

function Resolve-FullPath {
    param([Parameter(Mandatory = $true)][string]$Path)
    $executionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
}

function Assert-RepoRoot {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath (Join-Path $Path 'package.json') -PathType Leaf)) {
        throw "Repo root '$Path' does not contain package.json."
    }
    if (-not (Test-Path -LiteralPath (Join-Path $Path 'Runtime') -PathType Container)) {
        throw "Repo root '$Path' does not contain Runtime/."
    }
}

function ConvertTo-UnityFileUriPath {
    param([Parameter(Mandatory = $true)][string]$Path)
    return ($Path -replace '\\', '/')
}

function Initialize-UnityCacheEnvironment {
    param(
        [Parameter(Mandatory = $true)][string]$CacheRoot
    )

    $cacheRoot = $CacheRoot
    $upmRoot = Join-Path $cacheRoot 'upm'
    $npmRoot = Join-Path $cacheRoot 'npm'
    $gitLfsRoot = Join-Path $cacheRoot 'git-lfs'
    $localUnityCaches = if ($env:LOCALAPPDATA) {
        Join-Path $env:LOCALAPPDATA 'Unity\Caches'
    } else {
        Join-Path $cacheRoot 'localappdata\Unity\Caches'
    }

    foreach ($path in @($cacheRoot, $upmRoot, $npmRoot, $gitLfsRoot, $localUnityCaches)) {
        New-Item -ItemType Directory -Force -Path $path | Out-Null
    }

    $env:UPM_CACHE_ROOT = $upmRoot
    $env:UPM_NPM_CACHE_PATH = $npmRoot
    $env:UPM_GIT_LFS_CACHE_PATH = $gitLfsRoot
    $env:UPM_ENABLE_GIT_LFS_CACHE = 'true'

    Write-Host "::group::Unity cache environment"
    Write-Host "LOCALAPPDATA Unity caches: $localUnityCaches"
    Write-Host "UPM_CACHE_ROOT: $env:UPM_CACHE_ROOT"
    Write-Host "UPM_NPM_CACHE_PATH: $env:UPM_NPM_CACHE_PATH"
    Write-Host "UPM_GIT_LFS_CACHE_PATH: $env:UPM_GIT_LFS_CACHE_PATH"
    Write-Host "::endgroup::"
}

# Read+parse a package-manifest single-source JSON (the OpenUPM registry + pinned
# packages used to extend the ephemeral manifest). Shared by the comparison and
# integration legs, which read DIFFERENT files of the SAME shape:
#   .github/comparison-packages.json  (benchmark comparison deps; not present in
#                                      unity-helpers today)
#   .github/integration-packages.json (DI-container integration deps)
# Kept DRY so both legs parse identically and a missing/typo'd source fails loudly
# with the file path rather than silently producing an empty manifest extension.
function Get-PackageManifestSource {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [Parameter(Mandatory = $true)][string]$Kind
    )
    $path = Join-Path $Root $RelativePath
    if (-not (Test-Path -LiteralPath $path)) {
        throw "$Kind packages single source not found: $path"
    }
    return Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
}

function Get-ComparisonPackages {
    param([Parameter(Mandatory = $true)][string]$Root)
    return Get-PackageManifestSource -Root $Root -RelativePath '.github/comparison-packages.json' -Kind 'Comparison'
}

function Get-IntegrationPackages {
    param([Parameter(Mandatory = $true)][string]$Root)
    return Get-PackageManifestSource -Root $Root -RelativePath '.github/integration-packages.json' -Kind 'Integration'
}

# Read the SINGLE SOURCE OF TRUTH for the UnityEngine built-in modules + editor-
# bundled packages (com.unity.ugui) the ephemeral test project must declare so the
# package's Runtime/Editor code AND its test fixtures compile. Shared with
# scripts/unity/create-test-project.sh so the two manifest generators cannot drift
# (that drift -- this generator declared ZERO modules -- is what failed every
# matrix leg: the editor could not compile and emitted no NUnit results.xml).
# Returns an [ordered] id->version map. Fails LOUDLY with the file path if the
# source is missing or has no 'modules' object, rather than silently producing a
# module-less manifest (the exact regression this guards against).
function Get-UnityTestProjectModules {
    param([Parameter(Mandatory = $true)][string]$Root)
    $source = Get-PackageManifestSource -Root $Root -RelativePath '.github/unity-test-project-modules.json' -Kind 'Unity test-project module'
    $modulesNode = $source.PSObject.Properties['modules']
    # Guard BOTH a missing 'modules' key AND a present-but-null value (JSON
    # "modules": null), so a malformed edit fails with this clear message rather
    # than an opaque StrictMode "property cannot be found on null" throw below.
    if (-not $modulesNode -or $null -eq $modulesNode.Value) {
        throw "unity-test-project-modules.json is missing or has a null 'modules' object; cannot generate the test-project manifest."
    }
    $modules = [ordered]@{}
    foreach ($prop in $modulesNode.Value.PSObject.Properties) {
        $modules[$prop.Name] = $prop.Value
    }
    if ($modules.Count -lt 1) {
        throw "unity-test-project-modules.json 'modules' object is empty; the test project would fail to compile."
    }
    return $modules
}

function Get-UnityTestFrameworkVersion {
    param([Parameter(Mandatory = $true)][string]$Root)
    $source = Get-PackageManifestSource -Root $Root -RelativePath '.github/unity-test-framework.json' -Kind 'Unity Test Framework policy'
    $version = $source.PSObject.Properties['requestedVersion']
    if ($null -eq $version -or $version.Value -isnot [string] -or $version.Value -cnotmatch '^[0-9]+\.[0-9]+\.[0-9]+$') {
        throw 'Unity Test Framework policy requires a stable requestedVersion string.'
    }
    return $version.Value
}

function New-ManifestJson {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [switch]$IncludeComparisons,
        [switch]$IncludeIntegrations,
        [string]$RepoRoot
    )

    $packagePath = ConvertTo-UnityFileUriPath -Path $Root
    $moduleRoot = if ([string]::IsNullOrWhiteSpace($RepoRoot)) { $Root } else { $RepoRoot }
    $dependencies = [ordered]@{
        'com.unity.test-framework' = Get-UnityTestFrameworkVersion -Root $moduleRoot
    }

    # UNCONDITIONAL (every leg -- editmode/playmode/standalone, single-threaded,
    # comparison, integration): the package's required UnityEngine built-in modules
    # must be in the project or the editor fails compilation BEFORE any test runs.
    # Sourced from the shared single-source file so this generator and
    # create-test-project.sh cannot drift. The package.json deliberately does NOT
    # carry these (dual npm+UPM file; `npm ci` would fail to resolve com.unity.*),
    # so the test-project manifest is their only home.
    foreach ($module in (Get-UnityTestProjectModules -Root $moduleRoot).GetEnumerator()) {
        $dependencies[$module.Key] = $module.Value
    }

    # Add the local package after the Unity modules (the -IncludeComparisons /
    # -IncludeIntegrations legs may append further dependencies below this).
    $dependencies[$PackageName] = "file:$packagePath"

    $manifest = [ordered]@{
        dependencies = $dependencies
        testables = @($PackageName)
    }

    # Accumulate the OpenUPM scoped-registry scopes contributed by whichever opt-in
    # legs are active. Both comparison and integration legs use the SAME OpenUPM
    # registry (package.openupm.com); if both were ever active together their
    # scopes are merged into a SINGLE scopedRegistries entry (Unity would otherwise
    # see two registries with the same URL). The non-opt-in legs add NOTHING here,
    # so their manifest stays byte-for-byte identical to before (no scopedRegistries
    # key, no extra dependencies) and their Library cache/reliability are unchanged.
    $registryName = $null
    $registryUrl = $null
    $registryScopes = New-Object System.Collections.Generic.List[string]

    # ONLY the comparison legs (-IncludeComparisons) get the OpenUPM scoped
    # registry, pinned comparison packages, and comparison-package-required Unity
    # built-in modules, read from the single source .github/comparison-packages.json.
    if ($IncludeComparisons) {
        if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
            throw "New-ManifestJson -IncludeComparisons requires -RepoRoot (the comparison-packages.json single source)."
        }
        $comparisons = Get-ComparisonPackages -Root $RepoRoot
        foreach ($pkg in $comparisons.packages.PSObject.Properties) {
            $dependencies[$pkg.Name] = $pkg.Value
        }
        $builtInPackages = $comparisons.PSObject.Properties['unityBuiltInPackages']
        if (-not $builtInPackages) {
            throw "comparison-packages.json is missing unityBuiltInPackages; cannot generate the comparison manifest."
        }
        foreach ($pkg in $builtInPackages.Value.PSObject.Properties) {
            $dependencies[$pkg.Name] = $pkg.Value
        }
        $reg = $comparisons.registry
        $registryName = $reg.name
        $registryUrl = $reg.url
        foreach ($scope in @($reg.scopes)) {
            if (-not $registryScopes.Contains($scope)) {
                $registryScopes.Add($scope)
            }
        }
    }

    # ONLY the integration legs (-IncludeIntegrations) get the OpenUPM scoped
    # registry + the pinned DI-container packages (Reflex / VContainer / Zenject-
    # Extenject) from .github/integration-packages.json. Installing them is what
    # makes the Runtime/Integrations + Tests/{Editor,Runtime}/Integrations asmdefs
    # (REFLEX_PRESENT / VCONTAINER_PRESENT / ZENJECT_PRESENT versionDefines) compile
    # and their tests run. unityBuiltInPackages is OPTIONAL here (the DI packages
    # are pure-managed and pull no extra Unity modules).
    if ($IncludeIntegrations) {
        if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
            throw "New-ManifestJson -IncludeIntegrations requires -RepoRoot (the integration-packages.json single source)."
        }
        $integrations = Get-IntegrationPackages -Root $RepoRoot
        foreach ($pkg in $integrations.packages.PSObject.Properties) {
            $dependencies[$pkg.Name] = $pkg.Value
        }
        $builtInPackages = $integrations.PSObject.Properties['unityBuiltInPackages']
        if ($builtInPackages) {
            foreach ($pkg in $builtInPackages.Value.PSObject.Properties) {
                $dependencies[$pkg.Name] = $pkg.Value
            }
        }
        $reg = $integrations.registry
        if (-not $registryName) {
            $registryName = $reg.name
            $registryUrl = $reg.url
        }
        foreach ($scope in @($reg.scopes)) {
            if (-not $registryScopes.Contains($scope)) {
                $registryScopes.Add($scope)
            }
        }
    }

    if ($registryScopes.Count -gt 0) {
        # Ordered so ConvertTo-Json emits name/url/scopes deterministically (matches
        # the committed local-parity manifest field order and keeps the CI-log diff
        # of the generated manifest stable run-to-run).
        $manifest['scopedRegistries'] = @(
            [ordered]@{
                name = $registryName
                url = $registryUrl
                scopes = @($registryScopes.ToArray())
            }
        )
    }

    return ($manifest | ConvertTo-Json -Depth 8)
}

function New-ConfiguratorSource {
    param(
        [string]$Backend = 'IL2CPP',
        [ValidateSet('Release', 'Debug')]
        [string]$CompilerConfiguration = 'Release',
        [ValidateSet('Disabled', 'Low', 'Medium', 'High')]
        [string]$StrippingLevel = 'Disabled',
        [switch]$RequireReleaseManagedCodeVariant
    )

    $requireReleaseVariant = $RequireReleaseManagedCodeVariant.IsPresent.ToString().ToLowerInvariant()

    # NOTE: this is a DOUBLE-quoted here-string so $Backend interpolates into the
    # generated C#. Every LITERAL C# dollar sign (the Debug.Log interpolated
    # string) is therefore backtick-escaped (`$). The LIVE code uses the
    # parameterized scripting backend (ScriptingImplementation.<Backend>), the
    # non-deprecated ApiCompatibilityLevel.NET_Standard (which targets .NET Standard
    # 2.1), CompilationPipeline.codeOptimization = Release, and disables managed
    # stripping by default so the ordinary Release Mono test player remains discoverable.
    # Focused acceptance can request High to exercise the generated static dispatch.
    @"
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

public static class UhCiTestConfigurator
{
    public static void Apply()
    {
        // Prove Release editor code optimization for every Unity CI leg. Set FIRST
        // so the effective value is logged below.
        UnityEditor.Compilation.CompilationPipeline.codeOptimization = UnityEditor.Compilation.CodeOptimization.Release;

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64);

        // GLOBAL scripting define injection (e.g. SINGLE_THREADED). The runner hands
        // the requested defines in via UH_ADDITIONAL_SCRIPTING_DEFINES (semicolon-
        // delimited). They are set on the Standalone NamedBuildTarget -- the only
        // build-target group every CI leg (editmode/playmode/standalone) uses -- so
        // they apply to ALL assemblies, asmdef assemblies INCLUDED (global scripting
        // defines, not an Assets/csc.rsp that only reaches the predefined assembly).
        // Unity in -batchmode does NOT recompile when defines change mid-run, so the
        // runner runs this configure pass in a SEPARATE editor invocation that
        // persists the defines to ProjectSettings.asset (AssetDatabase.SaveAssets
        // below); the subsequent -runTests invocation then loads the project with
        // the defines in place from startup, and its FIRST compile sees them. When
        // the env var is empty this is a no-op, so the DEFAULT (no-extra-defines)
        // behavior and the existing comparison/standalone legs are unchanged.
        ApplyAdditionalScriptingDefines();

        // The scripting backend is parameterized: the runner passes the IL2CPP or
        // the Mono backend for the Mono perf leg via -Backend.
        NamedBuildTarget target = NamedBuildTarget.Standalone;
        PlayerSettings.SetScriptingBackend(target, ScriptingImplementation.$Backend);
#if UNITY_6000_6_OR_NEWER
        if ($requireReleaseVariant || PlayerSettings.GetScriptingBackend(target) == ScriptingImplementation.Mono2x)
        {
            PlayerSettings.SetManagedCodeVariant(target, ManagedCodeVariant.Release);
            Debug.Log("UH perf managed code variant: " + PlayerSettings.GetManagedCodeVariant(target));
        }
#endif
        // Use the non-deprecated ApiCompatibilityLevel.NET_Standard (targets .NET
        // Standard 2.1). The deprecated 2.0 form and the non-existent 2.1 enum
        // member are intentionally NOT used.
        PlayerSettings.SetApiCompatibilityLevel(target, ApiCompatibilityLevel.NET_Standard);
        PlayerSettings.SetManagedStrippingLevel(target, ManagedStrippingLevel.$StrippingLevel);
        // Pin the IL2CPP C++ compiler configuration explicitly ($CompilerConfiguration).
        // An ephemeral CI project has no committed default, so the pin removes the
        // variable instead of trusting any implicit default. The standalone leg passes
        // Debug because Release ICEs MSVC on the generated test C++ -- see the
        // -Il2CppCompilerConfiguration parameter docs for the run and the exact file.
        // Harmless under Mono.
        PlayerSettings.SetIl2CppCompilerConfiguration(target, Il2CppCompilerConfiguration.$CompilerConfiguration);

        // Print the EFFECTIVE Unity config so the artifact log PROVES Mono/IL2CPP
        // + .NET Standard 2.1 + Release for this run.
        PlayerSettings.GetScriptingDefineSymbols(target, out string[] effectiveDefines);
        Debug.Log(`$"UH perf config: backend={PlayerSettings.GetScriptingBackend(target)}, api={PlayerSettings.GetApiCompatibilityLevel(target)}, codeOpt={UnityEditor.Compilation.CompilationPipeline.codeOptimization}, il2cppConfig={PlayerSettings.GetIl2CppCompilerConfiguration(target)}, stripping={PlayerSettings.GetManagedStrippingLevel(target)}, defines=[{string.Join(`";`", effectiveDefines ?? new string[0])}]");

        // Persist the PlayerSettings mutations (scripting backend/api/stripping AND
        // any injected scripting defines) to ProjectSettings.asset so the SEPARATE
        // -runTests editor invocation that follows this configure pass loads them
        // from startup. A clean -batchmode quit normally flushes settings, but the
        // explicit save removes that dependency and is the load-bearing step for the
        // editmode/playmode single-threaded leg (where this configure pass is the
        // ONLY place the defines get persisted before the test invocation compiles).
        AssetDatabase.SaveAssets();

        // Write a success marker as the FINAL action so the runner can treat the
        // CONFIGURED PROJECT -- not Unity's process exit code -- as the source of
        // truth. Unity can crash in a BACKGROUND thread (for example the
        // DirectoryMonitor file-watcher's teardown) DURING shutdown, AFTER Apply()
        // has fully completed and the editor logged "Batchmode quit successfully
        // invoked"; that returns a crash exit code (0xC0000005 STATUS_ACCESS_VIOLATION)
        // for a run whose configuration work actually succeeded. A fresh marker
        // proves Apply() ran to completion regardless of the shutdown exit code. The
        // marker path is handed in via UH_CONFIGURE_MARKER_PATH (mirrors how the
        // standalone build modifier receives UH_PLAYER_BUILD_PATH).
        string markerPath = Environment.GetEnvironmentVariable("UH_CONFIGURE_MARKER_PATH");
        if (!string.IsNullOrEmpty(markerPath))
        {
            string dir = Path.GetDirectoryName(markerPath);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }
            File.WriteAllText(markerPath, "UhCiTestConfigurator.Apply completed");
        }
    }

    // Union the requested global scripting defines (UH_ADDITIONAL_SCRIPTING_DEFINES,
    // semicolon-delimited) with whatever is already set for the Standalone group and
    // write them back via the non-deprecated SetScriptingDefineSymbols(NamedBuildTarget,
    // string[]) API (the BuildTargetGroup overload is obsolete in Unity 6). Order is
    // preserved and duplicates are dropped. A null/empty env var leaves the existing
    // defines untouched (no-op), so a normal leg's compilation is byte-for-byte
    // unchanged. NamedBuildTarget.Standalone exists in 2021.2+, so this compiles on
    // every CI Unity version even though only the Unity-6 leg passes extra defines.
    private static void ApplyAdditionalScriptingDefines()
    {
        string raw = Environment.GetEnvironmentVariable("UH_ADDITIONAL_SCRIPTING_DEFINES");
        if (string.IsNullOrWhiteSpace(raw))
        {
            return;
        }

        string[] requested = raw
            .Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(d => d.Trim())
            .Where(d => d.Length > 0)
            .ToArray();
        if (requested.Length == 0)
        {
            return;
        }

        NamedBuildTarget target = NamedBuildTarget.Standalone;
        PlayerSettings.GetScriptingDefineSymbols(target, out string[] existing);

        List<string> merged = new List<string>(existing ?? new string[0]);
        foreach (string define in requested)
        {
            if (!merged.Contains(define))
            {
                merged.Add(define);
            }
        }

        PlayerSettings.SetScriptingDefineSymbols(target, merged.ToArray());
        Debug.Log(`$"UH additional scripting defines applied to {target.TargetName}: requested=[{string.Join(`";`", requested)}] effective=[{string.Join(`";`", merged)}]");
    }
}
"@
}

# STANDALONE ONLY. The Editor-side type that severs the test player's outbound
# PlayerConnection/Profiler TCP dependency at build time AND makes the editor's
# `-runTests` build step terminate. Emitted into Assets/Editor/ of the standalone
# CI project by Initialize-EphemeralProject. It mirrors Unity's documented
# "Split build and run" example (vendored com.unity.test-framework
# TestPlayerBuildModifierAttribute.cs): ITestPlayerBuildModifier rewrites the
# BuildPlayerOptions, IPostBuildCleanup exits the editor after the build.
#
# CRITICAL: clearing BuildOptions.AutoRunPlayer ALONE is NOT enough. The CLI
# `-runTests` path registers Executer.ExitIfRunIsCompleted on
# EditorApplication.update, which returns early while TestRunnerApi.IsRunActive()
# is true; for a player run that flag clears only on the PlayerConnection
# runFinished message. With the player never launched the message never arrives,
# so the editor idles forever. The PostBuildCleanup exit (run AFTER the build via
# ExecutePostBuildCleanupMethods) is mandatory.
function New-StandaloneBuildModifierSource {
    param([bool]$DevelopmentBuild = $false)

    # The Development BuildOptions flag is opt-in only. Unity CI defaults to a true
    # Release/non-development player; the compatibility -ReleasePlayerBuild switch is
    # retained at the script boundary but Release is the unconditional contract.
    # CRITICAL: the Unity Test Framework's PlayerLauncher hands ModifyOptions a
    # BuildPlayerOptions that ALREADY carries BuildOptions.Development, so the
    # Release path must actively CLEAR the flag -- merely not adding it leaves the
    # player a development build (Debug.isDebugBuild=true; published runs reported
    # "x64 Debug" platform strings until this strip landed). Every OTHER option (clearing
    # AutoRunPlayer/ConnectToHost/ConnectWithProfiler, |= IncludeTestAssemblies, the
    # UH_PLAYER_BUILD_PATH redirect, and the PostBuildCleanup exit) is REQUIRED for
    # the split-build test execution and is emitted unconditionally. This is a
    # DOUBLE-quoted here-string so $developmentOption interpolates; the generated C#
    # contains no other dollar signs or backticks, so nothing else needs escaping.
    $developmentOption = if ($DevelopmentBuild) { '        playerOptions.options |= BuildOptions.Development;' } else { '        playerOptions.options &= ~BuildOptions.Development;' }
    @"
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.TestTools;
using UnityEngine;
using UnityEngine.TestTools;

[assembly: TestPlayerBuildModifier(typeof(UhCiStandaloneBuildModifier))]
[assembly: PostBuildCleanup(typeof(UhCiStandaloneBuildModifier))]

// Mirrors the documented Unity "Split build and run" example. Clearing
// AutoRunPlayer alone is NOT enough: the CLI -runTests path registers
// Executer.ExitIfRunIsCompleted on EditorApplication.update, which returns early
// while TestRunnerApi.IsRunActive() is true; for a player run that flag only
// clears on the PlayerConnection runFinished message, which never arrives when
// the player is not launched. PostBuildCleanup is the framework's hook (run after
// the build) to exit the editor cleanly.
public sealed partial class UhCiStandaloneBuildModifier : ITestPlayerBuildModifier, IPostBuildCleanup
{
    private static bool s_Armed;
    private static readonly EditorApplication.CallbackFunction s_Exit = () => EditorApplication.Exit(0);

    static partial void WriteFrozenBuildPreparation(BuildPlayerOptions playerOptions);

    public BuildPlayerOptions ModifyOptions(BuildPlayerOptions playerOptions)
    {
        const string testScene = "Packages/com.wallstop-studios.unity-helpers/Tests/Runtime/Scenes/Test1.unity";
        if (AssetDatabase.LoadAssetAtPath<SceneAsset>(testScene) == null)
        {
            throw new InvalidOperationException("Required standalone test scene is missing: " + testScene);
        }
        string[] scenes = playerOptions.scenes ?? Array.Empty<string>();
        if (Array.IndexOf(scenes, testScene) < 0)
        {
            string[] provisioned = new string[scenes.Length + 1];
            Array.Copy(scenes, provisioned, scenes.Length);
            provisioned[scenes.Length] = testScene;
            playerOptions.scenes = provisioned;
        }
        Debug.Log("UH standalone test scene: " + testScene);
        playerOptions.options &= ~BuildOptions.AutoRunPlayer;
        playerOptions.options &= ~BuildOptions.ConnectToHost;
        playerOptions.options &= ~BuildOptions.ConnectWithProfiler;
        playerOptions.options |= BuildOptions.IncludeTestAssemblies;
$developmentOption
        string outPath = Environment.GetEnvironmentVariable("UH_PLAYER_BUILD_PATH");
        if (!string.IsNullOrEmpty(outPath))
        {
            string dir = Path.GetDirectoryName(outPath);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }
            playerOptions.locationPathName = outPath;
        }
        UnityEditor.Build.NamedBuildTarget target = UnityEditor.Build.NamedBuildTarget.Standalone;
        Debug.Log("UH player build config: backend=" + UnityEditor.PlayerSettings.GetScriptingBackend(target)
            + ", stripping=" + UnityEditor.PlayerSettings.GetManagedStrippingLevel(target)
            + ", development=" + ((playerOptions.options & UnityEditor.BuildOptions.Development) != 0));
        WriteFrozenBuildPreparation(playerOptions);
        return playerOptions;
    }

    public void Cleanup()
    {
        if (s_Armed)
        {
            return;
        }
        s_Armed = true;
        if (Environment.GetCommandLineArgs().Any(a => a == "-runTests"))
        {
            EditorApplication.update += s_Exit;
        }
    }
}
"@
}

# STANDALONE ONLY. The player-side [assembly:TestRunCallback] that REPLACES the
# editor's need to receive results over PlayerConnection/TCP. On RunFinished it
# serializes the NUnit result to NUnit-compatible XML (mirroring Unity's
# ResultsWriter.WriteResultsToXml) at the path from the -uhTestResults <path>
# command-line arg, then Application.Quit(0 pass / 1 fail / 2 no-path / 3 write
# error). Emitted into Assets/UhCiStandaloneTestCallback/ with its own .asmdef.
# [Preserve] keeps the type for IL2CPP.
#
# On the PLAYER, ITestResult.ResultState is a NUnit.Framework.Interfaces.ResultState
# OBJECT, so we call .ToString() (the editor adaptor does the same). The single
# results channel is -uhTestResults; there is NO environment-variable fallback and
# NO per-user-data-folder silent-loss fallback.
function New-StandaloneTestCallbackSource {
    @'
using System;
using System.IO;
using System.Xml;
using NUnit.Framework.Interfaces;
using UnityEngine;
using UnityEngine.Scripting;
using UnityEngine.TestRunner;

[assembly: TestRunCallback(typeof(UhCiStandaloneTestCallback))]

[Preserve]
internal sealed class UhCiStandaloneTestCallback : ITestRunCallback
{
    public void RunStarted(ITest testsToRun)
    {
    }

    public void TestStarted(ITest test)
    {
    }

    public void TestFinished(ITestResult result)
    {
    }

    public void RunFinished(ITestResult result)
    {
        string path = ResolveResultsPath();
        if (string.IsNullOrEmpty(path))
        {
            Debug.LogError("UH: standalone test player received no -uhTestResults <path>; not writing results.");
            Application.Quit(2);
            return;
        }
        int exitCode;
        try
        {
            WriteNUnitXml(result, path);
            exitCode = result.FailCount > 0 ? 1 : 0;
            int total = result.PassCount + result.FailCount + result.SkipCount + result.InconclusiveCount;
            Debug.LogFormat(
                LogType.Log,
                LogOption.NoStacktrace,
                null,
                "UH: wrote standalone results to {0} (total={1} passed={2} failed={3} skipped={4})",
                path,
                total,
                result.PassCount,
                result.FailCount,
                result.SkipCount);
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            exitCode = 3;
        }
        Application.Quit(exitCode);
    }

    private static string ResolveResultsPath()
    {
        string[] args = Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length - 1; i++)
        {
            if (string.Equals(args[i], "-uhTestResults", StringComparison.Ordinal))
            {
                return args[i + 1];
            }
        }
        return null;
    }

    private static void WriteNUnitXml(ITestResult result, string filePath)
    {
        string dir = Path.GetDirectoryName(filePath);
        if (!string.IsNullOrEmpty(dir))
        {
            Directory.CreateDirectory(dir);
        }
        XmlWriterSettings settings = new XmlWriterSettings
        {
            Indent = true,
            NewLineOnAttributes = false
        };
        using (StreamWriter sw = File.CreateText(filePath))
        using (XmlWriter xw = XmlWriter.Create(sw, settings))
        {
            int total = result.PassCount + result.FailCount + result.SkipCount + result.InconclusiveCount;
            TNode run = new TNode("test-run");
            run.AddAttribute("id", "2");
            run.AddAttribute("testcasecount", total.ToString());
            run.AddAttribute("result", result.ResultState.ToString());
            run.AddAttribute("total", total.ToString());
            run.AddAttribute("passed", result.PassCount.ToString());
            run.AddAttribute("failed", result.FailCount.ToString());
            run.AddAttribute("inconclusive", result.InconclusiveCount.ToString());
            run.AddAttribute("skipped", result.SkipCount.ToString());
            run.AddAttribute("asserts", result.AssertCount.ToString());
            run.AddAttribute("engine-version", "3.5.0.0");
            run.AddAttribute("clr-version", Environment.Version.ToString());
            run.AddAttribute("start-time", result.StartTime.ToString("u"));
            run.AddAttribute("end-time", result.EndTime.ToString("u"));
            run.AddAttribute("duration", result.Duration.ToString());
            run.ChildNodes.Add(result.ToXml(true));
            run.WriteTo(xw);
        }
    }
}
'@
}

# STANDALONE ONLY. The asmdef for the player-side test callback above. Referencing
# UnityEngine.TestRunner is MANDATORY: TestRunCallbackListener.GetAllCallbacks only
# scans assemblies that reference UnityEngine.TestRunner. overrideReferences +
# precompiledReferences=nunit.framework.dll gives the callback the NUnit types;
# defineConstraints UNITY_INCLUDE_TESTS keeps it out of non-test builds. This must
# be a PLAYER assembly (NOT under Assets/Editor/), so includePlatforms is empty.
function New-StandaloneTestCallbackAsmdef {
    @'
{
    "name": "UhCiStandaloneTestCallback",
    "references": [
        "UnityEngine.TestRunner"
    ],
    "includePlatforms": [],
    "excludePlatforms": [],
    "overrideReferences": true,
    "precompiledReferences": [
        "nunit.framework.dll"
    ],
    "autoReferenced": true,
    "defineConstraints": [
        "UNITY_INCLUDE_TESTS"
    ]
}
'@
}

# This package DOES ship an analyzer, and nothing is pre-copied into the ephemeral project.
#
# Session 173 shipped Runtime/Analyzers/WallstopStudios.UnityHelpers.Proto.Generator.dll -- the
# source generator that emits every WallstopProto formatter the package depends on. Note the path:
# the .gitignore reserves Editor/Analyzers/, and the analyzer did not ship there.
#
# Unity registers a RoslynAnalyzer-labeled asset that lives inside a referenced package directly, so
# the copy-into-Assets dance this section was ported from does not apply. DxMessaging ships its
# generator outside the package and pre-copies it before the editor launches; here the manifest
# reference is enough, which the ported contracts' passing tests on all sixteen legs demonstrate.
#
# The analyzer's presence, label, platform settings and uniqueness are asserted by
# scripts/tests/test-analyzer-placement.js, which runs in two workflows. Restating its expected path
# here would be a second copy of that contract, free to drift, and a wrong path would red every Unity
# leg at once -- so this stays a diagnostic and the contract stays there.

function Write-AnalyzerSetupDiagnostics {
    param(
        [Parameter(Mandatory = $true)][string]$Project,
        [string]$LogPath,
        [Parameter(Mandatory = $true)][string]$Label
    )

    $null = $Project
    $null = $LogPath
    Write-Host ("::notice::unity-helpers ships its Roslyn analyzer inside the package at " +
        "Runtime/Analyzers/ and Unity registers it from there; no analyzer is copied into the CI " +
        "project. Placement is asserted by scripts/tests/test-analyzer-placement.js ($Label).")
}

function Set-EphemeralProjectContent {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$Content
    )

    $needsWrite = -not (Test-Path -LiteralPath $Path -PathType Leaf)
    if (-not $needsWrite) {
        $existing = [IO.File]::ReadAllText($Path)
        $needsWrite = ($existing.TrimEnd("`r", "`n") -cne $Content.TrimEnd("`r", "`n"))
    }
    if ($needsWrite) {
        $Content | Set-Content -LiteralPath $Path -Encoding UTF8
    }
}

function Initialize-EphemeralScriptingDefines {
    param(
        [Parameter(Mandatory = $true)][string]$Project,
        [Parameter(Mandatory = $true)][string]$Version,
        [string]$Defines = ''
    )

    if ($Version -notmatch '^6000\.') { return }

    $symbols = @(
        $Defines -split '[,;]' |
            ForEach-Object { $_.Trim() } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            Select-Object -Unique
    )
    if ($symbols.Count -eq 0) { return }

    $path = Join-Path $Project 'ProjectSettings/ProjectSettings.asset'
    if (Test-Path -LiteralPath $path -PathType Leaf) { return }

    $quotedSymbols = ConvertTo-Json -InputObject ($symbols -join ';') -Compress
    $content = @"
%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!129 &1
PlayerSettings:
  serializedVersion: 26
  scriptingDefineSymbols:
    Standalone: $quotedSymbols
"@
    try {
        $stream = [IO.File]::Open($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    } catch [IO.IOException] {
        if (Test-Path -LiteralPath $path -PathType Leaf) { return }
        throw
    }
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes("$content`n")
        $stream.Write($bytes, 0, $bytes.Length)
    } finally {
        $stream.Dispose()
    }
}

function Initialize-EphemeralProject {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$Version,
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$IncludeComparisons,
        [switch]$IncludeIntegrations,
        [string]$Backend = 'IL2CPP',
        [ValidateSet('Release', 'Debug')]
        [string]$Il2CppCompilerConfiguration = 'Release',
        [ValidateSet('Disabled', 'Low', 'Medium', 'High')]
        [string]$ManagedStrippingLevel = 'Disabled',
        [bool]$DevelopmentBuild = $false,
        [switch]$RequireReleaseManagedCodeVariant,
        [string]$ScriptingDefines = '',
        [string]$RepoRoot
    )

    # The comparison/integration package single sources live at the repo root.
    # Default to -Root when no explicit -RepoRoot is threaded (the package source
    # root is the repo root in this harness), so New-ManifestJson can read them.
    if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
        $RepoRoot = $Root
    }

    # Resolve-UnityProjectWorkspace is the single authority on WHERE the project
    # lives; this function only builds one. A second, divergent computation here is
    # how the persistent root and the repo-local default would silently drift apart.
    $project = Resolve-FullPath -Path $Path

    New-Item -ItemType Directory -Force -Path (Join-Path $project 'Packages') | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $project 'ProjectSettings') | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $project 'Assets\Editor') | Out-Null

    Initialize-EphemeralScriptingDefines -Project $project -Version $Version -Defines $ScriptingDefines

    $testLinkerSource = Join-Path $Root 'Tests/Runtime/Serialization/link.xml'
    $testLinkerTarget = Join-Path $project 'Assets/UhCiTestLinker/link.xml'
    if (Test-Path -LiteralPath $testLinkerSource -PathType Leaf) {
        $null = New-Item -ItemType Directory -Force -Path (Split-Path -Parent $testLinkerTarget)
        Set-EphemeralProjectContent -Path $testLinkerTarget -Content ([IO.File]::ReadAllText($testLinkerSource))
    }
    else {
        foreach ($staleTestLinkerPath in @($testLinkerTarget, "$testLinkerTarget.meta")) {
            if (Test-Path -LiteralPath $staleTestLinkerPath -PathType Leaf) {
                Remove-Item -LiteralPath $staleTestLinkerPath
            }
        }
    }

    Set-EphemeralProjectContent `
        -Path (Join-Path $project 'Packages\manifest.json') `
        -Content (New-ManifestJson -Root $Root -IncludeComparisons:$IncludeComparisons -IncludeIntegrations:$IncludeIntegrations -RepoRoot $RepoRoot)
    Set-EphemeralProjectContent `
        -Path (Join-Path $project 'ProjectSettings\ProjectVersion.txt') `
        -Content "m_EditorVersion: $Version`n"
    # Force 2D Default Behavior Mode (kept in sync with create-test-project.sh Step 3b).
    # unity-helpers is a 2D sprite-tooling package whose dev environment and entire
    # validated test suite run in 2D mode. Without this seed the ephemeral project defaults
    # to 3D, where fresh PNGs import as TextureImporterType.Default with npotScale=ToNearest
    # -- rounding NPOT dimensions (e.g. 10x6 -> 8x8) and omitting the Sprite sub-asset -- so
    # texture/sprite tests that pass locally fail in CI. A partial EditorSettings.asset seeds
    # the mode (Unity fills the rest); UhCiTestConfigurator's later SaveAssets preserves it.
    # ProjectBehaviorModeTests guards against silent regression.
    $editorSettings = @'
%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!159 &1
EditorSettings:
  m_DefaultBehaviorMode: 1
'@
    Set-EphemeralProjectContent `
        -Path (Join-Path $project 'ProjectSettings\EditorSettings.asset') `
        -Content $editorSettings
    Set-EphemeralProjectContent `
        -Path (Join-Path $project 'Assets\Editor\UhCiTestConfigurator.cs') `
        -Content (New-ConfiguratorSource -Backend $Backend -CompilerConfiguration $Il2CppCompilerConfiguration -StrippingLevel $ManagedStrippingLevel -RequireReleaseManagedCodeVariant:$RequireReleaseManagedCodeVariant)

    $frameworkEvidence = Join-Path $project 'Assets/UhCiTestFrameworkEvidence/Editor'
    $null = New-Item -ItemType Directory -Force -Path $frameworkEvidence
    foreach ($extension in @('cs', 'asmdef')) {
        Set-EphemeralProjectContent -Path (Join-Path $frameworkEvidence "UhCiTestFrameworkEvidence.$extension") `
            -Content ([IO.File]::ReadAllText((Join-Path $RepoRoot "scripts/unity/test-framework-evidence.$extension.txt")))
    }

    # STANDALONE ONLY: generate the split-build helpers that sever the test
    # player's PlayerConnection/TCP result streaming (the 10060 hang on multi-NIC
    # self-hosted runners). The Editor-side build modifier clears the player's
    # outbound-connection BuildOptions and exits the editor after the build; the
    # player-side TestRunCallback writes NUnit XML to -uhTestResults and quits.
    # Written idempotently (only when missing or changed), so reruns against the
    # cached project do not needlessly invalidate Unity's import cache.
    # editmode/playmode never emit these files (the local single -runTests path
    # is untouched).
    if ($Mode -eq 'standalone') {
        $standaloneFiles = @(
            @{ Path = (Join-Path $project 'Assets\Editor\UhCiStandaloneBuildModifier.cs'); Content = (New-StandaloneBuildModifierSource -DevelopmentBuild $DevelopmentBuild) },
            @{ Path = (Join-Path $project 'Assets\UhCiStandaloneTestCallback\UhCiStandaloneTestCallback.cs'); Content = (New-StandaloneTestCallbackSource) },
            @{ Path = (Join-Path $project 'Assets\UhCiStandaloneTestCallback\UhCiStandaloneTestCallback.asmdef'); Content = (New-StandaloneTestCallbackAsmdef) }
        )
        foreach ($file in $standaloneFiles) {
            $dir = Split-Path -Parent $file.Path
            if ($dir -and -not (Test-Path -LiteralPath $dir -PathType Container)) {
                New-Item -ItemType Directory -Force -Path $dir | Out-Null
            }
            Set-EphemeralProjectContent -Path $file.Path -Content $file.Content
        }
        Write-Host "::group::unity-helpers standalone split-build helpers"
        Write-Host "Generated the standalone build modifier + player TestRunCallback under $project (file-based results; no PlayerConnection)."
        foreach ($file in $standaloneFiles) {
            Write-Host "  $($file.Path)"
        }
        Write-Host "::endgroup::"
    }

    return $project
}

function Get-UnityActivationRetryBudgetSeconds {
    # Total wall-clock budget for RETRYING transient Unity serial-activation
    # failures. This exists for issue #57: the organization build lock's release
    # cooldown is deliberately near-zero, so when this run acquires a seat the
    # PRIOR holder's activation may not have propagated as returned yet and Unity
    # answers 20111 "maximum number of activations". That is transient seat
    # contention, so activation retries (bounded) until the seat frees instead of
    # the lock blindly holding a slot for minutes. Honors
    # UH_ACTIVATION_RETRY_BUDGET_SECONDS. Default 360s matches the previously
    # observed ~5-minute Unity activation handoff plus a margin. A NON-INTEGER or
    # NEGATIVE override is ignored with a ::warning:: and the default is used. 0 is
    # the explicit OPT-OUT: a single attempt with legacy fail-fast behavior (no
    # retry) -- note this differs from the *-TIMEOUT_SECONDS helpers where 0 means
    # "unbounded", because an unbounded activation retry could pin a lock slot
    # forever on a real capacity leak. Mirrors Get-StandaloneTestPlayerTimeoutSeconds's
    # env-parse idiom. StrictMode-safe: no collection reads.
    param([int]$Default = 360)

    if ($env:UH_ACTIVATION_RETRY_BUDGET_SECONDS) {
        $parsed = 0
        if (
            [int]::TryParse($env:UH_ACTIVATION_RETRY_BUDGET_SECONDS, [ref]$parsed) -and
            $parsed -ge 0
        ) {
            return $parsed
        }
        Write-Host "::warning::Ignoring invalid UH_ACTIVATION_RETRY_BUDGET_SECONDS='$env:UH_ACTIVATION_RETRY_BUDGET_SECONDS'; using $Default second(s)."
    }
    return $Default
}

function Get-UnityActivationRetryDelaySeconds {
    # Deterministic (pre-jitter) exponential backoff CEILING for activation retry
    # attempt N (1-based): min(CapSeconds, BaseSeconds * 2^(N-1)). The caller adds
    # bounded random jitter and additionally clamps the sleep so it never overruns
    # the retry-budget deadline. Pure + StrictMode-safe so the backoff policy is
    # unit-tested without launching Unity.
    param(
        [Parameter(Mandatory = $true)][int]$Attempt,
        [int]$BaseSeconds = 5,
        [int]$CapSeconds = 30
    )

    if ($Attempt -lt 1) { $Attempt = 1 }
    # Clamp the exponent so 2^(N-1) cannot overflow on a pathologically high attempt
    # count; the min() against CapSeconds makes anything past the cap moot anyway.
    $exponent = [Math]::Min($Attempt - 1, 30)
    $scaled = [double]$BaseSeconds * [Math]::Pow(2, $exponent)
    $ceiling = [Math]::Min([double]$CapSeconds, $scaled)
    return [int][Math]::Ceiling($ceiling)
}

function Get-UnityActivationFailureClass {
    # PURE classifier for a Unity SERIAL-activation attempt: given the editor exit
    # code and the (possibly empty) activation log text, decide whether the run
    # should proceed, retry, or fail fast. Returns a StrictMode-safe object with
    #   Class  = 'success' | 'retryable' | 'hard'
    #   Reason = a stable, credential-free tag for diagnostics
    #
    # Contract (see the org lock's RESOURCE_REASON_CODES + secure-two-seat-rollout):
    #   * exit 0                                 -> success / activated
    #   * 20111 "maximum number of activations"  -> retryable / account-limit-20111
    #       The SEAT-CONTENTION signal. The lock caps concurrent holders, so a 20111
    #       here is either a transient handoff (previous seat still freeing -> clears
    #       within the budget) or a real capacity leak (persists). We retry it ONLY
    #       within the bounded budget; a 20111 that survives the deadline is re-thrown
    #       with the 20111 evidence still in the (OVERWRITTEN, final-attempt)
    #       activation log, so the EXISTING return-side classifier still raises the
    #       account-blocked incident. We never treat 20111 as success and never reset
    #       the incident path.
    #   * 20113 "serial expired"                 -> hard / serial-expired-20113
    #       Calendar expiry; retrying is pointless until the serial is rotated.
    #   * any other non-zero exit                -> retryable / unknown
    #       Covers process kills (124/137/143), transient network/token licensing
    #       errors (20105/20120/...), and unforeseen transients. Bounded by the
    #       budget, so a genuine misconfiguration costs at most one budget then
    #       surfaces the real error.
    # The \b-style non-digit guards keep 201110 / 120111 from matching 20111.
    # StrictMode-safe: no collection reads.
    param(
        [Parameter(Mandatory = $true)][int]$ExitCode,
        [string]$LogText = ''
    )

    if ($ExitCode -eq 0) {
        return [pscustomobject]@{ Class = 'success'; Reason = 'activated' }
    }

    $text = if ($null -eq $LogText) { '' } else { [string]$LogText }

    if (
        $text -match '(?i)maximum number of activations' -or
        $text -match '(?<![0-9])20111(?![0-9])'
    ) {
        return [pscustomobject]@{ Class = 'retryable'; Reason = 'account-limit-20111' }
    }

    if (
        $text -match '(?i)serial expired' -or
        $text -match '(?<![0-9])20113(?![0-9])'
    ) {
        return [pscustomobject]@{ Class = 'hard'; Reason = 'serial-expired-20113' }
    }

    return [pscustomobject]@{ Class = 'retryable'; Reason = 'unknown' }
}

function Invoke-UnityLicenseActivate {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string]$Serial,
        [Parameter(Mandatory = $true)][string]$Email,
        [Parameter(Mandatory = $true)][string]$Password,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [int]$RetryBudgetSeconds = -1,
        # TESTABILITY SEAM (never passed in production): an optional invoker
        # `{ param($activateArgs, $logPath) ... return [int]$exitCode }` that stands
        # in for the real editor launch so the retry/deadline/backoff loop can be
        # exercised cross-platform without Unity. When $null (the default) the real
        # `& $EditorPath ... | Tee-Object` path runs and production behavior is
        # byte-for-byte unchanged.
        [scriptblock]$ActivationInvoker = $null
    )

    # Classic SERIAL activation: an editor invocation that activates the paid Unity
    # seat and immediately quits. This MUST succeed before the test run, so unlike
    # the best-effort return path a terminal failure THROWS -- an unlicensed test
    # editor fails opaquely.
    #
    # RETRY (issue #57): the organization lock's release cooldown is intentionally
    # near-zero, so when this run acquires a seat the PRIOR holder's activation may
    # not have propagated as returned yet and Unity answers 20111 "maximum number of
    # activations". That is transient seat contention, not a hard error, so we retry
    # within a bounded wall-clock budget (Get-UnityActivationRetryBudgetSeconds) with
    # jittered exponential backoff (Get-UnityActivationRetryDelaySeconds). A 20111
    # that SURVIVES the budget is a real capacity leak: we re-throw with the 20111
    # evidence still in the activation log so the existing return-side classifier
    # raises the account incident. Permanent failures (serial expiry) fail fast.
    $logDir = Split-Path -Parent $LogPath
    if ($logDir -and -not (Test-Path -LiteralPath $logDir -PathType Container)) {
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    }

    # SECURITY: the serial/email/password ride in the argument array, so this site
    # must NEVER echo the args (no "...$activateArgs..." Write-Host). The caller
    # passes a $LogPath under a NON-uploaded temp dir (RUNNER_TEMP / system temp),
    # never under $ArtifactsPath. Tee-Object OVERWRITES $LogPath each attempt, so the
    # log reflects only the FINAL attempt: a success after a transient 20111 leaves a
    # clean log (no stale 20111 for the return classifier to mis-read as an incident),
    # while a persistent 20111 leaves the 20111 intact for the incident path.
    $activateArgs = @(
        '-quit',
        '-batchmode',
        '-nographics',
        '-serial', $Serial,
        '-username', $Email,
        '-password', $Password,
        '-logFile', '-'
    )

    if ($RetryBudgetSeconds -lt 0) {
        $RetryBudgetSeconds = Get-UnityActivationRetryBudgetSeconds
    }
    $deadline = (Get-Date).AddSeconds($RetryBudgetSeconds)
    $attempt = 0

    while ($true) {
        $attempt++

        if ($ActivationInvoker) {
            $exitCode = [int](& $ActivationInvoker $activateArgs $LogPath)
        } else {
            Write-Host "::group::Activate Unity license (serial) attempt $attempt"
            # Unity.exe is a Windows GUI-subsystem binary: `&` does NOT wait for it or
            # set $LASTEXITCODE unless its stdout is consumed. `-logFile -` + Tee-Object
            # forces the wait, sets $LASTEXITCODE, and (over)writes the non-uploaded log.
            & $EditorPath @activateArgs 2>&1 | Tee-Object -FilePath $LogPath | ForEach-Object { Write-Host (ConvertTo-UnitySafeLogText -Text ([string]$_)) }
            $exitCode = $LASTEXITCODE
            Write-Host "::endgroup::"
        }

        $logText = ''
        try {
            if (Test-Path -LiteralPath $LogPath -PathType Leaf) {
                $rawLog = Get-Content -LiteralPath $LogPath -Raw -ErrorAction Stop
                if ($null -ne $rawLog) { $logText = $rawLog }
            }
        } catch {
            $logText = ''
        }

        $decision = Get-UnityActivationFailureClass -ExitCode $exitCode -LogText $logText

        if ($decision.Class -eq 'success') {
            if ($attempt -gt 1) {
                Write-CiNotice "Activated the Unity license (serial) on attempt $attempt."
            } else {
                Write-CiNotice 'Activated the Unity license (serial).'
            }
            return
        }

        # Every throw names the failure class + reason + attempt count + the
        # (non-uploaded) log path ONLY -- never the serial/email/password values.
        if ($decision.Class -eq 'hard') {
            throw "Unity license activation failed with exit code $exitCode (reason=$($decision.Reason)) after $attempt attempt(s); not retryable. See the activation log at $LogPath (not uploaded as an artifact)."
        }

        $remainingSeconds = ($deadline - (Get-Date)).TotalSeconds
        if ($RetryBudgetSeconds -le 0 -or $remainingSeconds -le 0) {
            throw "Unity license activation failed with exit code $exitCode (reason=$($decision.Reason)) after $attempt attempt(s) within a $RetryBudgetSeconds s retry budget. See the activation log at $LogPath (not uploaded as an artifact)."
        }

        $delaySeconds = Get-UnityActivationRetryDelaySeconds -Attempt $attempt
        # Full jitter in [1, delay], then clamp so we never sleep past the deadline
        # (min 1s so a tiny remaining budget still makes one more attempt).
        $jittered = Get-Random -Minimum 1 -Maximum ($delaySeconds + 1)
        $sleepSeconds = [int][Math]::Max(1, [Math]::Min([double]$jittered, $remainingSeconds))
        Write-Host "::warning::Unity license activation attempt $attempt failed (exit code $exitCode, reason=$($decision.Reason)); retrying in ${sleepSeconds}s (~$([int]$remainingSeconds)s of retry budget left). Expected transient seat contention under the organization lock's near-zero release cooldown."
        Start-Sleep -Seconds $sleepSeconds
    }
}

function Invoke-UnityLicenseReturn {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string]$Email,
        [Parameter(Mandatory = $true)][string]$Password,
        [Parameter(Mandatory = $true)][string]$LogPath
    )

    # Best-effort, defense-in-depth: this MUST NEVER throw. The license is also
    # returned by the workflow if:always() step (a backstop for a hard-killed
    # editor that never reaches this finally) and by the NEXT run's
    # return-at-start (which attempts cleanup after an interrupted prior run on
    # this persistent self-hosted runner). Final central evidence decides health.
    try {
        $logDir = Split-Path -Parent $LogPath
        if ($logDir -and -not (Test-Path -LiteralPath $logDir -PathType Container)) {
            New-Item -ItemType Directory -Force -Path $logDir | Out-Null
        }

        # SECURITY: email/password ride in the argument array; never echo the args
        # and keep the return log in the NON-uploaded temp dir, never under
        # $ArtifactsPath.
        $returnArgs = @(
            '-quit',
            '-batchmode',
            '-nographics',
            '-returnlicense',
            '-username', $Email,
            '-password', $Password,
            '-logFile', '-'
        )

        Write-Host "::group::Return Unity license (serial)"
        # Consume the GUI-subsystem process through a pipeline so PowerShell waits
        # and records LASTEXITCODE, but write directly to the private log. Unity
        # return output can contain account or serial fragments and must not reach
        # the workflow log.
        & $EditorPath @returnArgs 2>&1 | Out-File -FilePath $LogPath -Encoding utf8
        $exitCode = $LASTEXITCODE
        Add-Content -LiteralPath $LogPath -Value "exit_return_rc=$exitCode" -Encoding utf8
        Write-Host "::endgroup::"

        $ulfReturnSkipped = Select-String `
            -LiteralPath $LogPath `
            -Pattern '^\s*(?:Serial number unavailable for ULF return|\[Licensing::Module\] Error: Serial number unavailable for ULF return; skipping operation)\s*$' `
            -CaseSensitive `
            -Quiet
        if ($ulfReturnSkipped) {
            Write-Host "::warning::Unity skipped ULF return; exact cleanup evidence was not confirmed (exit code $exitCode). The workflow if:always() return step evaluates final cleanup; the next run also attempts return-at-start."
        } elseif ($exitCode -ne 0) {
            Write-Host "::warning::Unity license return exited with code $exitCode; exact ULF cleanup evidence was not confirmed. The workflow if:always() return step evaluates final cleanup; the next run also attempts return-at-start."
        } else {
            Write-CiNotice 'Unity license return process exited with code 0; final cleanup is evaluated separately.'
        }
    } catch {
        Write-Host "::warning::Unity license return failed: $($_.Exception.Message). The workflow if:always() return step and the next run's return-at-start are the backstops."
    }
}

function Get-StandaloneTestPlayerTimeoutSeconds {
    # Single source of truth for the TOTAL wall-clock timeout applied to the
    # DIRECTLY-LAUNCHED standalone test player (Invoke-StandaloneTestPlayer). The
    # player runs ~700 runtime tests headless in single-digit minutes; the 30 min
    # default is a generous backstop so a player that hangs (e.g. a residual
    # connection dial-out or a deadlocked test) is tree-killed instead of running
    # until the 120-minute GitHub step is cancelled. Mirrors ensure-editor.ps1
    # Get-EnsureEditorInstallTimeoutSeconds EXACTLY: honors
    # UH_STANDALONE_PLAYER_TIMEOUT_SECONDS; a non-integer or NEGATIVE override is
    # ignored with a ::warning:: and the default is used; 0 is the explicit OPT-OUT
    # (unbounded wait). StrictMode-safe: no collection reads.
    param([int]$Default = 1800)

    if ($env:UH_STANDALONE_PLAYER_TIMEOUT_SECONDS) {
        $parsed = 0
        if (
            [int]::TryParse($env:UH_STANDALONE_PLAYER_TIMEOUT_SECONDS, [ref]$parsed) -and
            $parsed -ge 0
        ) {
            return $parsed
        }
        Write-Host "::warning::Ignoring invalid UH_STANDALONE_PLAYER_TIMEOUT_SECONDS='$env:UH_STANDALONE_PLAYER_TIMEOUT_SECONDS'; using $Default second(s)."
    }
    return $Default
}

function Get-StandaloneBuildTimeoutSeconds {
    # Single source of truth for the TOTAL wall-clock timeout applied to the editor
    # BUILD step that produces the standalone IL2CPP test player. The IL2CPP build
    # is the long pole; the 45 min default matches the install default and comfortably
    # exceeds a slow-but-progressing build, so a build that idles forever (e.g. the
    # PostBuildCleanup exit never fired because the modifier failed to compile and
    # AutoRunPlayer stayed set) is tree-killed instead of consuming the 120-minute
    # GitHub step. Mirrors ensure-editor.ps1 Get-EnsureEditorInstallTimeoutSeconds
    # EXACTLY: honors UH_STANDALONE_BUILD_TIMEOUT_SECONDS; a non-integer or NEGATIVE
    # override is ignored with a ::warning:: and the default is used; 0 is the
    # explicit OPT-OUT (unbounded wait). StrictMode-safe: no collection reads.
    param([int]$Default = 2700)

    if ($env:UH_STANDALONE_BUILD_TIMEOUT_SECONDS) {
        $parsed = 0
        if (
            [int]::TryParse($env:UH_STANDALONE_BUILD_TIMEOUT_SECONDS, [ref]$parsed) -and
            $parsed -ge 0
        ) {
            return $parsed
        }
        Write-Host "::warning::Ignoring invalid UH_STANDALONE_BUILD_TIMEOUT_SECONDS='$env:UH_STANDALONE_BUILD_TIMEOUT_SECONDS'; using $Default second(s)."
    }
    return $Default
}

function ConvertTo-ProcessArgumentLine {
    # MIRROR of scripts/unity/ensure-editor.ps1 ConvertTo-ProcessArgumentLine
    # (run-ci-tests.ps1 does not import that script, so the helper is copied here
    # verbatim). Builds a single Windows command-line argument string from an array,
    # quoting any argument containing whitespace or a quote and escaping embedded
    # backslashes/quotes per the CommandLineToArgvW rules. Used by
    # Invoke-ProcessWithTreeKillTimeout (it assigns ProcessStartInfo.Arguments, the
    # single command-line string form, NOT the per-element argument-list property
    # the contract forbids).
    param([string[]]$Arguments)

    $quoted = foreach ($arg in @($Arguments)) {
        if ($null -eq $arg) {
            '""'
            continue
        }

        $value = [string]$arg
        if ($value.Length -gt 0 -and $value -notmatch '[\s"]') {
            $value
            continue
        }

        $builder = New-Object System.Text.StringBuilder
        [void]$builder.Append('"')
        $backslashes = 0
        foreach ($ch in $value.ToCharArray()) {
            if ($ch -eq '\') {
                $backslashes++
                continue
            }

            if ($ch -eq '"') {
                if ($backslashes -gt 0) {
                    [void]$builder.Append('\' * ($backslashes * 2))
                }
                [void]$builder.Append('\"')
                $backslashes = 0
                continue
            }

            if ($backslashes -gt 0) {
                [void]$builder.Append('\' * $backslashes)
                $backslashes = 0
            }
            [void]$builder.Append($ch)
        }

        if ($backslashes -gt 0) {
            [void]$builder.Append('\' * ($backslashes * 2))
        }
        [void]$builder.Append('"')
        $builder.ToString()
    }

    return ($quoted -join ' ')
}

function Set-CompletionGraceDeadline {
    # Helper for Invoke-ProcessWithTreeKillTimeout's completion-sentinel handling. If
    # $Line matches $Pattern (and a pattern was supplied), arms the grace countdown:
    # sets $Armed to $true, parses the "Exiting with code N" exit code into $ExitCode
    # when present, and returns the tightened deadline (the earlier of the current
    # deadline and now + $GraceSeconds). Otherwise returns $CurrentDeadline unchanged.
    # StrictMode-safe: no uninitialized reads, no collection indexing.
    param(
        [string]$Line,
        [string]$Pattern,
        [int]$GraceSeconds,
        [DateTime]$CurrentDeadline,
        [Parameter(Mandatory = $true)][ref]$Armed,
        [Parameter(Mandatory = $true)][ref]$ExitCode,
        [string]$Label = ''
    )

    if ([string]::IsNullOrEmpty($Pattern)) {
        return $CurrentDeadline
    }
    if ($Line -notmatch $Pattern) {
        return $CurrentDeadline
    }

    $Armed.Value = $true

    $codeMatch = [regex]::Match($Line, 'Exiting with code (\d+)')
    if ($codeMatch.Success) {
        $parsed = 0
        if ([int]::TryParse($codeMatch.Groups[1].Value, [ref]$parsed)) {
            $ExitCode.Value = $parsed
        }
    }

    Write-Host "::notice::'$Label' logged a completion sentinel; results are already written. Will tree-kill the editor in up to $GraceSeconds s if it does not exit on its own (Unity 2021.3 batchmode shutdown-deadlock guard)."

    $graceDeadline = [DateTime]::UtcNow.AddSeconds([double]$GraceSeconds)
    if ($graceDeadline -lt $CurrentDeadline) {
        return $graceDeadline
    }
    return $CurrentDeadline
}

function Invoke-ProcessWithTreeKillTimeout {
    # GENERALIZED hard tree-kill watchdog, STRUCTURALLY IDENTICAL to
    # scripts/unity/ensure-editor.ps1 Invoke-UnityCliCaptureWithTimeout (the proven
    # resilience core). It launches $FilePath with $Arguments via
    # System.Diagnostics.Process + ProcessStartInfo, drains BOTH stdout and stderr
    # from a MAIN-THREAD ReadLineAsync poll loop (live echo via Write-Host + Tee to
    # $LogPath), enforces an absolute UTC deadline, and on a breach $proc.Kill($true)
    # tree-kills the whole process tree (the Unity editor build spawns child
    # processes -- IL2CPP/bee -- and the player may too, so a bare Kill() would orphan
    # them). The process is held in a try/finally that kills it on ANY throw between
    # launch and reap, so a pwsh cancellation cannot leave an orphaned editor/player.
    #
    # WHY a Process and NOT `& <exe>`: the call operator cannot be interrupted -- a
    # hung child runs until the whole job is killed. WHY the main-thread poll loop:
    # every line is echoed LIVE the instant it arrives (no silent multi-minute build
    # console) AND both pipes are continuously drained so neither can fill and
    # back-pressure the child (the classic full-pipe-buffer deadlock is impossible).
    # A Process.Start() launch is NOT an `&`/`.` call, so it does not trip the
    # powershell-unity-process-wait-safety parser rule; the contract test additionally
    # forbids a bare empty-parens WaitForExit and the per-element argument-list
    # property here, both of which this implementation avoids.
    #
    # Returns a StrictMode-safe hashtable @{ ExitCode; TimedOut }. The caller throws
    # on $TimedOut or a non-zero $ExitCode; the FILE written by the player is the
    # source of truth for pass/fail.
    #
    # COMPLETION SENTINEL (optional): some Unity versions (notably 2021.3 in
    # -batchmode) finish the test run -- writing the authoritative results.xml and
    # logging "Test run completed. Exiting with code N" -- and then DEADLOCK on
    # shutdown, never terminating and never closing their stdout/stderr pipes. A bare
    # wall-clock deadline would let that hang burn the full timeout. When
    # $CompletionPattern is supplied, the FIRST log line matching it arms a short
    # $CompletionGraceSeconds countdown; if the process still has not exited on its
    # own when the countdown elapses, it is tree-killed and the run is reported as a
    # NORMAL completion (TimedOut=$false) carrying the exit code parsed from the
    # sentinel ("Exiting with code N"). The durable results.xml -- already written
    # before the sentinel -- remains the source of truth, so a passing run still
    # passes. A run that never logs the sentinel (e.g. a compile failure) falls back
    # to the plain wall-clock deadline.
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string[]]$Arguments,
        [int]$TimeoutSeconds = 1800,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [Parameter(Mandatory = $true)][string]$Label,
        [string]$CompletionPattern = '',
        [int]$CompletionGraceSeconds = 120,
        # No-output stall guard. When > 0, the process is tree-killed if it emits NO new
        # stdout/stderr line for this many seconds WHILE THE RUN IS STILL IN PROGRESS
        # (i.e. before the completion sentinel arms). 0 disables it. This is the guard for
        # a MID-RUN silent hang -- e.g. a PlayMode test whose background coroutine throws
        # and wedges the runner with zero further output -- which the wall-clock deadline
        # alone would let burn the full TimeoutSeconds. Deliberately SUSPENDED once the
        # completion sentinel is seen, because the editor legitimately goes quiet while
        # flushing results during the grace window (that case is the completion guard's).
        [int]$StallSeconds = 0,
        [hashtable]$ProcessObservation
    )

    $logDir = Split-Path -Parent $LogPath
    if ($logDir -and -not (Test-Path -LiteralPath $logDir -PathType Container)) {
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    }

    # Sentinel exit code for a wall-clock timeout kill. 124 mirrors GNU coreutils
    # `timeout`; it is non-zero so the caller's "exit != 0 -> fail" path applies.
    $timeoutExitCode = 124
    # Sentinel exit code for a no-output stall kill. 125 is one above the wall-clock 124
    # so the two watchdog kills are distinguishable in the log: each emits its own
    # ::error:: and a distinct, greppable exit code. (NOT added to the
    # $NativeExitCodeDescriptions table on purpose: that table also drives
    # Test-NativeCrashExitCode, which must not classify a watchdog kill as a native
    # crash.) The durable results.xml stays the pass/fail source of truth either way.
    $stallExitCode = 125

    Write-Host "::group::$Label"
    Write-Host "`"$FilePath`" $($Arguments -join ' ')"

    $buffer = New-Object System.Collections.Generic.List[string]

    if ($TimeoutSeconds -le 0) {
        $hasDeadline = $false
        $timeoutMs = -1
    } else {
        $hasDeadline = $true
        $timeoutMsLong = [int64]$TimeoutSeconds * 1000
        if ($timeoutMsLong -gt [int64]::MaxValue - 1) {
            $timeoutMs = [int64]::MaxValue - 1
        } else {
            $timeoutMs = $timeoutMsLong
        }
    }

    $proc = $null
    $exit = -1
    $timedOut = $false
    $reaped = $false
    $stalled = $false
    $stallEnabled = $StallSeconds -gt 0
    $completionArmed = $false
    $completionExitCode = $null
    $killedAfterCompletion = $false
    $observedProcessId = $null
    $launchUtc = [DateTime]::UtcNow
    $rawExitCode = $null
    $exitOrigin = 'unobserved'
    $killReason = $null
    $killSucceeded = $false
    $exceptionType = $null
    $processExitUtc = $null
    $postExitDrainStarted = $null
    $postExitLastOutput = $null
    $outputDrainStopped = $false
    $oDone = $false
    $eDone = $false
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $FilePath
        $psi.Arguments = ConvertTo-ProcessArgumentLine -Arguments $Arguments
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi

        [void]$proc.Start()
        try { $observedProcessId = $proc.Id } catch { }

        $outReader = $proc.StandardOutput
        $errReader = $proc.StandardError
        $oTask = $outReader.ReadLineAsync()
        $eTask = $errReader.ReadLineAsync()

        # Stall clock: reset on every line received (see the poll loop below); measures
        # time since the last output. Initialized at launch so a process that prints
        # NOTHING at all is still bounded by the stall guard, not just the wall clock.
        $lastOutputAt = [DateTime]::UtcNow
        # Heartbeat clock: throttles the "still alive" ::notice:: during a quiet stretch.
        $lastHeartbeatAt = [DateTime]::UtcNow

        if ($hasDeadline) {
            $deadline = [DateTime]::UtcNow.AddMilliseconds([double]$timeoutMs)
        } else {
            $deadline = [DateTime]::MaxValue
        }

        while (-not ($oDone -and $eDone)) {
            $progressed = $false

            if (-not $oDone -and $oTask.Wait(0)) {
                $line = $oTask.Result
                if ($null -eq $line) {
                    $oDone = $true
                } else {
                    Write-Host (ConvertTo-UnitySafeLogText -Text $line)
                    $buffer.Add([string]$line)
                    if (-not $completionArmed) {
                        $deadline = Set-CompletionGraceDeadline -Line $line -Pattern $CompletionPattern -GraceSeconds $CompletionGraceSeconds -CurrentDeadline $deadline -Armed ([ref]$completionArmed) -ExitCode ([ref]$completionExitCode) -Label $Label
                    }
                    $oTask = $outReader.ReadLineAsync()
                    $lastOutputAt = [DateTime]::UtcNow
                }
                $progressed = $true
            }

            if (-not $eDone -and $eTask.Wait(0)) {
                $line = $eTask.Result
                if ($null -eq $line) {
                    $eDone = $true
                } else {
                    Write-Host (ConvertTo-UnitySafeLogText -Text $line)
                    $buffer.Add([string]$line)
                    if (-not $completionArmed) {
                        $deadline = Set-CompletionGraceDeadline -Line $line -Pattern $CompletionPattern -GraceSeconds $CompletionGraceSeconds -CurrentDeadline $deadline -Armed ([ref]$completionArmed) -ExitCode ([ref]$completionExitCode) -Label $Label
                    }
                    $eTask = $errReader.ReadLineAsync()
                    $lastOutputAt = [DateTime]::UtcNow
                }
                $progressed = $true
            }

            if ($proc.HasExited) {
                $now = [DateTime]::UtcNow
                if ($null -eq $postExitDrainStarted) {
                    try {
                        $reportedExitUtc = $proc.ExitTime.ToUniversalTime()
                        if ($launchUtc -le $reportedExitUtc -and $reportedExitUtc -le $now) {
                            $processExitUtc = $reportedExitUtc
                        }
                    } catch { }
                    $postExitDrainStarted = $now
                    $postExitLastOutput = $now
                }
                $exitWithinDeadline = if ($null -ne $processExitUtc) { $processExitUtc -le $deadline } else { $postExitDrainStarted -le $deadline }
                if ($exitWithinDeadline) {
                    if ($progressed) { $postExitLastOutput = $now }
                    if (($now - $postExitLastOutput).TotalSeconds -ge 1 -or ($now - $postExitDrainStarted).TotalSeconds -ge 5) {
                        $outputDrainStopped = -not ($oDone -and $eDone)
                        if ($outputDrainStopped) {
                            Write-Host "::notice::$Label process exited; stopped waiting for open output streams."
                        }
                        break
                    }
                    if (-not $progressed) { Start-Sleep -Milliseconds 50 }
                    continue
                }
            }

            if ([DateTime]::UtcNow -ge $deadline) {
                # Either a true wall-clock breach, OR the completion-grace countdown
                # elapsed after the run finished but the editor hung on shutdown. The
                # latter is a NORMAL completion (results.xml already written), not a
                # timeout. Tree-kill the WHOLE process tree either way (the editor can
                # spawn children -- bee/IL2CPP -- so a bare Kill() would orphan them).
                if ($completionArmed) {
                    $killedAfterCompletion = $true
                } else {
                    $timedOut = $true
                }
                $killReason = if ($completionArmed) { 'completion-grace' } else { 'wall-timeout' }
                try {
                    $proc.Kill($true)
                    $killSucceeded = $true
                } catch {
                    try { $proc.Kill(); $killSucceeded = $true } catch { }
                }
                break
            }

            if (
                $stallEnabled -and
                -not $completionArmed -and
                ([DateTime]::UtcNow - $lastOutputAt).TotalSeconds -ge $StallSeconds
            ) {
                # No new output for $StallSeconds while the run is STILL in progress (the
                # completion sentinel has not armed): a silent MID-RUN hang -- e.g. a
                # PlayMode test whose background coroutine threw and wedged the runner.
                # The wall-clock deadline alone would let this burn the full window; the
                # stall guard tree-kills it in seconds. Flagged distinctly from a
                # wall-clock breach so the caller reports exit 125 (not 124).
                Write-Host "::error::$Label produced no output for ${StallSeconds}s (no-output stall) and was tree-killed. The wall-clock and completion-sentinel guards remain in force; raise the stall window if a run is legitimately silent for longer."
                $stalled = $true
                $killReason = 'stall-timeout'
                try {
                    $proc.Kill($true)
                    $killSucceeded = $true
                } catch {
                    try { $proc.Kill(); $killSucceeded = $true } catch { }
                }
                break
            }

            # Heartbeat: during a legitimately quiet stretch (run still in progress, no
            # output for a while but not yet a stall) emit a throttled ::notice:: so the CI
            # log is never fully silent and an operator can tell "slow but alive" from
            # "hung" without waiting for a kill. Suppressed on chatty runs (only after
            # >=20s of quiet) and after the completion sentinel; one line/minute max.
            # Diagnostic only -- never touches the exit decision.
            if (-not $completionArmed) {
                $quietSeconds = ([DateTime]::UtcNow - $lastOutputAt).TotalSeconds
                if (
                    $quietSeconds -ge 20 -and
                    ([DateTime]::UtcNow - $lastHeartbeatAt).TotalSeconds -ge 60
                ) {
                    $lastHeartbeatAt = [DateTime]::UtcNow
                    Write-Host "::notice::$Label is still running but has produced no new output for $([int]$quietSeconds)s (alive, not hung)."
                }
            }

            if (-not $progressed) {
                Start-Sleep -Milliseconds 50
            }
        }

        # Reap so ExitCode is valid; bounded so a stuck reap cannot hang the harness.
        $reaped = $proc.WaitForExit(5000)

        # Drain any reads that completed during/after the kill so no pre-kill output
        # is dropped.
        $pendingWaitMilliseconds = if ($outputDrainStopped) { 0 } else { 2000 }
        foreach ($pending in @($oTask, $eTask)) {
            try {
                if ($pending.Wait($pendingWaitMilliseconds) -and $null -ne $pending.Result) {
                    $line = $pending.Result
                    Write-Host (ConvertTo-UnitySafeLogText -Text $line)
                    $buffer.Add([string]$line)
                }
            } catch {
                # A faulted/cancelled read on a killed pipe carries nothing to add.
            }
        }

        try {
            if ($reaped -and $proc.HasExited) {
                $rawExitCode = $proc.ExitCode
                if ($null -eq $processExitUtc) {
                    $reportedExitUtc = $proc.ExitTime.ToUniversalTime()
                    if ($launchUtc -le $reportedExitUtc -and $reportedExitUtc -le [DateTime]::UtcNow) {
                        $processExitUtc = $reportedExitUtc
                    }
                }
            }
        } catch { }
        if ($killedAfterCompletion) {
            $exitOrigin = 'completion-grace'
            # The test run finished and wrote results.xml; the editor then hung on
            # shutdown and we tree-killed it after the grace window. This is NOT a
            # timeout -- report the exit code the runner logged in the sentinel (the
            # caller validates the durable results.xml regardless). Fall back to 0 if
            # the code could not be parsed, so a healthy run is never failed by the
            # shutdown deadlock alone.
            if ($null -ne $completionExitCode) {
                $exit = $completionExitCode
            } else {
                $exit = 0
            }
            $timedOut = $false
        } elseif ($stalled) {
            $exitOrigin = 'stall-timeout'
            # A no-output stall kill. Distinct exit code (125) from the wall-clock 124;
            # surfaced as a timeout-class failure ($timedOut) so a stalled run is never
            # mistaken for a clean exit by a caller that gates on TimedOut.
            $exit = $stallExitCode
            $timedOut = $true
        } elseif ($timedOut) {
            $exitOrigin = 'wall-timeout'
            $exit = $timeoutExitCode
        } elseif ($reaped -and $proc.HasExited) {
            $exitOrigin = 'process-exit'
            $exit = $proc.ExitCode
        } else {
            $exitOrigin = 'exit-not-observed'
            $exit = $timeoutExitCode
            $timedOut = $true
        }
    } catch {
        $message = "Process watchdog '$Label' threw: $($_.Exception.Message)"
        Write-Host "::warning::$message"
        $buffer.Add($message)
        $exit = -1
        $exitOrigin = 'watchdog-exception'
        $exceptionType = $_.Exception.GetType().FullName
    } finally {
        # If we are unwinding on a throw/cancellation and the process is still alive,
        # tree-kill it so a cancelled step never orphans the editor/player.
        if ($proc -and -not $proc.HasExited) {
            $killReason = 'finally-cleanup'
            try { $proc.Kill($true); $killSucceeded = $true } catch { }
        }
        if ($null -ne $ProcessObservation) {
            try {
                $ProcessObservation.Clear()
                $ProcessObservation.State = 'observed'
                $ProcessObservation.MachineName = [Environment]::MachineName
                $ProcessObservation['ExecutablePath'] = [IO.Path]::GetFullPath($FilePath)
                $ProcessObservation['ProcessId'] = $observedProcessId
                $ProcessObservation['LaunchUtc'] = $launchUtc.ToString('o')
                $ProcessObservation['EndObservedUtc'] = [DateTime]::UtcNow.ToString('o')
                $ProcessObservation.RawExitCode = $rawExitCode
                $ProcessObservation.ReturnedExitCode = $exit
                $ProcessObservation.ExitOrigin = $exitOrigin
                $ProcessObservation.KillReason = $killReason
                $ProcessObservation.KillSucceeded = $killSucceeded
                $ProcessObservation.ExceptionType = $exceptionType
                $ProcessObservation.ProcessExitUtc = if ($null -ne $processExitUtc) { $processExitUtc.ToString('o') } else { $null }
                $ProcessObservation.OutputDrainStopped = $outputDrainStopped
                $ProcessObservation.StandardOutputEndObserved = $oDone
                $ProcessObservation.StandardErrorEndObserved = $eDone
            } catch {
                Write-Host '::warning::Could not record process observation; execution outcome is unchanged.'
            }
        }
        if ($proc) { $proc.Dispose() }
    }

    Write-Host "::endgroup::"

    # Persist the captured (already-streamed) output to $LogPath for diagnostics.
    try {
        Set-Content -LiteralPath $LogPath -Value (@($buffer.ToArray()) -join "`n") -Encoding UTF8
        if ($null -ne $ProcessObservation) { $ProcessObservation['LogPersistence'] = 'written' }
    } catch {
        if ($null -ne $ProcessObservation) { $ProcessObservation['LogPersistence'] = 'write-failed' }
        Write-Host "::warning::Could not persist '$Label' log to ${LogPath}: $($_.Exception.Message)"
    }

    return @{
        ExitCode = $exit
        TimedOut = [bool]$timedOut
        Stalled  = [bool]$stalled
    }
}

# Opt-in diagnostic provenance only. Explicit input lists do not prove source coverage
# or that a player consumed the declared corpus; no campaign becomes eligible here.
function Read-FrozenPlayerDeclaration {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$UnityVersion,
        [Parameter(Mandatory = $true)][string]$Backend,
        [Parameter(Mandatory = $true)][string]$ArtifactsPath,
        [Parameter(Mandatory = $true)][string]$RepoRoot,
        [switch]$GenerateOnly,
        [switch]$BuildCaptureOnly
    )
    if ($Mode -ne 'standalone' -or $GenerateOnly) {
        throw 'FrozenPlayerDeclarationPath requires an executed standalone player run.'
    }
    $fullPath = [IO.Path]::GetFullPath($Path)
    $item = Get-Item -LiteralPath $fullPath -Force -ErrorAction Stop
    if ($item.PSIsContainer -or $item.Length -lt 1 -or $item.Length -gt 4194304 -or
        ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Frozen player declaration must be a nonempty regular file of at most 4 MiB.'
    }
    Assert-FrozenPlayerRegularPath -Path $fullPath
    $bytes = [IO.File]::ReadAllBytes($fullPath)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $hash = ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
    $declaration = (New-Object Text.UTF8Encoding($false, $true)).GetString($bytes).TrimStart([char]0xfeff) | ConvertFrom-Json -ErrorAction Stop
    if ($declaration.RunId -isnot [string] -or $declaration.UnityVersion -isnot [string] -or $declaration.Backend -isnot [string] -or
        $declaration.SchemaVersion -ne 1 -or [string]$declaration.RunId -cnotmatch '^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,62}[A-Za-z0-9_-])?$' -or
        $declaration.UnityVersion -cne $UnityVersion -or $declaration.Backend -cne $Backend) {
        throw 'Frozen declaration schema, RunId, Unity version, or backend does not match this request.'
    }
    $kind = 'borrowed-diagnostic'
    if ($declaration.PSObject.Properties.Name -contains 'CampaignKind') {
        if ($declaration.CampaignKind -isnot [string] -or $declaration.CampaignKind -cne 'wproto-seven-families-v1') {
            throw 'Unknown frozen player campaign kind.'
        }
        $kind = $declaration.CampaignKind
    }
    $maximumFiles = if ($kind -ceq 'wproto-seven-families-v1') { 16384 } else { 4096 }
    if ($kind -ceq 'borrowed-diagnostic' -and $bytes.Length -gt 1048576) { throw 'Borrowed declaration exceeds 1 MiB.' }
    if ($kind -ceq 'wproto-seven-families-v1') {
        if (($declaration.SchemaVersion -isnot [int] -and $declaration.SchemaVersion -isnot [long]) -or
            ($Backend -cne 'Mono2x' -and -not ($BuildCaptureOnly -and $Backend -ceq 'IL2CPP')) -or $declaration.SourceCommit -isnot [string] -or
            $declaration.SourceCommit -cnotmatch '^[a-f0-9]{40}$' -or
            $declaration.CanonicalCorpusPath -cne 'scripts/unity/wproto-corpus.v1.json') {
            throw 'WProto declaration requires Mono2x or an explicit IL2CPP build-only capture, an exact source commit, and the canonical synthetic corpus.'
        }
        Assert-WProtoSourceCensus -Repository $RepoRoot -DeclaredFiles $declaration.SourceFiles
    }
    foreach ($name in @('SourceFiles', 'CorpusFiles')) {
        $entries = @($declaration.$name)
        if ($entries.Count -lt 1 -or $entries.Count -gt $maximumFiles) { throw "Frozen declaration requires nonempty bounded $name." }
        Get-FrozenPlayerFileInventory -Root $RepoRoot -DeclaredFiles $entries -MaximumFiles $maximumFiles | Out-Null
    }
    $canonicalCorpus = $null
    if ($declaration.PSObject.Properties.Name -contains 'CanonicalCorpusPath') {
        if ($declaration.CanonicalCorpusPath -isnot [string]) { throw 'CanonicalCorpusPath must be a scalar string.' }
        $matching = @($declaration.CorpusFiles | Where-Object { $_.Path -ceq $declaration.CanonicalCorpusPath })
        if ($matching.Count -ne 1) { throw 'CanonicalCorpusPath must exactly identify one validated CorpusFiles entry.' }
        $canonicalCorpus = $matching[0]
    }
    $reportDirectory = Join-Path $ArtifactsPath "frozen-player-$($declaration.RunId)"
    if (Test-Path -LiteralPath $reportDirectory) { throw "Frozen RunId already has an output directory: $reportDirectory" }
    return [pscustomobject]@{ Path = $fullPath; Bytes = $bytes; Sha256 = $hash; Value = $declaration; ReportDirectory = $reportDirectory; CanonicalCorpus = $canonicalCorpus; CampaignKind = $kind; MaximumFiles = $maximumFiles }
}

function Start-FrozenPlayerProvenance {
    param(
        [Parameter(Mandatory = $true)]$Declaration,
        [Parameter(Mandatory = $true)][string]$RepoRoot,
        [Parameter(Mandatory = $true)][string]$PayloadRoot
    )
    $payloadPath = [IO.Path]::GetFullPath($PayloadRoot).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    foreach ($path in @($Declaration.Path, $Declaration.ReportDirectory)) {
        if ([IO.Path]::GetFullPath($path).StartsWith($payloadPath, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Frozen declaration and report must be outside the player payload.'
        }
    }
    Assert-FrozenPlayerRegularPath -Path (Split-Path -Parent $Declaration.ReportDirectory) -Directory
    New-Item -ItemType Directory -Path $Declaration.ReportDirectory -ErrorAction Stop | Out-Null
    $reportPath = Join-Path $Declaration.ReportDirectory 'provenance.json'
    $reservation = [IO.File]::Open($reportPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $reservation.Dispose()
    [IO.File]::WriteAllBytes((Join-Path $Declaration.ReportDirectory 'declaration.json'), $Declaration.Bytes)
    return [pscustomobject]@{
        Declaration = $Declaration; RepoRoot = $RepoRoot; PayloadRoot = $PayloadRoot; ReportPath = $reportPath
        Snapshots = (New-Object 'System.Collections.Generic.List[object]'); PayloadBaseline = $null
        GeneratedRoot = $null; GeneratedFiles = @()
        LaunchAttempted = $false; InvocationObserved = $false; ResultsValidated = $false; PlayerOutcome = $null; ExecutionError = $null
        ConfigureOutcomes = (New-Object 'System.Collections.Generic.List[object]'); BuildOutcome = $null
        ProjectSettingsBaseline = $null; BuildPreparation = $null; BuildPreparationSha256 = $null
        BuildObservation = $null; KnownFaultScan = $null; NativeSupportScans = @()
    }
}

function New-WProtoBuildPreparationSource {
    param([Parameter(Mandatory = $true)]$Context)
    $runId = $Context.Declaration.Value.RunId
    $declarationHash = $Context.Declaration.Sha256
    $commit = $Context.Declaration.Value.SourceCommit
    $receiptPath = (Join-Path $Context.Declaration.ReportDirectory 'build-preparation.json').Replace('"', '""')
    $year = (Get-Date).Year
    @"
// MIT License - Copyright (c) $year wallstop
// Full license text: https://github.com/wallstop/unity-helpers/blob/main/LICENSE

using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using UnityEditor;
using UnityEngine;

public sealed partial class UhCiStandaloneBuildModifier
{
    static partial void WriteFrozenBuildPreparation(BuildPlayerOptions playerOptions)
    {
#if UNITY_6000_6_OR_NEWER
        if (PlayerSettings.GetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone) == ScriptingImplementation.Mono2x)
        {
            PlayerSettings.SetManagedCodeVariant(UnityEditor.Build.NamedBuildTarget.Standalone, ManagedCodeVariant.Release);
        }
#endif
        WallstopStudios.UnityHelpers.Editor.Settings.UnityHelpersSettings.instance.SaveSettings();
        AssetDatabase.SaveAssets();
        string project = Directory.GetParent(Application.dataPath).FullName;
        List<string> entries = new List<string>();
        Stack<string> pending = new Stack<string>();
        foreach (string directory in new[] { "Assets", "Packages", "ProjectSettings" })
        {
            string root = Path.Combine(project, directory);
            if (!Directory.Exists(root) || (File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0)
            {
                throw new InvalidOperationException("Invalid WProto preparation root: " + directory);
            }
            pending.Push(root);
        }
        while (pending.TryPop(out string current))
        {
            foreach (string path in Directory.EnumerateFileSystemEntries(current))
            {
                FileAttributes attributes = File.GetAttributes(path);
                if ((attributes & FileAttributes.ReparsePoint) != 0 || 16384 <= entries.Count)
                {
                    throw new InvalidOperationException("Invalid or excessive WProto preparation inputs.");
                }
                entries.Add(path);
                if ((attributes & FileAttributes.Directory) != 0)
                {
                    pending.Push(path);
                }
            }
        }
        entries.Sort(StringComparer.Ordinal);
        string playerSettingsPath = Path.Combine(project, "ProjectSettings", "ProjectSettings.asset");
        FileInfo playerSettings = new FileInfo(playerSettingsPath);
        if ((playerSettings.Attributes & FileAttributes.ReparsePoint) != 0 || playerSettings.Length < 1 || 1048576 < playerSettings.Length)
        {
            throw new InvalidOperationException("Invalid WProto prepared player settings.");
        }
        File.Copy(playerSettingsPath, Path.Combine(Path.GetDirectoryName(@"$receiptPath"), "build-player-settings.asset"), false);
        using (FileStream output = new FileStream(@"$receiptPath", FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            Utf8JsonWriter writer = new Utf8JsonWriter(output);
            try
            {
                writer.WriteStartObject();
                writer.WriteNumber("SchemaVersion", 2);
                writer.WriteString("RunId", "$runId");
                writer.WriteString("DeclarationSha256", "$declarationHash");
                writer.WriteString("SourceCommit", "$commit");
                writer.WriteStartArray("Scenes");
                foreach (string scene in playerOptions.scenes ?? Array.Empty<string>())
                {
                    writer.WriteStringValue(scene.Replace('\\', '/'));
                }
                writer.WriteEndArray();
                writer.WriteStartArray("ProjectInputs");
                foreach (string path in entries)
                {
                    string relative = path.Substring(project.Length + 1).Replace('\\', '/');
                    writer.WriteStartObject();
                    writer.WriteString("Path", relative);
                    if (Directory.Exists(path))
                    {
                        writer.WriteString("Kind", "directory");
                        writer.WriteNull("Length");
                        writer.WriteNull("Sha256");
                    }
                    else
                    {
                        using (FileStream input = File.OpenRead(path))
                        using (SHA256 hash = SHA256.Create())
                        {
                            writer.WriteString("Kind", "file");
                            writer.WriteNumber("Length", input.Length);
                            writer.WriteString("Sha256", BitConverter.ToString(hash.ComputeHash(input)).Replace("-", string.Empty).ToLowerInvariant());
                        }
                    }
                    writer.WriteEndObject();
                }
                writer.WriteEndArray();
                writer.WriteEndObject();
            }
            finally
            {
                writer.Dispose();
            }
        }
    }
}
"@
}

function New-FrozenPlayerAnchor {
    param([Parameter(Mandatory = $true)]$Context, [Parameter(Mandatory = $true)][string]$ProjectPath)
    if ($null -eq $Context.Declaration.CanonicalCorpus) { return }
    $assets = Join-Path $ProjectPath 'Assets'
    Assert-FrozenPlayerRegularPath -Path $assets -Directory
    $anchorDirectory = Join-Path $assets 'FrozenPlayerAnchor'
    if (Test-Path -LiteralPath $anchorDirectory) { throw 'Frozen anchor directory already exists; use a fresh project scope.' }
    $assemblyMeta = Join-Path $Context.RepoRoot 'Tests/Runtime/Performance/WallstopStudios.UnityHelpers.Tests.Runtime.Performance.asmdef.meta'
    Assert-FrozenPlayerRegularPath -Path $assemblyMeta
    $guidMatch = [regex]::Matches((Get-Content -LiteralPath $assemblyMeta -Raw), '(?m)^guid: ([a-f0-9]{32})\r?$')
    if ($guidMatch.Count -ne 1) { throw 'Performance assembly GUID metadata is invalid.' }
    $assemblyGuid = $guidMatch[0].Groups[1].Value
    $runId = $Context.Declaration.Value.RunId
    $declarationHash = $Context.Declaration.Sha256
    $corpusHash = $Context.Declaration.CanonicalCorpus.Sha256
    $year = (Get-Date).Year
    $anchorSource = @"
// MIT License - Copyright (c) $year wallstop
// Full license text: https://github.com/wallstop/unity-helpers/blob/main/LICENSE

namespace WallstopStudios.UnityHelpers.Tests.Runtime.Performance
{
    public sealed partial class BorrowedBufferPreflightTests
    {
        static partial void ReadFrozenAnchor(
            ref string runId,
            ref string declarationSha256,
            ref string corpusSha256
        )
        {
            runId = "$runId";
            declarationSha256 = "$declarationHash";
            corpusSha256 = "$corpusHash";
        }
    }
}
"@
    $anchorName = 'BorrowedBufferPreflightTests.Anchor.cs'
    if ($Context.Declaration.CampaignKind -ceq 'wproto-seven-families-v1') {
        $anchorName = 'ProtoSerializationPerformanceTests.Anchor.cs'
        $anchorSource = $anchorSource.Replace('BorrowedBufferPreflightTests', 'ProtoSerializationPerformanceTests')
        $anchorSource = $anchorSource.Replace('ref string corpusSha256', "ref string corpusSha256,`n            ref string sourceCommit")
        $anchorSource = $anchorSource.Replace('corpusSha256 = "' + $corpusHash + '";',
            'corpusSha256 = "' + $corpusHash + '";' + "`n            sourceCommit = `"$($Context.Declaration.Value.SourceCommit)`";")
    }
    New-Item -ItemType Directory -Path $anchorDirectory -ErrorAction Stop | Out-Null
    $generated = [ordered]@{
        ("Assets/FrozenPlayerAnchor/$anchorName") = $anchorSource
        'Assets/FrozenPlayerAnchor/FrozenPlayerAnchor.asmref' = "{`"reference`":`"GUID:$assemblyGuid`"}"
        'Assets/FrozenPlayerAnchor.meta' = @'
fileFormatVersion: 2
guid: 47f97962fd75e896636f669ca65a248a
folderAsset: yes
DefaultImporter:
  externalObjects: {}
  userData:
  assetBundleName:
  assetBundleVariant:
'@
        ("Assets/FrozenPlayerAnchor/$anchorName.meta") = @'
fileFormatVersion: 2
guid: d60d7181d309022b7d213e8407fcccc6
MonoImporter:
  externalObjects: {}
  serializedVersion: 2
  defaultReferences: []
  executionOrder: 0
  icon: {instanceID: 0}
  userData:
  assetBundleName:
  assetBundleVariant:
'@
        'Assets/FrozenPlayerAnchor/FrozenPlayerAnchor.asmref.meta' = @'
fileFormatVersion: 2
guid: e32aa25f3b7b7cd8ab24fdabbfe7bc9a
AssemblyDefinitionReferenceImporter:
  externalObjects: {}
  userData:
  assetBundleName:
  assetBundleVariant:
'@
    }
    if ($Context.Declaration.CampaignKind -ceq 'wproto-seven-families-v1') {
        $generated['Assets/Editor/UhCiStandaloneBuildModifier.WProto.cs'] = New-WProtoBuildPreparationSource -Context $Context
        $generated['Assets/Editor/UhCiStandaloneBuildModifier.WProto.cs.meta'] = $generated["Assets/FrozenPlayerAnchor/$anchorName.meta"].Replace(
            'd60d7181d309022b7d213e8407fcccc6', '6d83710f21db498e9c7362a09eaaae01')
    }
    foreach ($relative in $generated.Keys) {
        $path = Join-Path $ProjectPath $relative
        if (Test-Path -LiteralPath $path) { throw "Frozen anchor output already exists: $relative" }
        $bytes = [Text.Encoding]::UTF8.GetBytes($generated[$relative].Replace("`r`n", "`n").Replace("`n", "`r`n") + "`r`n")
        $output = [IO.File]::Open($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $output.Write($bytes, 0, $bytes.Length) } finally { $output.Dispose() }
    }
    $Context.GeneratedRoot = $ProjectPath
    $Context.GeneratedFiles = @(
        foreach ($relative in $generated.Keys) {
            [pscustomobject]@{ Path = $relative; Sha256 = (Get-FileHash -LiteralPath (Join-Path $ProjectPath $relative) -Algorithm SHA256).Hash.ToLowerInvariant() }
        }
    )
}

function Get-FrozenPlayerRuntimeJoin {
    param(
        [Parameter(Mandatory = $true)]$Context,
        [string]$PlayerLogPath,
        [Parameter(Mandatory = $true)][bool]$PrerequisitesPassed
    )
    if ($Context.Declaration.CampaignKind -ceq 'wproto-seven-families-v1') {
        return Get-WProtoFrozenPlayerRuntimeJoin -Context $Context -PlayerLogPath $PlayerLogPath -PrerequisitesPassed $PrerequisitesPassed
    }
    $raw = New-Object 'System.Collections.Generic.List[object]'
    $errors = New-Object 'System.Collections.Generic.List[string]'
    $state = 'unverified'
    $corpusState = 'unverified'
    if ($null -ne $Context.Declaration.CanonicalCorpus) {
        $state = 'rejected'
        $corpusState = 'rejected'
        try {
            Assert-FrozenPlayerRegularPath -Path $PlayerLogPath
            $logFile = Get-Item -LiteralPath $PlayerLogPath -Force -ErrorAction Stop
            if ($logFile.Length -gt 67108864) { throw 'Frozen player stdout exceeds the 64 MiB parsing bound.' }
            $reader = New-Object IO.StreamReader($PlayerLogPath, (New-Object Text.UTF8Encoding($false, $true)))
            try {
                $lineNumber = 0
                while ($null -ne ($line = $reader.ReadLine())) {
                    $lineNumber++
                    $markers = [regex]::Matches($line, '^\s*(BORROWED_PREFLIGHT|BORROWED_BASE64_CORPUS)(?=\s|$)')
                    if ($markers.Count -eq 0) { continue }
                    $observation = [pscustomobject]@{ LineNumber = $lineNumber; Marker = $markers[0].Groups[1].Value; RawLine = $line; Record = $null; Error = $null }
                    $raw.Add($observation)
                    try {
                        if ($markers.Count -ne 1 -or $line.Length -gt 4194304) { throw 'Marker line is duplicated or exceeds the 4 MiB record bound.' }
                        $json = $line.Substring($markers[0].Index + $markers[0].Length).Trim()
                        $stringPattern = '"(?:[^"\\]|\\.)*"'
                        $depth = 0
                        foreach ($character in ([regex]::Replace($json, $stringPattern, '""')).ToCharArray()) {
                            if ($character -eq '{' -or $character -eq '[') {
                                $depth++
                                if ($depth -gt 64) { throw 'Marker JSON exceeds the 64-level nesting bound.' }
                            } elseif ($character -eq '}' -or $character -eq ']') { $depth-- }
                        }
                        foreach ($token in [regex]::Matches($json, $stringPattern)) {
                            $next = $token.Index + $token.Length
                            while ($next -lt $json.Length -and [char]::IsWhiteSpace($json[$next])) { $next++ }
                            if ($next -lt $json.Length -and $json[$next] -eq ':' -and $token.Value.Contains('\')) {
                                throw 'Marker property names must be literal; escaped names cannot establish an unambiguous schema.'
                            }
                        }
                        $record = ConvertFrom-Json -InputObject $json -ErrorAction Stop
                        if ($record -isnot [pscustomobject]) { throw 'Marker JSON must be an object.' }
                        $observation.Record = $record
                        $requiredKeys = if ($observation.Marker -ceq 'BORROWED_PREFLIGHT') {
                            @('SchemaVersion', 'FrozenRunId', 'FrozenDeclarationSha256', 'FrozenCorpusSha256', 'ActualCorpusSha256',
                                'RuntimeIdentity', 'UnityVersion', 'Backend', 'Platform', 'ProcessBits', 'IsEditor', 'DevelopmentBuild')
                        } else { @('SchemaVersion', 'CorpusSha256', 'VerifiedRows', 'DecoderAssertions', 'DeclaredCampaignRows') }
                        if ($observation.Marker -ceq 'BORROWED_PREFLIGHT' -and
                            $record.PSObject.Properties.Name -contains 'NativeAllocationCountState') {
                            $requiredKeys += @('NativeAllocationCountState', 'NativeAllocationBackend',
                                'NativeAllocationSourceSha256', 'NativeAllocationError', 'NativeAllocationObservations',
                                'TraversalTimingObservations', 'TraversalAllocationObservations')
                        }
                        foreach ($key in $requiredKeys) {
                            if ([regex]::Matches($json, '(?<!\\)"' + [regex]::Escape($key) + '"\s*:').Count -ne 1) {
                                throw "Marker must contain exactly one literal $key field."
                            }
                        }
                    } catch { $observation.Error = $_.ToString(); $errors.Add($observation.Error) }
                }
            } finally { $reader.Dispose() }
            $preflight = @($raw | Where-Object { $_.Marker -ceq 'BORROWED_PREFLIGHT' })
            $correctness = @($raw | Where-Object { $_.Marker -ceq 'BORROWED_BASE64_CORPUS' })
            if ($preflight.Count -ne 1 -or $correctness.Count -ne 1 -or $errors.Count -ne 0) {
                throw 'One complete unambiguous preflight marker and one correctness-corpus marker are required.'
            }
            if (-not $PrerequisitesPassed -or $Context.GeneratedFiles.Count -ne 5) {
                throw 'Frozen generated anchor, current invocation, exact correctness cases, and stable payload are required before joining runtime records.'
            }
            $runtime = $preflight[0].Record
            $corpus = $correctness[0].Record
            foreach ($name in @('FrozenRunId', 'FrozenDeclarationSha256', 'FrozenCorpusSha256', 'ActualCorpusSha256')) {
                if ($runtime.$name -isnot [string]) { throw "Runtime $name must be a scalar string." }
            }
            if ($corpus.CorpusSha256 -isnot [string]) { throw 'Correctness CorpusSha256 must be a scalar string.' }
            foreach ($record in @($runtime, $corpus)) {
                if (($record.SchemaVersion -isnot [int] -and $record.SchemaVersion -isnot [long]) -or $record.SchemaVersion -ne 1) {
                    throw 'Runtime and correctness schema versions must be JSON integers equal to one.'
                }
            }
            if ($runtime.RuntimeIdentity -isnot [pscustomobject] -or
                ($runtime.RuntimeIdentity.ProcessBits -isnot [int] -and $runtime.RuntimeIdentity.ProcessBits -isnot [long])) {
                throw 'Runtime identity must be an object with an integer ProcessBits value.'
            }
            foreach ($name in @('UnityVersion', 'Backend', 'Platform')) {
                if ($runtime.RuntimeIdentity.$name -isnot [string]) { throw "Runtime identity $name must be a scalar string." }
            }
            foreach ($name in @('VerifiedRows', 'DecoderAssertions', 'DeclaredCampaignRows')) {
                if ($corpus.$name -isnot [int] -and $corpus.$name -isnot [long]) {
                    throw "Correctness $name must be a JSON integer."
                }
            }
            $expectedCorpus = $Context.Declaration.CanonicalCorpus.Sha256
            $expectedBackend = if ($Context.Declaration.Value.Backend -ceq 'Mono2x') { 'Mono' } else { 'IL2CPP' }
            if ($runtime.SchemaVersion -ne 1 -or $runtime.FrozenRunId -cne $Context.Declaration.Value.RunId -or
                $runtime.FrozenDeclarationSha256 -cne $Context.Declaration.Sha256 -or
                $runtime.FrozenCorpusSha256 -cne $expectedCorpus -or $runtime.ActualCorpusSha256 -cne $expectedCorpus -or
                $runtime.RuntimeIdentity.UnityVersion -cne $Context.Declaration.Value.UnityVersion -or
                $runtime.RuntimeIdentity.Backend -cne $expectedBackend -or $runtime.RuntimeIdentity.Platform -cne 'WindowsPlayer' -or
                $runtime.RuntimeIdentity.ProcessBits -ne 64 -or $runtime.RuntimeIdentity.IsEditor -isnot [bool] -or
                $runtime.RuntimeIdentity.IsEditor -or $runtime.RuntimeIdentity.DevelopmentBuild -isnot [bool] -or
                $runtime.RuntimeIdentity.DevelopmentBuild) {
                throw 'Runtime compiled anchor, actual corpus, or Release Windows x64 identity does not match the frozen declaration.'
            }
            if ($corpus.SchemaVersion -ne 1 -or $corpus.CorpusSha256 -cne $expectedCorpus -or
                $corpus.VerifiedRows -ne 35 -or $corpus.DecoderAssertions -ne 105 -or $corpus.DeclaredCampaignRows -ne 12) {
                throw 'Correctness-corpus record must consume exactly 35 rows with 105 assertions and declare 12 campaign rows under the frozen digest.'
            }
            $state = 'passed'
            $corpusState = 'passed'
        } catch { $errors.Add($_.ToString()) }
    }
    return [pscustomobject]@{
        State = $state; CorrectnessCorpusConsumptionState = $corpusState; CampaignCorpusConsumptionState = 'unverified'
        VerifiedCorrectnessRows = $(if ($corpusState -eq 'passed') { 35 } else { 0 })
        DeclaredCampaignRows = $(if ($corpusState -eq 'passed') { 12 } else { 0 })
        RawRecords = $raw.ToArray(); Errors = $errors.ToArray()
    }
}

function Add-FrozenPlayerProvenanceSnapshot {
    param(
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$Stage,
        [switch]$IncludePayload,
        [switch]$AllowRejected
    )
    $snapshot = [ordered]@{ Stage = $Stage; DeclarationSha256 = $null; SourceFiles = @(); CorpusFiles = @(); GeneratedAnchorFiles = @(); PayloadFiles = @(); ProjectInputs = @(); State = 'passed'; Errors = @() }
    try {
        Assert-FrozenPlayerRegularPath -Path $Context.Declaration.Path
        $snapshot.DeclarationSha256 = (Get-FileHash -LiteralPath $Context.Declaration.Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
        if ($snapshot.DeclarationSha256 -cne $Context.Declaration.Sha256) { throw 'Frozen declaration bytes changed.' }
    } catch { $snapshot.Errors += $_.ToString() }
    foreach ($name in @('SourceFiles', 'CorpusFiles')) {
        $observed = New-Object 'System.Collections.Generic.List[object]'
        try {
            Get-FrozenPlayerFileInventory -Root $Context.RepoRoot -DeclaredFiles @($Context.Declaration.Value.$name) -MaximumFiles $Context.Declaration.MaximumFiles |
                ForEach-Object { $observed.Add($_) }
        } catch { $snapshot.Errors += $_.ToString() }
        $snapshot[$name] = $observed.ToArray()
    }
    if ($null -ne $Context.Declaration.CanonicalCorpus) {
        $observed = New-Object 'System.Collections.Generic.List[object]'
        try {
            $expectedAnchors = if ($Context.Declaration.CampaignKind -ceq 'wproto-seven-families-v1') { 7 } else { 5 }
            if ($Context.GeneratedFiles.Count -ne $expectedAnchors) { throw 'Frozen compiled anchor files are missing.' }
            Get-FrozenPlayerFileInventory -Root $Context.GeneratedRoot -DeclaredFiles $Context.GeneratedFiles |
                ForEach-Object { $observed.Add($_) }
        } catch { $snapshot.Errors += $_.ToString() }
        $snapshot.GeneratedAnchorFiles = $observed.ToArray()
    }
    if ($Context.Declaration.CampaignKind -ceq 'wproto-seven-families-v1') {
        try {
            Assert-WProtoSourceCensus -Repository $Context.RepoRoot -DeclaredFiles $Context.Declaration.Value.SourceFiles
            $projectInputs = @(Get-WProtoProjectInputs -ProjectPath $Context.GeneratedRoot)
            $snapshot.ProjectInputs = $projectInputs
            $projectIdentity = ConvertTo-Json -InputObject $projectInputs -Depth 4 -Compress
            if ($Stage -ceq 'after-configure') { $Context.ProjectSettingsBaseline = $projectIdentity }
            elseif ($Stage -ceq 'after-build') {
                $preparationPath = Join-Path $Context.Declaration.ReportDirectory 'build-preparation.json'
                Assert-FrozenPlayerRegularPath -Path $preparationPath
                if ((Get-Item -LiteralPath $preparationPath).Length -gt 4194304) { throw 'WProto build preparation receipt exceeds 4 MiB.' }
                $Context.BuildPreparationSha256 = (Get-FileHash -LiteralPath $preparationPath -Algorithm SHA256).Hash.ToLowerInvariant()
                $Context.BuildPreparation = Get-Content -LiteralPath $preparationPath -Raw | ConvertFrom-Json -ErrorAction Stop
                $configured = @($Context.Snapshots | Where-Object { $_.Stage -ceq 'after-configure' })
                if ($configured.Count -ne 1) { throw 'WProto build preparation requires exactly one configured snapshot.' }
                Assert-WProtoBuildPreparation -Preparation $Context.BuildPreparation -ConfiguredInputs $configured[0].ProjectInputs `
                    -BuiltInputs $projectInputs -Declaration $Context.Declaration.Value -DeclarationSha256 $Context.Declaration.Sha256 `
                    -RestoredPlayerSettingsPath (Join-Path $Context.GeneratedRoot 'ProjectSettings/ProjectSettings.asset') `
                    -PreparedPlayerSettingsPath (Join-Path $Context.Declaration.ReportDirectory 'build-player-settings.asset')
                $Context.ProjectSettingsBaseline = $projectIdentity
            }
            elseif ($Stage -cne 'before-configure' -and ($null -eq $Context.ProjectSettingsBaseline -or $Context.ProjectSettingsBaseline -cne $projectIdentity)) {
                throw 'WProto generated project settings or compilation inputs changed after configuration.'
            }
        } catch { $snapshot.Errors += $_.ToString() }
    }
    if ($IncludePayload) {
        $observed = New-Object 'System.Collections.Generic.List[object]'
        try {
            Get-FrozenPlayerFileInventory -Root $Context.PayloadRoot | ForEach-Object { $observed.Add($_) }
            $snapshot.PayloadFiles = $observed.ToArray()
            $inventory = ConvertTo-Json -InputObject @($snapshot.PayloadFiles) -Depth 4 -Compress
            if ($Stage -eq 'after-build') { $Context.PayloadBaseline = $inventory }
            elseif ($null -eq $Context.PayloadBaseline) { throw 'No validated after-build payload baseline exists.' }
            elseif ($Context.PayloadBaseline -cne $inventory) { throw 'Frozen player payload changed.' }
        } catch { $snapshot.Errors += $_.ToString(); $snapshot.PayloadFiles = $observed.ToArray() }
    }
    if ($snapshot.Errors.Count -ne 0) { $snapshot.State = 'rejected' }
    $Context.Snapshots.Add([pscustomobject]$snapshot)
    if ($snapshot.State -eq 'rejected' -and -not $AllowRejected) {
        throw "Frozen provenance rejected at ${Stage}: $($snapshot.Errors -join '; ')"
    }
}

function Get-FrozenPlayerJointCorrectness {
    param([Parameter(Mandatory = $true)][string]$ResultsPath, [string]$CampaignKind = 'borrowed-diagnostic')
    $expected = @(
        'WallstopStudios.UnityHelpers.Tests.Runtime.Performance.BorrowedBufferPreflightTests.ReleasePlayerChannelsAreReported',
        'WallstopStudios.UnityHelpers.Tests.Extensions.BorrowedBase64Tests.BorrowedDecoderMatchesShippedDecoderAcrossPoolBoundariesAndUtf8Failures',
        'WallstopStudios.UnityHelpers.Tests.Extensions.BorrowedBase64Tests.ProductionAndBorrowedWholeCallsAvoidLeaseWorkWithShippedPositiveControl'
    )
    if ($CampaignKind -ceq 'wproto-seven-families-v1') {
        $expected = @(Get-WProtoFrozenOperationNames | ForEach-Object {
                'WallstopStudios.UnityHelpers.Tests.Runtime.Performance.ProtoSerializationPerformanceTests.CompareFrozenSevenFamilyCorpus("' + $_ + '")'
            })
    }
    $leaves = @()
    $reason = $null
    try {
        $evidence = Read-TestResultEvidence -Path $ResultsPath -Format NUnit
        $leaves = @($evidence.Cases | ForEach-Object {
                [pscustomobject]@{ FullName = $_.FullName; Result = $_.Result }
            })
        if ($leaves.Count -ne $expected.Count) { throw "Joint correctness requires exactly $($expected.Count) declared native cases." }
        foreach ($name in $expected) {
            $matching = @($leaves | Where-Object { $_.FullName -ceq $name })
            if ($matching.Count -ne 1 -or $matching[0].Result -cne 'Passed') {
                throw "Joint correctness case missing, duplicated, or not passed: $name"
            }
        }
    } catch { $reason = $_.ToString() }
    return [pscustomobject]@{ State = $(if ($null -eq $reason) { 'passed' } else { 'rejected' }); Reason = $reason; ExpectedFullNames = $expected; ObservedLeaves = $leaves }
}

function Complete-FrozenPlayerProvenance {
    param(
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$ResultsPath,
        [Parameter(Mandatory = $true)][string[]]$EvidencePaths,
        [string]$PlayerLogPath
    )
    Add-FrozenPlayerProvenanceSnapshot -Context $Context -Stage 'final' -IncludePayload:($Context.LaunchAttempted -or $null -ne $Context.PayloadBaseline) -AllowRejected
    $correctness = Get-FrozenPlayerJointCorrectness -ResultsPath $ResultsPath -CampaignKind $Context.Declaration.CampaignKind
    if (-not $Context.InvocationObserved -or -not $Context.ResultsValidated) {
        $correctness.State = 'rejected'
        $correctness.Reason = 'No observed invocation with validated results exists for this run; existing XML cannot prove current correctness.'
    }
    $evidence = @(
        foreach ($path in $EvidencePaths) {
            try {
                $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
                [pscustomobject]@{ Path = $path; Length = $item.Length; Sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant(); Error = $null }
            } catch { [pscustomobject]@{ Path = $path; Length = $null; Sha256 = $null; Error = $_.ToString() } }
        }
    )
    $stable = $null -ne $Context.PayloadBaseline -and @($Context.Snapshots | Where-Object { $_.State -ne 'passed' }).Count -eq 0
    $wproto = $Context.Declaration.CampaignKind -ceq 'wproto-seven-families-v1'
    $healthy = $false
    if ($wproto) {
        $expectedStages = @('before-configure', 'after-configure', 'after-build', 'before-launch', 'final')
        $stages = @($Context.Snapshots | ForEach-Object { $_.Stage })
        $stable = $stable -and ($stages.Count -eq $expectedStages.Count) -and (($stages -join '|') -ceq ($expectedStages -join '|'))
        $Context.KnownFaultScan = Get-WProtoKnownFaultScan -Paths @($EvidencePaths | Where-Object { $_ -cne $ResultsPath })
        $Context.NativeSupportScans = @(Get-WProtoNativeSupportScans -Context $Context)
        $healthy = Test-WProtoFrozenProcessHealth -Context $Context
    }
    $prerequisites = $stable -and $Context.InvocationObserved -and $Context.ResultsValidated -and $correctness.State -eq 'passed'
    if ($wproto) { $prerequisites = $prerequisites -and $healthy }
    $runtimeJoin = Get-FrozenPlayerRuntimeJoin -Context $Context -PlayerLogPath $PlayerLogPath -PrerequisitesPassed $prerequisites
    $report = [ordered]@{
        SchemaVersion = 1; RunId = $Context.Declaration.Value.RunId; IsDiagnosticOnly = $true
        CampaignEligible = $false; AdoptionEligible = $false
        CorpusConsumptionState = 'unverified'; RuntimeRecordJoinState = $runtimeJoin.State; SourceCoverageState = 'unverified'
        CorrectnessCorpusConsumptionState = $runtimeJoin.CorrectnessCorpusConsumptionState; CampaignCorpusConsumptionState = 'unverified'
        RetainedMemoryState = 'unverified'; EffectiveBuildSettingsState = 'unverified'; CodeSizeState = 'unverified'
        ProvenanceStableState = $(if ($stable) { 'passed' } else { 'rejected' })
        DeclarationSha256 = $Context.Declaration.Sha256; DeclarationPath = $Context.Declaration.Path
        RequestedUnityVersion = $Context.Declaration.Value.UnityVersion; RequestedBackend = $Context.Declaration.Value.Backend
        LaunchAttempted = $Context.LaunchAttempted; InvocationObserved = $Context.InvocationObserved; ResultsValidated = $Context.ResultsValidated
        PlayerOutcome = $Context.PlayerOutcome; ExecutionError = $Context.ExecutionError
        Snapshots = $Context.Snapshots.ToArray(); JointCorrectness = $correctness; EvidenceFiles = $evidence; RuntimeJoin = $runtimeJoin
    }
    if ($wproto) {
        $validCapture = $prerequisites -and $runtimeJoin.State -ceq 'passed'
        $report.CampaignKind = $Context.Declaration.CampaignKind
        $report.SourceCommit = $Context.Declaration.Value.SourceCommit
        $report.SourceFilesCount = @($Context.Declaration.Value.SourceFiles).Count
        $report.CapturedEvidenceValid = $validCapture
        $report.FullQualification = $false
        $report.ProcessHealthState = if ($healthy) { 'passed' } else { 'rejected' }
        $report.SourceCoverageState = if ($stable) { 'passed' } else { 'rejected' }
        $report.CorpusConsumptionState = $runtimeJoin.State
        $report.CampaignCorpusConsumptionState = $runtimeJoin.State
        $report.SyntheticTimingQualified = $validCapture -and $runtimeJoin.Summary.timingQualified -eq $true
        $report.TimingTwofoldTarget = $validCapture -and $runtimeJoin.Summary.timingTwofoldTarget -eq $true
        $report.ConfigureOutcomes = $Context.ConfigureOutcomes.ToArray()
        $report.BuildOutcome = $Context.BuildOutcome
        $report.BuildObservation = $Context.BuildObservation
        $report.BuildPreparation = $Context.BuildPreparation
        $report.BuildPreparationSha256 = $Context.BuildPreparationSha256
        $report.KnownFaultScan = $Context.KnownFaultScan
        $report.NativeSupportScans = $Context.NativeSupportScans
        $report.OriginalGeneratedRoot = $Context.GeneratedRoot
        $report.OriginalPayloadRoot = $Context.PayloadRoot
        $retained = Join-Path $Context.Declaration.ReportDirectory 'retained'
        $report.GeneratedRoot = 'retained/project-inputs'
        $report.PayloadRoot = 'retained/player'
        $report.PlayerLogPath = 'retained/corpus-records.txt'
        $report.ResultsPath = 'retained/results.xml'
        $report.BuildPreparationPath = 'retained/build-preparation.json'
        $report.EvidenceFilesScope = 'Historical pre-redaction support-log observations; replay uses RetainedFiles only.'
        $generatedRoot = Join-Path $Context.Declaration.ReportDirectory $report.GeneratedRoot
        $payloadRoot = Join-Path $Context.Declaration.ReportDirectory $report.PayloadRoot
        try {
            if (Test-Path -LiteralPath $retained) { throw 'WProto retained evidence directory already exists.' }
            $null = New-Item -ItemType Directory -Path $generatedRoot -Force -ErrorAction Stop
            foreach ($directoryName in @('Assets', 'Packages', 'ProjectSettings')) {
                Copy-Item -LiteralPath (Join-Path $Context.GeneratedRoot $directoryName) -Destination $generatedRoot -Recurse -ErrorAction Stop
            }
            Copy-Item -LiteralPath $Context.PayloadRoot -Destination $payloadRoot -Recurse -ErrorAction Stop
            $built = @($Context.Snapshots | Where-Object { $_.Stage -ceq 'after-build' })
            if ($built.Count -ne 1) { throw 'WProto retained evidence requires exactly one build snapshot.' }
            Assert-WProtoRecordedInventory -Root $payloadRoot -Entries $built[0].PayloadFiles -Complete
            Assert-WProtoRecordedInventory -Root $generatedRoot -Entries $built[0].ProjectInputs
            Assert-WProtoRecordedInventory -Root $generatedRoot -Entries $built[0].GeneratedAnchorFiles
            Copy-Item -LiteralPath (Join-Path $Context.Declaration.ReportDirectory 'build-preparation.json') `
                -Destination (Join-Path $Context.Declaration.ReportDirectory $report.BuildPreparationPath) -ErrorAction Stop
            if ((Get-FileHash -LiteralPath (Join-Path $retained 'build-preparation.json') -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Context.BuildPreparationSha256) {
                throw 'WProto build preparation changed before retention.'
            }
            if ($Context.BuildPreparation.SchemaVersion -eq 2) {
                Copy-Item -LiteralPath (Join-Path $Context.Declaration.ReportDirectory 'build-player-settings.asset') `
                    -Destination (Join-Path $retained 'build-player-settings.asset') -ErrorAction Stop
                $preparedSettings = @($Context.BuildPreparation.ProjectInputs | Where-Object { $_.Path -ceq 'ProjectSettings/ProjectSettings.asset' })
                if ($preparedSettings.Count -ne 1) { throw 'WProto prepared player settings identity is missing.' }
                Assert-WProtoRecordedInventory -Root $retained -Entries @([pscustomobject]@{
                        Path = 'build-player-settings.asset'; Kind = 'file'; Length = $preparedSettings[0].Length; Sha256 = $preparedSettings[0].Sha256
                    })
            }
            Copy-Item -LiteralPath $ResultsPath -Destination (Join-Path $retained 'results.xml') -ErrorAction Stop
            Copy-WProtoCorpusRecords -Source $PlayerLogPath -Destination (Join-Path $retained 'corpus-records.txt')
            $retainedPaths = @($report.PlayerLogPath, $report.ResultsPath, $report.BuildPreparationPath)
            if ($Context.BuildPreparation.SchemaVersion -eq 2) { $retainedPaths += 'retained/build-player-settings.asset' }
            $report.RetainedFiles = @(foreach ($relative in $retainedPaths) {
                    $path = Join-Path $Context.Declaration.ReportDirectory $relative
                    $item = Get-Item -LiteralPath $path -ErrorAction Stop
                    [pscustomobject]@{ Path = $relative; Kind = 'file'; Length = $item.Length; Sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
                })
            $report.RetainedEvidenceState = 'passed'
        } catch {
            $report.RetainedEvidenceState = 'rejected'
            $report.RetainedEvidenceError = $_.ToString()
            $report.CapturedEvidenceValid = $false
            $report.SyntheticTimingQualified = $false
            $report.TimingTwofoldTarget = $false
        }
        $report.Scope = 'Synthetic corpus capture only; adoption, representative target, and whole-capability qualification remain open.'
    }
    Assert-FrozenPlayerRegularPath -Path $Context.ReportPath
    $output = [IO.File]::Open($Context.ReportPath, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        if ($output.Length -ne 0) { throw 'Frozen provenance reservation changed; refusing to overwrite existing report contents.' }
        $bytes = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $report -Depth 12))
        $output.Write($bytes, 0, $bytes.Length)
        $output.Flush()
    } finally { $output.Dispose() }
    if ($wproto -and -not $report.CapturedEvidenceValid) { throw "WProto frozen capture rejected; retained report: $($Context.ReportPath)" }
    if ($null -eq $Context.ExecutionError -and (-not $stable -or $correctness.State -ne 'passed' -or
        ($null -ne $Context.Declaration.CanonicalCorpus -and $runtimeJoin.State -ne 'passed'))) {
        throw "Frozen player provenance or joint correctness rejected; retained report: $($Context.ReportPath)"
    }
}

function Invoke-StandaloneTestPlayer {
    # RUN the editor-built standalone IL2CPP test player DIRECTLY (no
    # PlayerConnection): the player-side TestRunCallback writes NUnit XML to the
    # -uhTestResults path and quits 0/1/2/3. The exe is launched under the hard
    # tree-kill watchdog so a hung player is killed long before the GitHub step is
    # cancelled. Returns @{ ExitCode; TimedOut }. The FILE is the source of truth: the
    # caller validates results.xml and treats a watchdog timeout as fatal ONLY when no
    # usable results file was written (a player can finish writing results in
    # RunFinished and then have Application.Quit deferred in -batchmode IL2CPP, which
    # the watchdog would otherwise turn into a spurious failure). Exit 2 (the player got
    # no -uhTestResults arg -- a harness-contract violation) is still thrown here.
    #
    # ONE results channel: -uhTestResults. There is NO environment-variable handoff
    # and NO per-user-data-folder fallback.
    param(
        [Parameter(Mandatory = $true)][string]$EditorBuiltExePath,
        [Parameter(Mandatory = $true)][string]$ResultsPath,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [int]$TimeoutSeconds = 1800
    )

    $playerArgs = @(
        '-batchmode',
        '-nographics',
        '-logFile', '-',
        '-uhTestResults', $ResultsPath
    )
    if ($env:UH_NATIVE_ALLOCATOR_DIAGNOSTICS -eq '1') {
        $playerArgs += '-diag-job-temp-memory-leak-validation'
    }

    # No -StallSeconds here (only the wall-clock backstop): the no-output stall guard is
    # deliberately scoped to the in-editor -runTests pass, whose silent-hang class -- a
    # wedged PlayMode-test coroutine -- it exists to catch. A standalone player can
    # legitimately run a batch of IL2CPP tests with little interleaved stdout.
    $result = Invoke-ProcessWithTreeKillTimeout `
        -FilePath $EditorBuiltExePath `
        -Arguments $playerArgs `
        -TimeoutSeconds $TimeoutSeconds `
        -LogPath $LogPath `
        -Label 'Run standalone test player'

    # Exit 2 means the player received no -uhTestResults arg (a harness-contract
    # violation -- the harness always passes it), so no file can exist: fail fast.
    if ($result.ExitCode -eq 2) {
        throw "Standalone test player reported no -uhTestResults path (exit 2); no results were written. See the player log at $LogPath."
    }

    # Do NOT throw on a watchdog timeout here. A player can write a complete results
    # file in its RunFinished callback and then have Application.Quit deferred/ignored
    # in -batchmode -nographics IL2CPP; the watchdog then tree-kills it (TimedOut) even
    # though the results are valid. The caller validates the FILE (the source of truth)
    # and decides, so a deferred-quit run is not turned into a spurious failure.
    return @{ ExitCode = $result.ExitCode; TimedOut = $result.TimedOut }
}

function New-UnityNativeEvidenceCapture {
    param([string]$LogPath, [string]$PrivateRoot = (Join-Path ([IO.Path]::GetTempPath()) 'unity-helpers-native'))

    $capture = @{ State = 'capture-setup-failed' }
    try {
        $identity = [Guid]::NewGuid().ToString('N')
        $artifactRoot = Split-Path -Parent ([IO.Path]::GetFullPath($LogPath))
        $directory = [IO.Path]::GetFullPath((Join-Path $PrivateRoot $identity))
        $artifactPrefix = $artifactRoot.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if ($directory.StartsWith($artifactPrefix, [StringComparison]::OrdinalIgnoreCase)) { return $capture }
        $null = [IO.Directory]::CreateDirectory($PrivateRoot)
        if ((Get-Item -LiteralPath $PrivateRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { return $capture }
        $null = [IO.Directory]::CreateDirectory($directory)
        $upmLog = Join-Path $directory 'upm.log'
        return @{ State = 'configured'; CaptureId = $identity; CrashDirectory = $directory; UpmLogPath = $upmLog }
    } catch { return $capture }
}


function Invoke-UnityStandaloneBuildDiagnostic {
    param(
        [ValidateSet('Direct', 'Debugger')][string]$Mode,
        [string]$EditorPath, [string]$ProjectPath, [string[]]$Arguments,
        [string]$ArtifactsPath, [string]$LogPath, [int]$TimeoutSeconds,
        [switch]$UseStandardHeap,
        [switch]$AttachToDirect,
        [switch]$AttachAfterStartup,
        [switch]$AttachAfterShutdown
    )

    if ($TimeoutSeconds -lt 1 -or $TimeoutSeconds -gt 1800) { throw 'Build diagnostics require a bounded timeout.' }
    if ($UseStandardHeap -and $Mode -ne 'Debugger') { throw 'Standard heap selection requires a debugger build.' }
    if ($AttachToDirect -and ($Mode -ne 'Debugger' -or $UseStandardHeap)) { throw 'Direct attachment requires a debugger build without a launch heap request.' }
    if ($AttachAfterStartup -and -not $AttachToDirect) { throw 'Startup-delayed attachment requires Direct attachment.' }
    if ($AttachAfterShutdown -and (-not $AttachToDirect -or $AttachAfterStartup)) { throw 'Shutdown-delayed attachment requires Direct attachment without startup selection.' }
    if ($Mode -eq 'Debugger') {
        & (Join-Path $PSScriptRoot 'capture-native-fault.ps1') -EditorPath $EditorPath -ProjectPath $ProjectPath `
            -BuildArguments $Arguments -BuildLogPath $LogPath -ArtifactsPath (Join-Path $ArtifactsPath 'native-build-diagnostics') `
            -TimeoutSeconds $TimeoutSeconds -UseStandardHeap:$UseStandardHeap -AttachToDirect:$AttachToDirect -AttachAfterStartup:$AttachAfterStartup -AttachAfterShutdown:$AttachAfterShutdown
    } else {
        $observation = @{}
        $null = Invoke-UnityObservedEditor -EditorPath $EditorPath -Arguments $Arguments `
            -TimeoutSeconds $TimeoutSeconds -LogPath $LogPath -Label 'Evidence-only Standalone build' -ProcessObservation $observation
    }
}

function Invoke-UnityObservedEditor {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [string]$CompletionPattern = '',
        [int]$CompletionGraceSeconds = 120,
        [int]$TimeoutSeconds = 0,
        [int]$StallSeconds = 0,
        [hashtable]$ProcessObservation
    )

    if ($null -eq $ProcessObservation) { $ProcessObservation = @{} }
    $frameworkEvidence = $null
    $projectArgument = [Array]::IndexOf($Arguments, '-projectPath')
    if ($projectArgument -ge 0 -and $projectArgument + 1 -lt $Arguments.Count) {
        $frameworkProject = $Arguments[$projectArgument + 1]
        if (Test-Path -LiteralPath (Join-Path $frameworkProject 'Assets/UhCiTestFrameworkEvidence/Editor/UhCiTestFrameworkEvidence.cs')) {
            $frameworkEvidence = Join-Path $script:ArtifactsPath ('framework/' + [Guid]::NewGuid().ToString('N'))
            $null = New-Item -ItemType Directory -Path $frameworkEvidence -ErrorAction Stop
            Copy-Item -LiteralPath (Join-Path $frameworkProject 'Packages/manifest.json') -Destination (Join-Path $frameworkEvidence 'requested-manifest.json')
            $frameworkInvocation = @{ SchemaVersion = 1; ProjectPath = $frameworkProject; OriginalLogRelativePath = [IO.Path]::GetRelativePath($script:ArtifactsPath, $LogPath).Replace('\', '/') }
            $frameworkInvocation | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $frameworkEvidence 'invocation.json') -Encoding UTF8
            $Arguments = @($Arguments) + @('-uhFrameworkEvidenceDirectory', $frameworkEvidence)
        }
    }

    $nativeCapture = $null
    if ($IsWindows) {
        $nativeCapture = New-UnityNativeEvidenceCapture -LogPath $LogPath
        if ($nativeCapture.State -eq 'configured') {
            $Arguments = @($Arguments) + @('-crash-report-folder', $nativeCapture.CrashDirectory, '-upmLogFile', $nativeCapture.UpmLogPath)
        }
    }
    $watch = Invoke-ProcessWithTreeKillTimeout `
        -FilePath $EditorPath `
        -Arguments $Arguments `
        -TimeoutSeconds $TimeoutSeconds `
        -LogPath $LogPath `
        -Label $Label `
        -CompletionPattern $CompletionPattern `
        -CompletionGraceSeconds $CompletionGraceSeconds `
        -StallSeconds $StallSeconds `
        -ProcessObservation $ProcessObservation
    try { $ProcessObservation['NativeEvidence'] = Get-UnityNativeEvidence -Capture $nativeCapture -LogPath $LogPath }
    catch { $ProcessObservation['NativeEvidence'] = @{ State = 'capture-unavailable'; Files = @() } }
    Write-UnityExecutionObservation -LogPath $LogPath -ProcessObservation $ProcessObservation -Label $Label
    if ($null -ne $frameworkEvidence) {
        if (-not $ProcessObservation.ContainsKey('LogPersistence') -or $ProcessObservation.LogPersistence -cne 'written') { throw 'Current invocation log was not persisted; refusing to bind stale framework evidence.' }
        $frameworkDiagnosticsPath = [IO.Path]::ChangeExtension($LogPath, 'execution-diagnostics.json')
        $frameworkDiagnostics = Get-Content -LiteralPath $frameworkDiagnosticsPath -Raw -ErrorAction Stop | ConvertFrom-Json -AsHashtable
        $recordedFrameworkLaunch = [DateTimeOffset]$frameworkDiagnostics.Process.LaunchUtc
        $expectedFrameworkLaunch = [DateTimeOffset]$ProcessObservation.LaunchUtc
        if ($frameworkDiagnostics.Process.ProcessId -ne $ProcessObservation.ProcessId -or
            $recordedFrameworkLaunch.UtcDateTime.Ticks -ne $expectedFrameworkLaunch.UtcDateTime.Ticks) { throw 'Current invocation diagnostics were not persisted; refusing to bind stale framework evidence.' }
        $capturedFrameworkLog = Join-Path $frameworkEvidence 'unity.log'
        Copy-Item -LiteralPath $LogPath -Destination $capturedFrameworkLog -ErrorAction Stop
        Copy-Item -LiteralPath ([IO.Path]::ChangeExtension($LogPath, 'execution-diagnostics.json')) -Destination (Join-Path $frameworkEvidence 'unity.execution-diagnostics.json') -ErrorAction Stop
        $frameworkInvocation.LogRelativePath = [IO.Path]::GetRelativePath($script:ArtifactsPath, $capturedFrameworkLog).Replace('\', '/')
        $frameworkInvocation.ProcessId = $ProcessObservation.ProcessId
        $frameworkInvocation | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $frameworkEvidence 'invocation.json') -Encoding UTF8
        Assert-UnityTestFrameworkEvidence -Directory $frameworkEvidence -ProcessId $ProcessObservation.ProcessId -Project $frameworkProject
    }
    return $watch
}

function Invoke-UnityEditor {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$LogPath,
        # When ANY of these is set, the editor is launched under the tree-kill watchdog
        # (completion-sentinel + wall-clock + no-output stall detection) instead of the
        # bare `&` pipeline. The -runTests passes use this because Unity -batchmode can
        # (a) deadlock on shutdown AFTER results.xml is written and (b) hang MID-RUN with
        # zero further output (a PlayMode test whose background coroutine throws), either
        # of which would otherwise block the `&` pipeline until the GitHub step's
        # wall-clock timeout. Configure/license callers may omit these and keep
        # the proven `&` idiom unchanged.
        [string]$CompletionPattern = '',
        [int]$CompletionGraceSeconds = 120,
        [int]$TimeoutSeconds = 0,
        [int]$StallSeconds = 0,
        [hashtable]$ProcessObservation
    )

    # Unity.exe is a Windows GUI-subsystem binary. PowerShell's `&` launches such
    # executables ASYNCHRONOUSLY: it does NOT wait for them and does NOT set
    # $LASTEXITCODE. Callers therefore pass `-logFile -` (Unity logs to stdout) so
    # that consuming the process's stdout via the pipeline forces PowerShell to
    # BLOCK until the process exits AND reliably sets $LASTEXITCODE. Tee-Object both
    # streams the log live to the CI console and persists it to $LogPath. This is
    # the proven idiom from scripts/unity/run-tests.ps1.
    $logDir = Split-Path -Parent $LogPath
    if ($logDir -and -not (Test-Path -LiteralPath $logDir -PathType Container)) {
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    }

    if ($CompletionPattern -or ($TimeoutSeconds -gt 0) -or ($StallSeconds -gt 0)) {
        # Hung-shutdown-resilient path: the watchdog drains both pipes on a main-thread
        # poll loop (live echo + tee to $LogPath), enforces the wall-clock deadline,
        # grace-kills the editor once the completion sentinel is seen, and tree-kills it
        # if it goes silent mid-run for $StallSeconds. It returns @{ ExitCode; TimedOut;
        # Stalled }; the durable results.xml remains the source of truth.
        $watch = Invoke-UnityObservedEditor `
            -EditorPath $EditorPath `
            -Arguments $Arguments `
            -TimeoutSeconds $TimeoutSeconds `
            -LogPath $LogPath `
            -Label $Label `
            -CompletionPattern $CompletionPattern `
            -CompletionGraceSeconds $CompletionGraceSeconds `
            -StallSeconds $StallSeconds `
            -ProcessObservation $ProcessObservation
        $exitCode = $watch.ExitCode
    } else {
        Write-Host "::group::$Label"
        Write-Host "`"$EditorPath`" $($Arguments -join ' ')"
        # Stream Unity's output LIVE to the console AND persist it to $LogPath, but route
        # it to the HOST (Out-Host) so it never enters this function's success stream:
        # the function RETURNS the exit code, and a bare `| Tee-Object` would otherwise
        # collect every streamed log line into the caller's `$x = Invoke-UnityEditor`
        # capture (turning the return value into an Object[] of log lines + the code).
        # Consuming the process's stdout via the pipeline still forces PowerShell to
        # BLOCK until the GUI-subsystem Unity.exe exits and to set $LASTEXITCODE.
        & $EditorPath @Arguments 2>&1 | Tee-Object -FilePath $LogPath | ForEach-Object { Write-Host (ConvertTo-UnitySafeLogText -Text ([string]$_)) }
        $exitCode = $LASTEXITCODE
        Write-Host "::endgroup::"
    }
    # Runs on EVERY invocation, not only a failing one: the legs that exposed this
    # exited zero here and failed at license return long afterwards (issue #657).
    Write-UnityEnvironmentWarningAnnotations -LogPath $LogPath
    if ($exitCode -ne 0) {
        # Proactively surface catastrophic compile-time failure patterns
        # (PrecompiledAssemblyException, CompilationFailedException, CS####,
        # CS8032) as ::error:: annotations so the operator sees the root cause
        # in BOTH the runner log AND GitHub's error summary, independent of
        # whether the workflow-level verify step also fires. On a benign
        # shutdown-race crash the log matches no catastrophic pattern, so this
        # is a no-op; on a real compile failure it names the root cause.
        Write-UnityCatastrophicErrorAnnotations -LogPath $LogPath
        # If that compile failure was a missing UnityEngine module (CS1069 forward
        # / CS0234 'UI'), name the exact package id to add to the shared manifest
        # source so the fix is one obvious edit, not a CS-error guessing game.
        Write-UnityMissingModuleAnnotations -LogPath $LogPath
    }
    # RETURN the exit code; do NOT throw on a non-zero value. The DURABLE ARTIFACT
    # the invocation produces (the configure marker / the built player exe / the
    # NUnit results.xml) is the source of truth, validated by the caller. Unity
    # can crash in a BACKGROUND thread (for example the DirectoryMonitor file
    # watcher) DURING shutdown AFTER the artifact is fully written, returning a
    # crash exit code for an otherwise-successful run; gating on the artifact (not
    # the exit code) makes those benign shutdown-race crashes non-fatal while a
    # missing/invalid artifact still fails loudly.
    return $exitCode
}

# The Windows NTSTATUS codes a Unity batch process most commonly exits WITH when
# it crashes or aborts. Keyed by the canonical 8-char uppercase hex of the
# UNSIGNED exit code. This is the single source of truth for both the human
# description (Get-NativeExitCodeDescription) and the "is this a native crash
# code" classifier (Test-NativeCrashExitCode). These statuses identify native errors;
# they do not establish crash timing or prove a shutdown race.
$script:NativeExitCodeDescriptions = [ordered]@{
    'C0000005' = 'STATUS_ACCESS_VIOLATION'
    'C000001D' = 'STATUS_ILLEGAL_INSTRUCTION'
    'C0000017' = 'STATUS_NO_MEMORY'
    'C00000FD' = 'STATUS_STACK_OVERFLOW'
    'C0000135' = 'STATUS_DLL_NOT_FOUND'
    'C0000139' = 'STATUS_ENTRYPOINT_NOT_FOUND'
    'C0000374' = 'STATUS_HEAP_CORRUPTION'
    'C0000409' = 'STATUS_STACK_BUFFER_OVERRUN'
    'C0000420' = 'STATUS_ASSERTION_FAILURE'
}

function ConvertTo-UnsignedExitHex {
    # Canonical 8-char uppercase hex of an exit code, normalizing the negative
    # Int32 form PowerShell yields for a high-bit NTSTATUS (for example -1073741819
    # -> 'C0000005'). Compare against this STRING form, never the 0xC0000005 token:
    # PowerShell parses `0xC0000005` as a NEGATIVE Int32, so a numeric -eq against
    # the unsigned value silently fails (the int/uint conflation this whole helper
    # exists to avoid).
    param([Parameter(Mandatory = $true)][int]$ExitCode)
    $normalized = if ($ExitCode -lt 0) {
        [uint32]($ExitCode + 4294967296)
    } else {
        [uint32]$ExitCode
    }
    return $normalized.ToString('X8')
}

function Test-NativeCrashExitCode {
    # Preserve the standalone build status policy; a matching status does not prove shutdown timing.
    param([Parameter(Mandatory = $true)][int]$ExitCode)
    $hexBare = ConvertTo-UnsignedExitHex -ExitCode $ExitCode
    if ($script:NativeExitCodeDescriptions.Contains($hexBare)) {
        return $true
    }
    return ($hexBare -like 'C0*')
}

function Get-NativeExitCodeDescription {
    param([Parameter(Mandatory = $true)][int]$ExitCode)

    $hexBare = ConvertTo-UnsignedExitHex -ExitCode $ExitCode
    $hex = "0x$hexBare"
    if ($script:NativeExitCodeDescriptions.Contains($hexBare)) {
        return "$hex / $($script:NativeExitCodeDescriptions[$hexBare])"
    }

    return $hex
}

function Test-BenignStandaloneBuildExit {
    param(
        [Parameter(Mandatory = $true)][int]$ExitCode,
        [Parameter(Mandatory = $true)][string]$LogPath
    )

    if ($ExitCode -eq 0 -or (Test-NativeCrashExitCode -ExitCode $ExitCode)) {
        return $true
    }
    if ($ExitCode -ne 255 -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return $false
    }

    try {
        $buildLog = Get-Content -LiteralPath $LogPath -Raw
        if ($buildLog -notmatch '(?m)^Build Finished, Result: Success\.\r?$') {
            return $false
        }
        foreach ($marker in [regex]::Matches($buildLog, '(?m)^##utp:(\{[^\r\n]*\})\r?$')) {
            try {
                $playerInfo = $marker.Groups[1].Value | ConvertFrom-Json -ErrorAction Stop
            } catch {
                continue
            }
            $typeProperty = $playerInfo.PSObject.Properties['type']
            if ($null -eq $typeProperty -or $typeProperty.Value -ne 'PlayerBuildInfo') {
                continue
            }
            $successProperty = $playerInfo.PSObject.Properties['success']
            if ($null -eq $successProperty -or $successProperty.Value -eq $true) {
                return $true
            }
        }
        return $false
    } catch {
        return $false
    }
}

function Get-UnityCrashSignature {
    param([string]$LogPath)

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return ''
    }
    try {
        $logText = Get-Content -LiteralPath $LogPath -Raw
    } catch {
        return ''
    }
    if (-not $logText) {
        return ''
    }

    $observations = @()
    if ($logText -match 'Crash!!!') {
        if ($logText -match 'DirectoryMonitor') {
            $observations += 'The log contains a native crash marker and a DirectoryMonitor reference; crash timing is unresolved'
        } else {
            $observations += 'The log contains a native crash marker; crash timing is unresolved'
        }
    }
    $completion = [regex]::Match($logText, '(?m)^Test run completed\. Exiting with code [^\r\n]*')
    if ($completion.Success) {
        $observations += "Editor completion: $(ConvertTo-UnitySafeLogText -Text $completion.Value)"
    }
    if ($logText -match 'Batchmode quit successfully invoked' -or
        $logText -match 'Exiting batchmode successfully') {
        $observations += 'The log records successful batch completion; the nonzero exit cause is unresolved'
    }
    return $observations -join '; '

}

function Write-UnityBenignExitWarning {
    param(
        [Parameter(Mandatory = $true)][string]$Label,
        [int]$ExitCode = 0,
        [switch]$TimedOut,
        [string]$LogPath,
        [string]$ArtifactSummary
    )

    $cause = if ($TimedOut) {
        'was tree-killed by the watchdog; the shutdown cause is unresolved'
    } else {
        $description = Get-NativeExitCodeDescription -ExitCode $ExitCode
        $hexBare = ConvertTo-UnsignedExitHex -ExitCode $ExitCode
        $crashNote = if ($script:NativeExitCodeDescriptions.Contains($hexBare)) {
            ' (a known native error/crash status; timing and cause are unresolved)'
        } else {
            ' (exit/artifact discrepancy; cause is unresolved)'
        }
        "exited with code $ExitCode / $description$crashNote"
    }
    $signature = Get-UnityCrashSignature -LogPath $LogPath
    $signatureNote = if ($signature) { " Log evidence: $signature." } else { '' }
    $artifactNote = if ($ArtifactSummary) { " Accepted XML: $ArtifactSummary." } else { '' }
    Write-Host "::warning::${Label}: Unity $cause. The validated result artifact is accepted under the existing artifact policy.$artifactNote$signatureNote"
}

function Test-UnityConfigureMarker {
    # Validate the standalone-configure SUCCESS MARKER as the source of truth for
    # the configure pass (UhCiTestConfigurator.Apply writes it as its final
    # action). Returns '' when the marker exists and is FRESH for this run, else a
    # short reason string (mirrors Test-StandalonePlayerBuildOutput's contract).
    # A fresh marker proves Apply() ran to completion even if Unity then crashed in
    # a background thread during shutdown and returned a crash exit code.
    param(
        [Parameter(Mandatory = $true)][string]$MarkerPath,
        [Parameter(Mandatory = $true)][datetime]$StartedUtc
    )

    if (-not (Test-Path -LiteralPath $MarkerPath -PathType Leaf)) {
        return 'configure marker was not written (UhCiTestConfigurator.Apply did not run to completion)'
    }
    $marker = Get-Item -LiteralPath $MarkerPath
    if ($marker.LastWriteTimeUtc -lt $StartedUtc.AddSeconds(-5)) {
        return "stale configure marker; LastWriteTimeUtc=$($marker.LastWriteTimeUtc.ToString('o'))"
    }
    return ''
}

function Invoke-UnityNativeStartupProbe {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string]$LogPath
    )

    $logDir = Split-Path -Parent $LogPath
    if ($logDir -and -not (Test-Path -LiteralPath $logDir -PathType Container)) {
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    }

    Write-Host "::group::Unity native startup diagnostics"
    Write-Host "Runner name: $env:RUNNER_NAME"
    Write-Host "Runner OS: $env:RUNNER_OS"
    Write-Host "Runner architecture: $env:RUNNER_ARCH"
    Write-Host "Unity editor path: $EditorPath"
    try {
        $editorItem = Get-Item -LiteralPath $EditorPath
        Write-Host "Unity editor file version: $($editorItem.VersionInfo.FileVersion)"
        Write-Host "Unity editor product version: $($editorItem.VersionInfo.ProductVersion)"
    } catch {
        Write-Host "::notice::Could not read Unity editor version info: $($_.Exception.Message)"
    }

    Write-Host "Unity licensing client inventory:"
    $licensingClientCandidates = New-Object System.Collections.Generic.List[string]
    foreach ($root in @(${env:ProgramFiles}, ${env:ProgramFiles(x86)})) {
        if ($root -and $root.Trim().Length -gt 0) {
            $licensingClientCandidates.Add(
                (Join-Path $root 'Common Files\Unity\UnityLicensingClient\Unity.Licensing.Client.exe')
            )
        }
    }
    if ($env:LOCALAPPDATA -and $env:LOCALAPPDATA.Trim().Length -gt 0) {
        $licensingClientCandidates.Add(
            (Join-Path $env:LOCALAPPDATA 'Unity\Unity.Licensing.Client\Unity.Licensing.Client.exe')
        )
    }
    foreach ($candidate in $licensingClientCandidates) {
        $exists = Test-Path -LiteralPath $candidate -PathType Leaf
        Write-Host "  [$exists] $candidate"
    }

    $probeArgs = @(
        '-version',
        '-batchmode',
        '-nographics',
        '-quit',
        '-logFile', '-'
    )

    Write-Host "`"$EditorPath`" $($probeArgs -join ' ')"
    & $EditorPath @probeArgs 2>&1 | Tee-Object -FilePath $LogPath | ForEach-Object { Write-Host (ConvertTo-UnitySafeLogText -Text ([string]$_)) }
    $exitCode = $LASTEXITCODE
    $description = Get-NativeExitCodeDescription -ExitCode $exitCode
    Write-Host "Unity native startup probe exit code: $exitCode ($description)"
    Write-Host "::endgroup::"

    if ($exitCode -ne 0) {
        throw "Unity native startup probe failed with exit code $exitCode ($description) after the pre-lock healthy-existing editor check. CI Unity jobs do not repair editors in-job; run scripts/unity/maintain-windows-runner.ps1 or dispatch .github/workflows/runner-bootstrap.yml, then retry. See the streamed probe log above (also saved to $LogPath)."
    }
}

# CLASS-OF-ISSUE GUARD: the defect this whole change fixes is a single analyzer
# DLL handed to the compiler from MORE THAN ONE path (the Assets/Plugins copy plus
# a duplicate registration). That is invisible in a raw csc command line, so this
# best-effort scanner reads the Unity compile log, collects every analyzer the
# compiler was given (-a:/-analyzer:, quoted or not), and -- when the SAME DLL file
# name came from more than one distinct path -- names the offending DLL and every
# path. It catches a regression of the project-generation fix loudly. NEVER throws
# (the caller is already on a throw path).
function Write-DuplicateAnalyzerDiagnostics {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$LogPath)

    if (-not $LogPath -or -not (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        return
    }

    try {
        # -a:"path" / -a:path / -analyzer:"path" / -analyzer:path. Captured lazily
        # up to the first '.dll' so an unquoted, space-separated token does not
        # swallow the next argument.
        $pattern = '-(?:a|analyzer):"?([^"\r\n]+?\.dll)"?(?:"|\s|$)'
        $pathsByName = @{}
        $hits = @(
            Select-String -LiteralPath $LogPath -Pattern $pattern -AllMatches -ErrorAction SilentlyContinue
        )
        foreach ($hit in $hits) {
            foreach ($match in $hit.Matches) {
                $fullPath = $match.Groups[1].Value.Trim() -replace '\\', '/'
                if (-not $fullPath) {
                    continue
                }
                $name = Split-Path -Leaf $fullPath
                if (-not $pathsByName.ContainsKey($name)) {
                    $pathsByName[$name] = New-Object 'System.Collections.Generic.HashSet[string]'
                }
                [void]$pathsByName[$name].Add($fullPath)
            }
        }

        $duplicates = @($pathsByName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 })
        if ($duplicates.Count -lt 1) {
            return
        }

        Write-Host "::group::Duplicate analyzer registration"
        foreach ($entry in $duplicates) {
            $joinedPaths = (@($entry.Value) | Sort-Object) -join '; '
            Write-CiError ("Analyzer/source-generator '$($entry.Key)' was handed to the compiler from " +
                "$($entry.Value.Count) distinct paths: $joinedPaths. A source generator that runs more than " +
                "once emits each member twice (CS0102) and duplicate precompiled assemblies are rejected " +
                "outright. The harness must register each analyzer DLL EXACTLY ONCE (the pre-created " +
                "Assets/Plugins copy); it must NOT also wire one via csc.rsp.")
        }
        Write-Host "::endgroup::"
    } catch {
        Write-Host "::warning::Could not scan for duplicate analyzer registration: $($_.Exception.Message)"
    }
}

function Write-UnityResultFailureDiagnostics {
    param(
        [string]$LogPath,
        [string]$Project,
        [Parameter(Mandatory = $true)][string]$Label
    )

    Write-Host "::group::Unity result failure diagnostics ($Label)"
    try {
        if ($LogPath -and (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
            Write-Host "Unity log path: $LogPath"
            # Compose this function's scan list as:
            #   (catastrophic patterns from the shared $script:CatastrophicPatterns
            #    array; ONLY the regex-form entries, since Select-String's
            #    -Pattern overload is regex when -SimpleMatch is absent)
            # plus this function's local additions (Aborting/Exiting/No tests/
            # TestRunner/results.xml/assemblyNames) -- the latter are NOT
            # catastrophic-class patterns and are intentionally NOT in the
            # shared array. This keeps the "single source of truth" rule for
            # the overlapping patterns (error CS\d+, warning CS8032) without
            # changing the function's overall scan behavior.
            $catastrophicRegexes = @(
                foreach ($entry in $script:CatastrophicPatterns) {
                    if (-not $entry.UseSimple) {
                        $entry.Pattern
                    }
                }
            )
            $localDiagnosticPatterns = @(
                'Aborting batchmode',
                'Exiting batchmode successfully',
                'No tests',
                'TestRunner',
                'IPCStream \(Upm-[^)]+\): IPC stream failed to read',
                'Failed to resolve packages',
                'Cancelled resolving packages',
                'results\.xml',
                'assemblyNames',
                'Files generated by test without cleanup\.',
                'CleanupVerificationTask',
                'IgnoreFailingMessages:false',
                'Unhandled log message',
                'UnexpectedLogMessageException(?!\.cs)',
                'EditorWindow\.ShowUtility',
                'd3d12: Unrecoverable GPU device error',
                'AddCursorRect called outside an editor OnGUI'
            )
            $diagnosticPatterns = @($catastrophicRegexes) + @($localDiagnosticPatterns)
            $matches = @(
                Select-String -LiteralPath $LogPath -Pattern $diagnosticPatterns -ErrorAction SilentlyContinue |
                    Select-Object -First 80
            )
            if ($matches.Count -gt 0) {
                Write-Host "Selected Unity log lines:"
                foreach ($match in $matches) {
                    Write-Host ("  line {0}: {1}" -f $match.LineNumber, (ConvertTo-UnitySafeLogText -Text $match.Line.Trim()))
                }
            } else {
                Write-Host "No targeted diagnostic lines matched in the Unity log."
            }

            $logText = Get-Content -LiteralPath $LogPath -Raw
            if ($logText -match 'warning CS8032') {
                Write-CiError "Unity could not instantiate one or more unity-helpers analyzers/source generators (CS8032). Check that Editor/Analyzers DLLs target the Roslyn version supported by this Unity editor."
            }
            if ($logText -match 'error CS0315' -and $logText -match 'Simple(?:Untargeted|Targeted|Broadcast)Message') {
                Write-CiError "Message fixture compile errors followed missing generated interfaces. This usually means the unity-helpers source generator did not load."
            }
            if ($logText -match 'Exiting batchmode successfully') {
                Write-CiError "Unity exited with code 0 but did not write NUnit results. Check the selected assembly list, test platform, and TestRunner log lines above."
            }
            # A C# compile error aborts batchmode BEFORE results.xml is written.
            # Unity prints "Aborting batchmode due to failure:" immediately followed
            # by the offending diagnostics. Surface a CRISP, leg-named "Compilation
            # failed" message with the first few CS errors so the operator sees the
            # ACTUAL root cause instead of inferring "compile failed" from the
            # generic missing-results throw. (e.g. the CS0104 Reflex-integration
            # ambiguity that aborted every integration leg in run 74473484398.)
            if ($logText -match 'Aborting batchmode due to failure') {
                $csErrors = @(
                    Select-String -LiteralPath $LogPath -Pattern 'error CS\d+' -ErrorAction SilentlyContinue |
                        Select-Object -First 5
                )
                if ($csErrors.Count -gt 0) {
                    $firstErrors = (
                        $csErrors | ForEach-Object { ConvertTo-SingleLineDiagnostic -Text $_.Line }
                    ) -join ' | '
                    Write-CiError "Compilation failed for ${Label}: Unity aborted batchmode before writing NUnit results. First C# error(s): $firstErrors"
                } else {
                    Write-CiError "Compilation/startup failed for ${Label}: Unity aborted batchmode before writing NUnit results (no 'error CS####' line found; see the selected log lines above)."
                }
            }
            # The shared IMGUI harness is window-free. A "No graphic device" line in
            # EditMode now points to a remaining native EditorWindow/GUIView path or
            # another graphics-bound test that should be isolated from headless CI.
            if ($logText -match 'No graphic device is available to initialize the view') {
                Write-CiError "Editor code attempted to initialize a graphics-backed view for ${Label} ('No graphic device is available to initialize the view'). CI-driven editor tests should avoid native EditorWindow/GUIView surfaces and use offscreen harnesses such as TestIMGUIExecutor."
            }
            if (Test-UnityPackageManagerTransientFailure -LogPath $LogPath) {
                Write-CiError "Unity Package Manager canceled package resolution before tests started. This is a CI/Unity package-resolution failure, not a unity-helpers test assertion."
                Write-UnityPackageManagerDiagnostics -Project $Project -LogPath $LogPath
            }

            # Name a duplicate analyzer registration (the same generator/analyzer
            # DLL fed to csc from two paths) -- the precise root cause of the
            # "Multiple precompiled assemblies" / CS0102 duplicate-'MessageType'
            # failures this harness change fixes.
            Write-DuplicateAnalyzerDiagnostics -LogPath $LogPath
        } else {
            Write-Host "Unity log path unavailable or missing: $LogPath"
        }

        if ($Project) {
            $analyzerCopyDir = Join-Path $Project 'Assets\Plugins\Editor\WallstopStudios.UnityHelpers'
            Write-Host "Pre-created analyzer copy dir exists: $(Test-Path -LiteralPath $analyzerCopyDir -PathType Container)"
            $scriptAssemblies = Join-Path $Project 'Library\ScriptAssemblies'
            if (Test-Path -LiteralPath $scriptAssemblies -PathType Container) {
                Write-Host "Script assemblies present:"
                Get-ChildItem -LiteralPath $scriptAssemblies -Filter '*.dll' -ErrorAction SilentlyContinue |
                    Select-Object -ExpandProperty Name |
                    Sort-Object |
                    ForEach-Object { Write-Host "  $_" }
            } else {
                Write-Host "Script assemblies directory missing: $scriptAssemblies"
            }
        }
    } catch {
        Write-Host "::warning::Could not collect Unity result failure diagnostics: $($_.Exception.Message)"
    }
    Write-Host "::endgroup::"
}

function Write-UnityRunFailureDiagnostics {
    # Emit the combined analyzer-setup + result-failure diagnostics for a Unity
    # batch invocation whose DURABLE ARTIFACT validation failed (missing configure
    # marker / invalid player exe / missing-or-invalid results.xml). This is the
    # failure-path diagnostics bundle the retired Invoke-UnityEditorWithFailureDiagnostics
    # wrapper used to emit on a thrown non-zero exit; it now fires from the
    # artifact-validation failure branch (the exit code is no longer the trigger).
    # Two callers: the configure marker-validation failure and the standalone build
    # exe-validation failure (the latter then also emits Write-StandaloneBuildOutputDiagnostics).
    # The editmode/playmode + standalone-player paths get the result-failure half
    # directly from Test-NUnitResults, which calls Write-UnityResultFailureDiagnostics.
    param(
        [Parameter(Mandatory = $true)][string]$Project,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [Parameter(Mandatory = $true)][string]$CscLabel,
        [Parameter(Mandatory = $true)][string]$DiagnosticsLabel
    )

    Write-AnalyzerSetupDiagnostics -Project $Project -LogPath $LogPath -Label $CscLabel
    Write-UnityResultFailureDiagnostics -LogPath $LogPath -Project $Project -Label $DiagnosticsLabel
}

function Write-StandaloneDirectorySnapshot {
    param(
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$Path,
        [int]$MaxEntries = 60
    )

    try {
        Write-Host "${Label}: $Path"
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            Write-Host "  (missing)"
            return
        }

        $entries = @(
            Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue |
                Sort-Object FullName |
                Select-Object -First $MaxEntries
        )
        if ($entries.Count -lt 1) {
            Write-Host "  (empty)"
            return
        }

        foreach ($entry in $entries) {
            $kind = if ($entry.PSIsContainer) { 'dir ' } else { 'file' }
            $length = if ($entry.PSIsContainer) { '' } else { " $($entry.Length) bytes" }
            Write-Host "  [$kind] $($entry.FullName)$length"
        }
    } catch {
        Write-Host "::warning::Could not snapshot ${Label}: $($_.Exception.Message)"
    }
}

function Write-StandaloneBuildOutputDiagnostics {
    param(
        [Parameter(Mandatory = $true)][string]$Project,
        [Parameter(Mandatory = $true)][string]$ExpectedExe,
        [string]$LogPath,
        [datetime]$BuildStartedUtc
    )

    Write-Host "::group::Standalone player build output diagnostics"
    try {
        Write-Host "Expected exe: $ExpectedExe"
        Write-Host "UH_PLAYER_BUILD_PATH: $env:UH_PLAYER_BUILD_PATH"
        Write-Host "Build started UTC: $($BuildStartedUtc.ToString('o'))"

        $expectedDir = Split-Path -Parent $ExpectedExe
        Write-StandaloneDirectorySnapshot -Label 'Expected output directory' -Path $expectedDir
        Write-StandaloneDirectorySnapshot -Label 'Project Build directory' -Path (Join-Path $Project 'Build')
        Write-StandaloneDirectorySnapshot -Label 'Project Temp\UhTestPlayer directory' -Path (Join-Path $Project 'Temp\UhTestPlayer')
        Write-StandaloneDirectorySnapshot -Label 'Project Temp\PlayerWithTests directory' -Path (Join-Path $Project 'Temp\PlayerWithTests')

        Write-Host "Discovered executable candidates under Build/Temp:"
        $candidateRoots = @(
            Join-Path $Project 'Build'
            Join-Path $Project 'Temp'
        )
        $candidates = @(
            foreach ($root in $candidateRoots) {
                if (Test-Path -LiteralPath $root -PathType Container) {
                    Get-ChildItem -LiteralPath $root -Recurse -Filter '*.exe' -File -ErrorAction SilentlyContinue
                }
            }
        )
        if ($candidates.Count -lt 1) {
            Write-Host "  (none)"
        } else {
            foreach ($candidate in ($candidates | Sort-Object FullName | Select-Object -First 40)) {
                Write-Host ("  {0} ({1} bytes, LastWriteTimeUtc={2:o})" -f $candidate.FullName, $candidate.Length, $candidate.LastWriteTimeUtc)
            }
        }

        if ($LogPath -and (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
            $logText = Get-Content -LiteralPath $LogPath -Raw
            Write-Host "Build log markers:"
            foreach ($marker in @(
                    'UhCiStandaloneBuildModifier',
                    'UH_PLAYER_BUILD_PATH',
                    'UhTestPlayer',
                    'PlayerWithTests',
                    'AutoRunPlayer',
                    'CopyFiles'
                )) {
                Write-Host "  ${marker}: $($logText.Contains($marker))"
            }
            Write-Host "Build log tail:"
            Get-Content -LiteralPath $LogPath -Tail 80 -ErrorAction SilentlyContinue |
                ForEach-Object { Write-Host (ConvertTo-UnitySafeLogText -Text "  $_") }
        } else {
            Write-Host "Build log missing: $LogPath"
        }
    } catch {
        Write-Host "::warning::Could not collect standalone player build diagnostics: $($_.Exception.Message)"
    }
    Write-Host "::endgroup::"
}

function Test-StandalonePlayerBuildOutput {
    param(
        [Parameter(Mandatory = $true)][string]$ExpectedExe,
        [Parameter(Mandatory = $true)][datetime]$BuildStartedUtc,
        [switch]$RequireGameAssembly
    )

    if (-not (Test-Path -LiteralPath $ExpectedExe -PathType Leaf)) {
        return "missing exe"
    }

    $exe = Get-Item -LiteralPath $ExpectedExe
    if ($exe.LastWriteTimeUtc -lt $BuildStartedUtc.AddSeconds(-5)) {
        return "stale exe; LastWriteTimeUtc=$($exe.LastWriteTimeUtc.ToString('o'))"
    }

    $dataDir = Join-Path (Split-Path -Parent $ExpectedExe) ("{0}_Data" -f [System.IO.Path]::GetFileNameWithoutExtension($ExpectedExe))
    if (-not (Test-Path -LiteralPath $dataDir -PathType Container)) {
        return "missing player data directory: $dataDir"
    }

    # IL2CPP only: GameAssembly.dll is the LINKED native output of the il2cpp C++
    # compile -- the file that actually contains the compiled managed/test code. Bee
    # stages the bootstrapper exe and the _Data folder EARLY, BEFORE il2cpp compiles
    # the generated C++, so a C++ compile failure (e.g. an MSVC `C1001` internal
    # compiler error) leaves a FRESH exe + _Data but NO fresh GameAssembly.dll.
    # Validating only the exe/_Data therefore green-lights a failed build and runs a
    # broken player. GameAssembly.dll cannot exist fresh unless the compile AND link
    # succeeded, so it is the authoritative "the IL2CPP build actually finished" signal.
    if ($RequireGameAssembly) {
        $gameAssembly = Join-Path (Split-Path -Parent $ExpectedExe) 'GameAssembly.dll'
        if (-not (Test-Path -LiteralPath $gameAssembly -PathType Leaf)) {
            return "missing GameAssembly.dll (IL2CPP native compile/link did not complete): $gameAssembly"
        }
        $ga = Get-Item -LiteralPath $gameAssembly
        if ($ga.LastWriteTimeUtc -lt $BuildStartedUtc.AddSeconds(-5)) {
            return "stale GameAssembly.dll (IL2CPP native compile/link did not run this build); LastWriteTimeUtc=$($ga.LastWriteTimeUtc.ToString('o'))"
        }
    }

    return ''
}

function Test-NUnitResults {
    # The NUnit results.xml is the SOLE source of truth for editmode/playmode and
    # the standalone player run. The producing process exit code is advisory;
    # accepted XML can coexist with an ordinary nonzero exit or a native error.
    # Missing, invalid, empty or failing XML still fails independently of the exit.
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Label,
        [string]$LogPath,
        [string]$Project,
        [int]$UnityExitCode = 0,
        [switch]$RequirePassedTests
    )

    $exitNote = if ($UnityExitCode -ne 0) {
        " Unity exited $UnityExitCode / $(Get-NativeExitCodeDescription -ExitCode $UnityExitCode) (the results FILE, not the exit code, is the source of truth)."
    } else {
        ''
    }

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-CiError "No NUnit results XML exists at $Path for $Label.$exitNote"
        Write-UnityResultFailureDiagnostics -LogPath $LogPath -Project $Project -Label $Label
        throw "Unity did not produce NUnit results for $Label.$exitNote"
    }

    [xml]$xml = Get-Content -LiteralPath $Path -Raw
    $run = $xml.SelectSingleNode('//test-run')
    if (-not $run) {
        Write-CiError "NUnit results at $Path do not contain a <test-run> element.$exitNote"
        Write-UnityResultFailureDiagnostics -LogPath $LogPath -Project $Project -Label $Label
        throw "Invalid NUnit results for $Label."
    }

    $total = [int]$run.total
    $passed = [int]$run.passed
    $failed = [int]$run.failed
    $skipped = [int]$run.skipped
    $failedNodeCount = Get-UnityFailedNodeCount -Xml $xml

    Write-Host "Results: total=$total passed=$passed failed=$failed skipped=$skipped"
    if ($total -lt 1) {
        # total=0 has TWO very different causes; the producing process's exit code
        # disambiguates them. A non-zero exit with a valid <test-run> but zero
        # executed cases means Unity Test Framework wrote a zero-count XML for a
        # failed run. That can be a pre-test abort OR a post-run failure such as
        # cleanup verification; the Unity log is the source of the actionable
        # symptom, so scan it before throwing.
        if ($UnityExitCode -ne 0) {
            # GetAttribute (not the dynamic $run.result accessor) so a malformed
            # <test-run> with no 'result' attribute returns '' instead of THROWING
            # under Set-StrictMode -Version Latest -- the throw would suppress the
            # very diagnostics this branch exists to emit, on exactly the abort path
            # where the attribute is most likely missing.
            $resultState = $run.GetAttribute('result')
            Write-CiError "Unity exited $UnityExitCode but results.xml at $Path has total=0 (result='$resultState') for $Label. This is a failed or aborted Unity run with misleading zero-count NUnit XML, not proof of an empty assembly list. Inspect the Unity execution diagnostics below for cleanup-verification, unexpected-log, compile, package, or editor-window crash symptoms.$exitNote"
            Write-UnityExecutionSymptomDiagnostics -LogPath $LogPath -Label $Label
            Write-UnityResultFailureDiagnostics -LogPath $LogPath -Project $Project -Label $Label
            throw "Test run for $Label produced zero-count NUnit XML with a non-zero Unity exit ($UnityExitCode)."
        }
        Write-CiError "0 tests ran for $Label -- check assembly selection and package testables.$exitNote"
        throw "0 tests ran for $Label."
    }
    if ($failed -gt 0 -or $failedNodeCount -gt 0) {
        # Enumerate WHICH tests failed (fullname + message + stack) BEFORE the
        # throw so the operator sees the actionable detail, not just the count.
        # Best-effort inside the helper's own try/catch -- it never masks the
        # real failure below. ($exitNote is intentionally omitted here: when tests
        # genuinely failed, the named failing tests ARE the actionable signal and
        # the producing process's exit code is noise. The exit note is folded into
        # the missing-file / invalid / zero-test branches above, where the exit
        # code IS the most informative remaining clue.)
        Write-UnityFailedTestAnnotations -Xml $xml -Label $Label
        $failureCountForMessage = [Math]::Max($failed, $failedNodeCount)
        Write-CiError "$failureCountForMessage tests failed for $Label."
        throw "$failureCountForMessage tests failed for $Label."
    }

    if ($RequirePassedTests -and $passed -le 0) {
        throw "No selected tests passed for $Label; an all-skipped or inconclusive filtered run is not acceptance."
    }

    # The exit diagnostic must preserve the accepted XML outcomes without attributing an unproven cause.
    if ($UnityExitCode -ne 0) {
        $inconclusive = $xml.SelectNodes("//test-case[@result='Inconclusive']").Count
        $artifactSummary = "total=$total passed=$passed failed=$failed skipped=$skipped inconclusive=$inconclusive root-result='$($run.GetAttribute('result'))'"
        Write-UnityBenignExitWarning -Label $Label -ExitCode $UnityExitCode -LogPath $LogPath -ArtifactSummary $artifactSummary
    }
    Write-CiNotice "${Label}: total=$total passed=$passed failed=$failed skipped=$skipped"
}




function Get-UnityNativeReportSummary {
    param([string]$LogPath)
    return Get-NativeReportSummary -LogPath $LogPath
}

function Write-UnityExecutionObservation {
    param([string]$LogPath, [hashtable]$ProcessObservation, [string]$Label)

    try {
        $path = [IO.Path]::ChangeExtension($LogPath, 'execution-diagnostics.json')
        if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force -ErrorAction Stop }
        $nativeReports = Get-UnityNativeReportSummary -LogPath $null
        $nativeReports.State = 'log-persistence-unavailable'
        if ($ProcessObservation -and $ProcessObservation['LogPersistence'] -eq 'written') {
            $nativeReports = Get-UnityNativeReportSummary -LogPath $LogPath
        } elseif ($ProcessObservation -and $ProcessObservation['LogPersistence'] -eq 'write-failed') {
            $nativeReports.State = 'log-write-failed'
        }
        $report = [ordered]@{
            CapturedUtc = [DateTime]::UtcNow.ToString('o')
            Label = $Label
            Process = $ProcessObservation
            NativeReports = $nativeReports
            WindowsEvents = Get-UnityProcessFailureEvents -ProcessObservation $ProcessObservation
        }
        $json = ConvertTo-UnitySafeLogText -Text (ConvertTo-Json -InputObject $report -Depth 8)
        Set-Content -LiteralPath $path -Value $json -Encoding UTF8 -ErrorAction Stop
        Write-Host "::notice::Saved Unity execution diagnostics: $path"
    } catch {
        Write-Host '::warning::Could not persist Unity execution diagnostics; execution outcome is unchanged.'
    }
}

function Write-UnityConfigureFailureObservation {
    param([string]$LogPath, [hashtable]$ProcessObservation, [string]$Suffix = '')

    try {
        $stem = [IO.Path]::GetFileNameWithoutExtension($LogPath)
        if ($Suffix) { $stem += ".$Suffix" }
        $path = Join-Path (Split-Path -Parent $LogPath) "$stem.process-diagnostics.json"
        $report = [ordered]@{
            Process = $ProcessObservation
            WindowsEvents = Get-UnityProcessFailureEvents -ProcessObservation $ProcessObservation
        }
        $json = ConvertTo-UnitySafeLogText -Text (ConvertTo-Json -InputObject $report -Depth 8)
        Set-Content -LiteralPath $path -Value $json -Encoding UTF8 -ErrorAction Stop
        Write-Host "::notice::Saved configure failure process diagnostics: $path"
    } catch {
        Write-Host '::warning::Could not persist configure failure process diagnostics; original failure is unchanged.'
    }
}

# Run the UhCiTestConfigurator.Apply configure pass (a SEPARATE -executeMethod
# editor invocation) and validate the success marker it writes as its final action.
# The CONFIGURED PROJECT -- proven by a FRESH marker -- is the source of truth, NOT
# Unity's process exit code: Unity can crash in a background thread during shutdown
# AFTER Apply() fully completes (e.g. the DirectoryMonitor file-watcher faulting,
# returning 0xC0000005) for a configure that actually succeeded; a MISSING marker is
# a real failure that throws with the usual diagnostics. Apply() also persists any
# UH_ADDITIONAL_SCRIPTING_DEFINES onto the Standalone group's scripting defines and
# saves the project, so a SUBSEQUENT -runTests invocation loads them from startup
# (Unity does not recompile mid-run in -batchmode). Shared by the standalone path
# (always) and the editmode/playmode path (only when extra defines are requested).
function Invoke-UnityConfigurePass {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string]$ProjectPath,
        [Parameter(Mandatory = $true)][string]$MarkerPath,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [Parameter(Mandatory = $true)][string]$Label,
        [string[]]$ExtraArguments = @(),
        [scriptblock]$ConfigureInvoker,
        $FrozenContext = $null
    )

    if (Test-Path -LiteralPath $MarkerPath -PathType Leaf) {
        Remove-Item -LiteralPath $MarkerPath -Force
    }
    if (Test-Path -LiteralPath $LogPath -PathType Leaf) {
        Remove-Item -LiteralPath $LogPath -Force -ErrorAction Stop
    }
    $configureArgs = @(
        '-quit',
        '-batchmode',
        '-nographics',
        '-releaseCodeOptimization',
        '-projectPath', $ProjectPath,
        '-buildTarget', 'StandaloneWindows64',
        '-executeMethod', 'UhCiTestConfigurator.Apply',
        '-logFile', '-'
    ) + @($ExtraArguments)
    # Run the configure pass under the SAME tree-kill watchdog (wall-clock + no-output
    # stall) as the test run, not the bare `&` path. This is a SEPARATE cold editor
    # invocation that opens the project, compiles the local package + the injected
    # configurator, runs Apply() to persist the requested global defines, and quits (the
    # define-driven recompile itself happens later, on the -runTests pass's first compile
    # -- Unity does not recompile on a mid-run define change). A cold-compile or a
    # -batchmode shutdown deadlock here would otherwise silently burn the whole GitHub
    # step timeout. There is no completion sentinel (this is -quit/-executeMethod, not
    # -runTests), so the wall-clock + stall guards alone bound it; the durable marker file
    # remains the source of truth for whether Apply() actually ran.
    $invokeConfigure = {
        param([string]$AttemptLabel)
        $env:UH_CONFIGURE_MARKER_PATH = $MarkerPath
        if ($ConfigureInvoker) {
            return & $ConfigureInvoker $configureArgs $LogPath $AttemptLabel
        }
        return Invoke-UnityEditor `
            -EditorPath $EditorPath `
            -Arguments $configureArgs `
            -Label $AttemptLabel `
            -LogPath $LogPath `
            -TimeoutSeconds (Get-EditorTestRunTimeoutSeconds) `
            -StallSeconds (Get-EditorTestStallSeconds) `
            -ProcessObservation $processObservation
    }

    $firstAttemptLogPath = $null
    $artifactDatabaseFailure = $null
    $processObservation = @{ State = 'unavailable' }
    $configureStartedUtc = [DateTime]::UtcNow
    try {
        $configureExit = & $invokeConfigure $Label
    } catch {
        if (-not (Test-UnityConfigureMarker -MarkerPath $MarkerPath -StartedUtc $configureStartedUtc)) { throw }
        $artifactDatabaseFailure = Test-UnityArtifactDatabaseStartupFailure -LogPath $LogPath
        if (-not $artifactDatabaseFailure -and
            -not (Test-UnityConfigurePackageManagerRetryableFailure -LogPath $LogPath)) { throw }
        $configureExit = 1
    } finally {
        if ($null -ne $FrozenContext) { $FrozenContext.ConfigureOutcomes.Add([pscustomobject]$processObservation.Clone()) }
        # The configurator has run; drop the marker-path env var so it cannot be
        # inherited by later child processes (only Apply reads it).
        Remove-Item -LiteralPath Env:\UH_CONFIGURE_MARKER_PATH -ErrorAction SilentlyContinue
    }
    $configureProblem = Test-UnityConfigureMarker -MarkerPath $MarkerPath -StartedUtc $configureStartedUtc

    if ($null -eq $artifactDatabaseFailure) {
        $artifactDatabaseFailure = -not [string]::IsNullOrWhiteSpace($configureProblem) -and
            (Test-UnityArtifactDatabaseStartupFailure -LogPath $LogPath)
    }
    # A fresh marker proves Apply completed. Marker-less known startup database failures and
    # exact UPM cancellation signatures receive one recovery attempt.
    if (
        -not [string]::IsNullOrWhiteSpace($configureProblem) -and
        ($artifactDatabaseFailure -or (Test-UnityConfigurePackageManagerRetryableFailure -LogPath $LogPath))
    ) {
        Write-UnityConfigureFailureObservation -LogPath $LogPath -ProcessObservation $processObservation -Suffix 'first-attempt'
        $retryReason = 'UPM cancellation'
        if ($artifactDatabaseFailure) {
            $retryReason = 'startup artifact-database corruption'
            Write-CiWarning 'Unity failed while initializing its artifact database before configuration completed; retaining the failed Library and rebuilding once.'
        } else {
            Write-CiWarning "Unity Package Manager canceled package resolution before the configure marker existed; clearing UPM state and retrying once."
            Write-UnityPackageManagerTransientFailureWarnings -LogPath $LogPath
        }
        $preservedLogPath = Join-Path (Split-Path -Parent $LogPath) ("{0}.first-attempt.log" -f [System.IO.Path]::GetFileNameWithoutExtension($LogPath))
        try {
            Copy-Item -LiteralPath $LogPath -Destination $preservedLogPath -Force -ErrorAction Stop
            $firstAttemptLogPath = $preservedLogPath
            Write-CiNotice "Saved first failed Unity configure log before retry: $firstAttemptLogPath"
        } catch {
            Write-CiWarning "Could not preserve first failed Unity configure log before retry: $($_.Exception.Message)"
        }
        $observationPath = [IO.Path]::ChangeExtension($LogPath, 'execution-diagnostics.json')
        if (Test-Path -LiteralPath $observationPath -PathType Leaf) {
            try {
                Copy-Item -LiteralPath $observationPath -Destination ([IO.Path]::ChangeExtension($preservedLogPath, 'execution-diagnostics.json')) -Force -ErrorAction Stop
            } catch {
                Write-CiWarning 'Could not preserve first failed Unity configure execution diagnostics before retry.'
            }
        }
        if ($artifactDatabaseFailure) {
            Reset-UnityArtifactDatabaseLibrary -Project $ProjectPath
        } else {
            Clear-UnityPackageManagerRetryState -Project $ProjectPath
        }
        if (Test-Path -LiteralPath $MarkerPath -PathType Leaf) {
            Remove-Item -LiteralPath $MarkerPath -Force
        }

        if (Test-Path -LiteralPath $LogPath -PathType Leaf) {
            Remove-Item -LiteralPath $LogPath -Force -ErrorAction Stop
        }
        $processObservation = @{ State = 'unavailable' }
        $configureStartedUtc = [DateTime]::UtcNow
        try {
            $configureExit = & $invokeConfigure "$Label (retry 1 after $retryReason)"
        } finally {
            if ($null -ne $FrozenContext) { $FrozenContext.ConfigureOutcomes.Add([pscustomobject]$processObservation.Clone()) }
            Remove-Item -LiteralPath Env:\UH_CONFIGURE_MARKER_PATH -ErrorAction SilentlyContinue
        }
        $configureProblem = Test-UnityConfigureMarker -MarkerPath $MarkerPath -StartedUtc $configureStartedUtc
    }

    if (-not [string]::IsNullOrWhiteSpace($configureProblem)) {
        Write-UnityConfigureFailureObservation -LogPath $LogPath -ProcessObservation $processObservation
        Write-UnityRunFailureDiagnostics `
            -Project $ProjectPath `
            -LogPath $LogPath `
            -CscLabel $Label `
            -DiagnosticsLabel $Label
        throw "$Label failed ($configureProblem; Unity exit code $configureExit / $(Get-NativeExitCodeDescription -ExitCode $configureExit)). See the streamed Unity log above (also saved to $LogPath)."
    }
    if ($configureExit -ne 0) {
        Write-UnityBenignExitWarning -Label $Label -ExitCode $configureExit -LogPath $LogPath
    }
    Write-AnalyzerSetupDiagnostics -Project $ProjectPath -LogPath $LogPath -Label $Label
    if (-not [string]::IsNullOrWhiteSpace($firstAttemptLogPath)) {
        Assert-NoUnityCompilerWarnings -LogPath $firstAttemptLogPath -Label "$Label (first attempt)" -PackageRoot $RepoRoot
    }
    Assert-NoUnityCompilerWarnings -LogPath $LogPath -Label $Label -PackageRoot $RepoRoot
}

function Assert-UnityRunMode {
    param(
        [string]$Mode,
        [string]$Assemblies,
        [string]$Project,
        [string]$ExportPath,
        [string]$Version,
        [bool]$HasTestOptions
    )

    if ($Mode -ne 'export') {
        if ([string]::IsNullOrWhiteSpace($Assemblies)) {
            throw '-AssemblyNames is required for Unity test modes.'
        }
        if (-not [string]::IsNullOrWhiteSpace($ExportPath)) {
            throw '-ExportPackagePath requires -TestMode export.'
        }
        return
    }
    if ([string]::IsNullOrWhiteSpace($Project) -or [string]::IsNullOrWhiteSpace($ExportPath)) {
        throw 'Export requires an already staged -ProjectPath and -ExportPackagePath.'
    }
    if ($HasTestOptions -or -not [string]::IsNullOrWhiteSpace($Assemblies)) {
        throw 'Export cannot use test selection, project generation, or test project modifiers.'
    }
    if ([IO.Path]::GetExtension($ExportPath) -ine '.unitypackage') {
        throw '-ExportPackagePath must name a .unitypackage file.'
    }
    foreach ($required in @('Assets/Editor/UnityHelpersPackageExporter.cs',
            'Assets/WallstopStudios/UnityHelpers/package.json', 'Packages/manifest.json',
            'ProjectSettings/ProjectVersion.txt')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Project $required) -PathType Leaf)) {
            throw "Export project is not staged: missing $required. Run uv run --project scripts/python~ --locked --no-dev python scripts/unity/stage_unitypackage.py first."
        }
    }
    $projectVersion = Get-Content -LiteralPath (Join-Path $Project 'ProjectSettings/ProjectVersion.txt') -Raw
    if ($projectVersion -notmatch ('(?m)^m_EditorVersion: *' + [regex]::Escape($Version) + '\s*$')) {
        throw "Staged export project must target Unity $Version."
    }
    $manifest = Get-Content -LiteralPath (Join-Path $Project 'Packages/manifest.json') -Raw | ConvertFrom-Json
    if ($manifest.dependencies.PSObject.Properties.Name -contains 'com.wallstop-studios.unity-helpers') {
        throw 'Export must compile the staged Assets payload without a UPM package copy.'
    }
}

function Invoke-UnityPackageExport {
    param(
        [Parameter(Mandatory = $true)][string]$EditorPath,
        [Parameter(Mandatory = $true)][string]$Project,
        [Parameter(Mandatory = $true)][string]$OutputPath,
        [Parameter(Mandatory = $true)][string]$LogPath,
        [Parameter(Mandatory = $true)][string]$PackageRoot,
        [string[]]$ExtraArguments = @()
    )

    $OutputPath = [IO.Path]::GetFullPath($OutputPath)
    $hashPath = "$OutputPath.sha256"
    foreach ($stale in @($OutputPath, $hashPath)) {
        if (Test-Path -LiteralPath $stale) { Remove-Item -LiteralPath $stale -Force }
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutputPath) | Out-Null
    $exportArguments = @('-batchmode', '-nographics', '-quit', '-releaseCodeOptimization',
        '-projectPath', $Project, '-executeMethod', 'UnityHelpersPackageExporter.Export',
        '-exportOutput', $OutputPath, '-logFile', '-') + $ExtraArguments
    $exportExit = Invoke-UnityEditor -EditorPath $EditorPath -Arguments $exportArguments `
        -Label 'Export Unity package' -LogPath $LogPath -TimeoutSeconds 7200 -StallSeconds 900
    if ($exportExit -ne 0) {
        throw "Unity package export failed with exit code $exportExit. See $LogPath."
    }
    if (-not (Test-Path -LiteralPath $OutputPath -PathType Leaf) -or
        (Get-Item -LiteralPath $OutputPath).Length -le 0) {
        throw "Unity package export did not produce a fresh non-empty file: $OutputPath. See $LogPath."
    }
    Assert-NoUnityCompilerWarnings -LogPath $LogPath -Label 'Unity package export' -PackageRoot $PackageRoot
    $hash = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
    Set-Content -LiteralPath $hashPath -Value "$hash  $([IO.Path]::GetFileName($OutputPath))" -Encoding ascii
    Write-Host "Unity package exported: $OutputPath (SHA256 $hash)"
}

if ($StandaloneBuildCapture -ne 'None') {
    $captureTimeout = Get-StandaloneBuildTimeoutSeconds
    if ($captureTimeout -lt 1 -or $captureTimeout -gt 1800) { throw 'Build capture requires a timeout between one and 1800 seconds.' }
    if ($StandaloneBuildCapture -eq 'Debugger' -and [Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Debugger build capture requires Windows.' }
}

Assert-UnityRunMode -Mode $TestMode -Assemblies $AssemblyNames -Project $ProjectPath `
    -ExportPath $ExportPackagePath -Version $UnityVersion `
    -HasTestOptions:($GenerateOnly -or $IncludeComparisons -or $IncludeIntegrations -or
        $AdditionalScriptingDefines.Count -gt 0 -or -not [string]::IsNullOrWhiteSpace($TestFilter) -or
        -not [string]::IsNullOrWhiteSpace($TestCategory))

$RepoRoot = Resolve-FullPath -Path $RepoRoot
Assert-RepoRoot -Path $RepoRoot
$ArtifactsPath = Resolve-FullPath -Path $ArtifactsPath
New-Item -ItemType Directory -Force -Path $ArtifactsPath | Out-Null
$frozenPlayerDeclaration = $null
if (-not [string]::IsNullOrWhiteSpace($FrozenPlayerDeclarationPath)) {
    $frozenPlayerDeclaration = Read-FrozenPlayerDeclaration -Path $FrozenPlayerDeclarationPath `
        -Mode $TestMode -UnityVersion $UnityVersion -Backend $StandaloneScriptingBackend `
        -ArtifactsPath $ArtifactsPath -RepoRoot $RepoRoot -GenerateOnly:$GenerateOnly -BuildCaptureOnly:($StandaloneBuildCapture -ne 'None')
}
$frozenPlayerProvenance = $null

# Which MSVC toolset IL2CPP will use, written INTO THE ARTIFACT. The runner
# diagnostics step prints the same thing, but that lands in the GitHub job log,
# which is not retrievable through the REST API -- so the one place a toolchain
# question can actually be answered after the fact is the artifact, next to
# unity.log. Bee echoes the compiler command line only when a build FAILS, so
# without this a green run records nothing about what compiled it. See #374:
# MSVC 14.51.36231 ICEs at /Ox on the generated test C++.
try {
    $toolchainReport = Join-Path $ArtifactsPath 'msvc-toolchains.txt'
    $vsWhereExe = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    $toolchainLines = New-Object System.Collections.Generic.List[string]
    if (-not (Test-Path -LiteralPath $vsWhereExe)) {
        $toolchainLines.Add('vswhere.exe not found; no Visual Studio installation could be enumerated.')
    }
    else {
        foreach ($vsInstance in @(& $vsWhereExe -products * -format json | ConvertFrom-Json)) {
            $defaultVersionFile = Join-Path $vsInstance.installationPath 'VC\Auxiliary\Build\Microsoft.VCToolsVersion.default.txt'
            $defaultToolset = if (Test-Path -LiteralPath $defaultVersionFile) {
                (Get-Content -LiteralPath $defaultVersionFile -Raw).Trim()
            }
            else { '<none>' }
            $toolsRoot = Join-Path $vsInstance.installationPath 'VC\Tools\MSVC'
            $installedToolsets = if (Test-Path -LiteralPath $toolsRoot) {
                ((Get-ChildItem -LiteralPath $toolsRoot -Directory -ErrorAction SilentlyContinue |
                    Select-Object -ExpandProperty Name | Sort-Object) -join ', ')
            }
            else { '<none>' }
            $toolchainLines.Add(("{0} ({1})`n  path      = {2}`n  default   = {3}`n  installed = [{4}]" -f `
                    $vsInstance.displayName, $vsInstance.installationVersion, $vsInstance.installationPath, `
                    $defaultToolset, $installedToolsets))
        }
    }
    if ($toolchainLines.Count -eq 0) {
        $toolchainLines.Add('vswhere reported no Visual Studio installations.')
    }
    Set-Content -LiteralPath $toolchainReport -Value ($toolchainLines -join "`n") -Encoding utf8
    Write-Host "MSVC toolchains recorded to $toolchainReport"
}
catch {
    # Diagnostics that can fail a build are worse than no diagnostics.
    Write-Host "MSVC toolchain report unavailable: $($_.Exception.Message)"
}

if ($EditorPhaseGroup -ne 'All' -and ($TestMode -ne 'editmode' -or -not $IsolateCompilationFixtures)) {
    throw 'An editor phase group requires EditMode compilation isolation.'
}

$ExplicitProjectRequested = -not [string]::IsNullOrWhiteSpace($ProjectPath)
$ProjectWorkspace = Resolve-UnityProjectWorkspace `
    -RepoRoot $RepoRoot `
    -Version $UnityVersion `
    -Mode $TestMode `
    -Scope $ProjectScope `
    -ShareEditorProject:$ShareEditorProject `
    -ExplicitProjectPath $ProjectPath `
    -PersistentRoot $ProjectRoot `
    -GenerationFingerprint $(if ($TestMode -ne 'export') { Get-UnityTestFrameworkProjectFingerprint -Root $RepoRoot } else { '' })
$ProjectPath = Resolve-FullPath -Path $ProjectWorkspace.ProjectPath

Initialize-UnityCacheEnvironment -CacheRoot (Resolve-FullPath -Path $ProjectWorkspace.CacheRoot)

if ($TestMode -ne 'export' -and (-not $GenerateOnly -or -not [string]::IsNullOrWhiteSpace($LicenseSessionPath)) -and $ProjectWorkspace.Persistent) {
    Remove-LegacyUnityTestFrameworkCollector -Project $ProjectWorkspace.LegacyProjectPath -ArtifactsPath $ArtifactsPath
}

# Reclaim disk BEFORE the project directory is (re)created, so this leg's own
# project is never a prune candidate on the run that needs it.
if ($ProjectWorkspace.Persistent) {
    [void](Invoke-PersistentProjectPrune `
            -ProjectsRoot $ProjectWorkspace.PruneRoot `
            -KeepName $ProjectWorkspace.LeafName `
            -MinimumFreeGb $ProjectRootMinimumFreeGb)
}

# Release is now the repo-wide Unity CI contract. The historical switches remain
# accepted for workflow/back-compat, but the effective mode is always Release:
# editor/test compilations get -releaseCodeOptimization, and standalone generated
# players omit BuildOptions.Development.
$UseReleaseCodeOptimization = $true
$UseReleasePlayerBuild = $true

# Normalize the requested extra scripting defines to a clean, de-duplicated,
# semicolon-joined string ONCE here. The configurator C# reads this exact value
# from UH_ADDITIONAL_SCRIPTING_DEFINES; computing it up front keeps the env var,
# the diagnostic logging, and the configure-pass dispatch decision all consistent.
$AdditionalScriptingDefinesList = @(
    @($AdditionalScriptingDefines) |
        ForEach-Object { if ($null -ne $_) { ([string]$_).Trim() } } |
        Where-Object { $_ -and $_.Length -gt 0 } |
        Select-Object -Unique
)
$AdditionalScriptingDefinesJoined = ($AdditionalScriptingDefinesList -join ';')

if ($TestMode -ne 'export') {
    $retainedProject = Move-UnityProjectWithMigrationResidue -Project $ProjectPath -ExplicitProject:$ExplicitProjectRequested
    if ($null -ne $retainedProject) {
        New-Item -ItemType Directory -Force -Path $ArtifactsPath | Out-Null
        $retainedProject | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $ArtifactsPath 'retained-project.json') -Encoding UTF8
        Write-CiWarning "Retained interrupted migration project at '$($retainedProject.RetainedPath)'. Tests will use a fresh generated project."
    }
}

# Measured BEFORE the project is (re)generated: this single line is how a run
# proves the Library survived since the previous leg instead of being imported
# cold. A persistent leg that reports "cold" every run means the project root is
# not actually surviving between jobs, which is the whole point of this path.
$LibraryWarmth = if (Test-Path -LiteralPath (Join-Path $ProjectPath 'Library') -PathType Container) { 'warm (reused)' } else { 'cold (first run on this runner)' }

if ($TestMode -ne 'export') {
    $ProjectPath = Initialize-EphemeralProject -Root $RepoRoot -Version $UnityVersion -Mode $TestMode -Path $ProjectPath -IncludeComparisons:$IncludeComparisons -IncludeIntegrations:$IncludeIntegrations -Backend $StandaloneScriptingBackend -Il2CppCompilerConfiguration $Il2CppCompilerConfiguration -ManagedStrippingLevel $ManagedStrippingLevel -DevelopmentBuild:(-not $UseReleasePlayerBuild) -RequireReleaseManagedCodeVariant:($null -ne $frozenPlayerDeclaration -and $frozenPlayerDeclaration.CampaignKind -ceq 'wproto-seven-families-v1') -ScriptingDefines $AdditionalScriptingDefinesJoined -RepoRoot $RepoRoot
    $LibraryPath = Join-Path $ProjectPath 'Library'
    New-Item -ItemType Directory -Force -Path $LibraryPath | Out-Null
    Clear-StaleUnityCompilationCache -Project $ProjectPath -RepoRoot $RepoRoot -Force:$ForceFreshCompilationCache
} else {
    $LibraryPath = Join-Path $ProjectPath 'Library'
}


Write-Host "::group::Ephemeral Unity project"
Write-Host "RepoRoot: $RepoRoot"
Write-Host "ProjectPath: $ProjectPath"
Write-Host "ProjectPersistent: $($ProjectWorkspace.Persistent)"
Write-Host "LibraryPath: $LibraryPath"
Write-Host "Library: $LibraryWarmth"
Write-Host "ArtifactsPath: $ArtifactsPath"
Write-Host "IncludeComparisons: $IncludeComparisons"
Write-Host "IncludeIntegrations: $IncludeIntegrations"
Write-Host "AdditionalScriptingDefines: $AdditionalScriptingDefinesJoined"
Write-Host "StandaloneScriptingBackend: $StandaloneScriptingBackend"
Write-Host "ReleasePlayerBuild: $UseReleasePlayerBuild"
Write-Host "ReleaseCodeOptimization: $UseReleaseCodeOptimization"
Write-Host "Manifest:"
Get-Content -LiteralPath (Join-Path $ProjectPath 'Packages\manifest.json')
Write-Host "Pre-created analyzer copy (Assets/Plugins/Editor/WallstopStudios.UnityHelpers):"
$analyzerCopyDir = Join-Path $ProjectPath 'Assets\Plugins\Editor\WallstopStudios.UnityHelpers'
if (Test-Path -LiteralPath $analyzerCopyDir -PathType Container) {
    Get-ChildItem -LiteralPath $analyzerCopyDir -File |
        Select-Object -ExpandProperty Name |
        Sort-Object |
        ForEach-Object { Write-Host "  $_" }
} else {
    Write-Host "  (missing)"
}
Write-Host "::endgroup::"

if ($GenerateOnly) {
    Write-CiNotice "Generated ephemeral Unity project only: $ProjectPath"
    exit 0
}

# CI never provisions an editor here: the workflow's central ensure-unity-editor
# gate is the only editor authority, and it publishes the validated executable
# through UNITY_EDITOR_PATH. Failing closed keeps this script from silently
# installing, repairing, or quarantining editors behind an audited workflow's
# back; resolve a CI-managed editor first (locally, run the repository's
# ensure-editor helper yourself with -CiManagedOnly -RequireHealthyExisting).
if (-not $UnityEditorPath -or $UnityEditorPath.Trim().Length -eq 0) {
    throw 'UNITY_EDITOR_PATH is required and must point at an existing CI-managed Unity editor; resolve a managed editor before invoking this script.'
}

if (-not (Test-Path -LiteralPath $UnityEditorPath -PathType Leaf)) {
    throw "Unity editor not found: $UnityEditorPath"
}

# Export the resolved editor path so a workflow if:always() step (which runs in a
# SEPARATE process after this one exits) can run `Unity.exe -returnlicense` to
# return the seat as defense-in-depth.
if ($env:GITHUB_ENV) {
    Add-Content -LiteralPath $env:GITHUB_ENV -Value "UNITY_EDITOR_PATH=$UnityEditorPath"
}

# Classic SERIAL activation: the paid seat is activated from UNITY_SERIAL +
# UNITY_EMAIL + UNITY_PASSWORD. Legacy callers return inside this process;
# central-lifecycle callers leave return ownership to their immutable adjacent
# workflow action. All three credentials are required together; we test each with
# IsNullOrWhiteSpace so a blank-but-set secret counts as missing.
$hasLicenseCreds = (
    -not [string]::IsNullOrWhiteSpace($env:UNITY_SERIAL) -and
    -not [string]::IsNullOrWhiteSpace($env:UNITY_EMAIL) -and
    -not [string]::IsNullOrWhiteSpace($env:UNITY_PASSWORD)
)
$centralReturnOwnsLicense = [string]::Equals(
    $env:UH_CENTRAL_LICENSE_RETURN,
    'true',
    [System.StringComparison]::OrdinalIgnoreCase
)
# In CI all three credentials are MANDATORY: a missing one means the editor would
# launch unlicensed and fail opaquely. The error names the missing VARS (never
# their values). Locally, missing creds is fine -- we assume the machine is
# already licensed (Hub sign-in / a local .ulf) and simply skip activate/return.
if ($env:GITHUB_ACTIONS -eq 'true' -and -not $hasLicenseCreds) {
    $missing = @()
    if ([string]::IsNullOrWhiteSpace($env:UNITY_SERIAL)) { $missing += 'UNITY_SERIAL' }
    if ([string]::IsNullOrWhiteSpace($env:UNITY_EMAIL)) { $missing += 'UNITY_EMAIL' }
    if ([string]::IsNullOrWhiteSpace($env:UNITY_PASSWORD)) { $missing += 'UNITY_PASSWORD' }
    throw "Serial Unity activation requires UNITY_SERIAL, UNITY_EMAIL, and UNITY_PASSWORD in CI. Missing or empty: $($missing -join ', ')."
}

$sharedLicenseSession = $null
$reuseLicenseSession = $false
if ($PrepareLicenseOnly -and [string]::IsNullOrWhiteSpace($LicenseSessionPath)) {
    throw 'License preparation requires a shared session file.'
}
if (-not [string]::IsNullOrWhiteSpace($LicenseSessionPath)) {
    if (-not $hasLicenseCreds -or -not $centralReturnOwnsLicense) {
        throw 'Shared activation requires complete credentials and central return ownership.'
    }
    $sessionState = if ($PrepareLicenseOnly) { 'requested' } else { 'activated' }
    $sharedLicenseSession = Read-UnityLicenseSession -Path $LicenseSessionPath `
        -UnityVersion $UnityVersion -EditorPath $UnityEditorPath -State $sessionState
    $reuseLicenseSession = -not $PrepareLicenseOnly
}

# Array-wrap the capture so it is ALWAYS an array under Set-StrictMode -Version
# Latest. Get-AcceleratorArguments `return @()` on its empty path emits ZERO
# objects, so a bare `$x = Get-Foo` assigns AutomationNull (the empty array
# unwraps to nothing). Then reading `$x.Count` THROWS "property 'Count' cannot be
# found on this object" under StrictMode 2.0+ (verified on pwsh 7.6.1). @(...)
# forces Count 0 when empty so the read is safe. (The later `... + $x` concat was
# fine either way: `+` DROPS the empty/AutomationNull capture rather than adding
# it -- only a LITERAL $null operand would add a spurious element.)
$acceleratorArgs = @(Get-AcceleratorArguments -Endpoint $env:UNITY_ACCELERATOR_ENDPOINT -Version $UnityVersion -Mode $TestMode)
if ($acceleratorArgs.Count -gt 0) {
    Write-CiNotice "Unity Accelerator enabled for namespace unity-helpers-$UnityVersion-$TestMode (endpoint normalized at the script boundary; value masked)."
} else {
    Write-CiNotice "Unity Accelerator disabled; UNITY_ACCELERATOR_ENDPOINT is unset."
}

$testPlatform = switch ($TestMode) {
    'editmode' { 'EditMode' }
    'playmode' { 'PlayMode' }
    'standalone' { 'StandaloneWindows64' }
}

$filterArgs = @()
$requireFilteredPass = -not [string]::IsNullOrWhiteSpace($TestFilter)
if ($requireFilteredPass) {
    $filterArgs = @('-testFilter', $TestFilter)
    Write-CiNotice "Unity test name filter enabled: $TestFilter"
}

$categoryArgs = @()
if (-not [string]::IsNullOrWhiteSpace($TestCategory)) {
    $categoryArgs = @('-testCategory', $TestCategory)
    Write-CiNotice "Unity test category filter enabled: $TestCategory"
} else {
    Write-CiNotice "Unity test category filter disabled."
}

$resultsPath = Join-Path $ArtifactsPath 'results.xml'
$logPath = Join-Path $ArtifactsPath 'unity.log'
$configureLogPath = Join-Path $ArtifactsPath 'configure.log'
$startupProbeLogPath = Join-Path $ArtifactsPath 'unity-startup-probe.log'
# The standalone-configure SUCCESS MARKER: UhCiTestConfigurator.Apply writes it
# as its final action (path handed in via UH_CONFIGURE_MARKER_PATH). A fresh
# marker is the source of truth that the configure pass completed -- even if Unity
# then crashed in a background thread during shutdown and returned a crash exit
# code -- so we never fail a successful configure on a benign teardown crash.
$configureMarkerPath = Join-Path $ArtifactsPath 'configure-complete.marker'

# STANDALONE split-build artifacts. The built IL2CPP player goes under a stable
# per-run project Build directory, not project Temp: Unity's test player build
# pipeline can populate Temp/PlayerWithTests or copy through Temp and then clean
# it before this script's post-build assertion runs. The player still stays out
# of $ArtifactsPath because a full IL2CPP player is hundreds of MB; only the
# small player log and NUnit XML are uploaded.
$standaloneExe = Join-Path $ProjectPath 'Build\UhTestPlayer\UhTestPlayer.exe'
$playerLogPath = Join-Path $ArtifactsPath 'player.log'

# Hand the requested global scripting defines to the configurator C#
# (UhCiTestConfigurator.ApplyAdditionalScriptingDefines reads this env var). Set it
# unconditionally -- empty when none requested, in which case the configurator's
# define injection is a no-op -- so the SAME env var feeds both the standalone
# configure pass (already run for every standalone leg) and the editmode/playmode
# configure pass dispatched below. The configurator unions these onto the Standalone
# group's defines, which apply to ALL assemblies (asmdef assemblies included).
$env:UH_ADDITIONAL_SCRIPTING_DEFINES = $AdditionalScriptingDefinesJoined
if ($AdditionalScriptingDefinesList.Count -gt 0) {
    Write-CiNotice "Global scripting defines requested for asmdef compilation: $AdditionalScriptingDefinesJoined"
}

# Activation/return carry the serial/email/password in their argument arrays and
# Unity may echo account/serial fragments into the activation log, so these logs
# MUST NOT live under $ArtifactsPath (the workflow uploads that as an artifact and
# the credentials would leak). Write them to a NON-uploaded temp dir instead.
$licenseLogDir = if ($env:RUNNER_TEMP) { $env:RUNNER_TEMP } else { [System.IO.Path]::GetTempPath() }
$activateLogPath = Join-Path $licenseLogDir "unity-activate-$UnityVersion-$TestMode.log"
$returnLogPath = Join-Path $licenseLogDir "unity-return-$UnityVersion-$TestMode.log"

# Return-at-start defense: reclaim a seat that a PRIOR force-killed run on this
# persistent self-hosted runner may have leaked before its own finally or
# workflow backstop could run. This is safe for central-lifecycle callers too:
# the fresh activation below establishes the seat that the central executor will
# later return, so this pre-activation cleanup cannot consume that evidence.
if ($hasLicenseCreds -and -not $reuseLicenseSession) {
    Invoke-UnityLicenseReturn -EditorPath $UnityEditorPath -Email $env:UNITY_EMAIL -Password $env:UNITY_PASSWORD -LogPath $returnLogPath
}

try {
    if ($null -ne $frozenPlayerDeclaration) {
        $frozenPlayerProvenance = Start-FrozenPlayerProvenance -Declaration $frozenPlayerDeclaration `
            -RepoRoot $RepoRoot -PayloadRoot (Split-Path -Parent $standaloneExe)
        New-FrozenPlayerAnchor -Context $frozenPlayerProvenance -ProjectPath $ProjectPath
        Add-FrozenPlayerProvenanceSnapshot -Context $frozenPlayerProvenance -Stage 'before-configure'
    }
    Invoke-UnityNativeStartupProbe -EditorPath $UnityEditorPath -LogPath $startupProbeLogPath

    # Activate the paid seat BEFORE configure/run so the test editor launches
    # licensed. Activation THROWS on failure (caught by this try's finally, which
    # still returns the seat). Skipped locally when creds are absent (the machine
    # is assumed already licensed).
    if ($hasLicenseCreds -and -not $reuseLicenseSession) {
        Invoke-UnityLicenseActivate -EditorPath $UnityEditorPath -Serial $env:UNITY_SERIAL -Email $env:UNITY_EMAIL -Password $env:UNITY_PASSWORD -LogPath $activateLogPath
    }
    if ($PrepareLicenseOnly) {
        Complete-UnityLicenseSession -Path $LicenseSessionPath -Session $sharedLicenseSession
        return
    }


    if ($TestMode -eq 'export') {
        Invoke-UnityPackageExport -EditorPath $UnityEditorPath -Project $ProjectPath `
            -OutputPath $ExportPackagePath -LogPath $logPath -PackageRoot $RepoRoot `
            -ExtraArguments $acceleratorArgs
        return
    }

    if ($TestMode -eq 'standalone') {
        # CONFIGURE the standalone IL2CPP project (scripting backend/api/stripping,
        # Release code optimization, and any injected scripting defines). Marker-gated
        # via the shared Invoke-UnityConfigurePass.
        Invoke-UnityConfigurePass `
            -EditorPath $UnityEditorPath `
            -ProjectPath $ProjectPath `
            -MarkerPath $configureMarkerPath `
            -LogPath $configureLogPath `
            -Label 'Configure standalone IL2CPP project' `
            -FrozenContext $frozenPlayerProvenance `
            -ExtraArguments $acceleratorArgs
    } elseif ($AdditionalScriptingDefinesList.Count -gt 0) {
        # EDITMODE/PLAYMODE with extra global scripting defines (e.g. SINGLE_THREADED):
        # run the SAME configure pass FIRST so UhCiTestConfigurator.Apply persists the
        # defines onto the Standalone group and saves the project. The -runTests
        # invocation below then loads the project with the defines already in place,
        # so its first compile of the asmdef assemblies sees them (Unity does not
        # recompile mid-run in -batchmode). Without requested defines this pass is
        # skipped entirely, so the default editmode/playmode flow is unchanged (no
        # extra editor launch, byte-for-byte identical behavior).
        Invoke-UnityConfigurePass `
            -EditorPath $UnityEditorPath `
            -ProjectPath $ProjectPath `
            -MarkerPath $configureMarkerPath `
            -LogPath $configureLogPath `
            -Label "Configure $UnityVersion $TestMode scripting defines" `
            -ExtraArguments $acceleratorArgs
    }

    if ($TestMode -eq 'standalone') {
        # STANDALONE SPLIT BUILD + FILE-BASED RESULTS (zero PlayerConnection
        # dependency). The legacy `-runTests -testPlatform StandaloneWindows64` flow
        # had the built player stream NUnit results back to the editor over
        # PlayerConnection/TCP; on the self-hosted runners' multi-NIC networks the
        # player cannot reach the editor's listener (TcpProtobufClient errorcode
        # 10060) and the editor's run never completes, hanging the 120-minute step.
        # Instead we (2a) BUILD the player via the editor -- the generated
        # UhCiStandaloneBuildModifier clears AutoRunPlayer|ConnectToHost|
        # ConnectWithProfiler and IPostBuildCleanup exits the editor after the build
        # -- then (2b) RUN the built exe directly, where the generated
        # UhCiStandaloneTestCallback writes NUnit XML to -uhTestResults and quits,
        # then (2c) validate the FILE (the source of truth). Both 2a and 2b run under
        # the hard tree-kill watchdog so neither can hang to the step timeout.

        if ($null -ne $frozenPlayerProvenance) {
            Add-FrozenPlayerProvenanceSnapshot -Context $frozenPlayerProvenance -Stage 'after-configure'
        }

        # (2a) BUILD. Set UH_PLAYER_BUILD_PATH so the modifier redirects the player
        # output to a known path under the project's Build dir, then build with
        # -runTests (so PlayerLauncher's ModifyBuildOptions reflection path fires) but
        # NO -quit (the editor must reach PostBuildCleanup, which arms the exit).
        $env:UH_PLAYER_BUILD_PATH = $standaloneExe
        $standaloneBuildStartedUtc = [DateTime]::UtcNow
        $standaloneExeDir = Split-Path -Parent $standaloneExe
        if ($standaloneExeDir -and (Test-Path -LiteralPath $standaloneExeDir -PathType Container)) {
            Remove-Item -LiteralPath $standaloneExeDir -Recurse -Force
        }
        if ($standaloneExeDir) {
            New-Item -ItemType Directory -Force -Path $standaloneExeDir | Out-Null
        }
        if (Test-Path -LiteralPath $playerLogPath -PathType Leaf) {
            Remove-Item -LiteralPath $playerLogPath -Force
        }
        $buildArgs = @(
            '-batchmode',
            '-nographics',
            '-projectPath', $ProjectPath,
            '-runTests',
            '-testPlatform', 'StandaloneWindows64',
            '-testResults', $resultsPath,
            '-assemblyNames', $AssemblyNames,
            '-releaseCodeOptimization',
            '-buildTarget', 'StandaloneWindows64',
            '-logFile', '-'
        ) + $categoryArgs + $filterArgs + $acceleratorArgs

        # No -StallSeconds here (only the wall-clock backstop): IL2CPP native C++
        # compilation and linking are legitimately silent for minutes under `-logFile -`,
        # so a no-output stall guard WOULD false-fire on a healthy build. The stall guard
        # is scoped to the in-editor -runTests pass instead.
        if ($StandaloneBuildCapture -ne 'None') {
            Invoke-UnityStandaloneBuildDiagnostic -Mode $StandaloneBuildCapture -EditorPath $UnityEditorPath `
                -ProjectPath $ProjectPath -Arguments $buildArgs -ArtifactsPath $ArtifactsPath `
                -LogPath $logPath -TimeoutSeconds (Get-StandaloneBuildTimeoutSeconds) -UseStandardHeap:$StandaloneBuildDebuggerStandardHeap -AttachToDirect:$StandaloneBuildAttachToDirect -AttachAfterStartup:$StandaloneBuildAttachAfterStartup -AttachAfterShutdown:$StandaloneBuildAttachAfterShutdown
            if ($null -ne $frozenPlayerProvenance) {
                Add-FrozenPlayerProvenanceSnapshot -Context $frozenPlayerProvenance -Stage 'after-build' -IncludePayload
            }
            throw 'Evidence-only Standalone build capture stops before player launch and cannot satisfy acceptance.'
        }
        $buildObservation = @{}
        $buildResult = Invoke-UnityObservedEditor `
            -EditorPath $UnityEditorPath `
            -Arguments $buildArgs `
            -TimeoutSeconds (Get-StandaloneBuildTimeoutSeconds) `
            -LogPath $logPath `
            -Label "Build standalone IL2CPP test player (Unity $UnityVersion)" `
            -ProcessObservation $buildObservation

        if ($null -ne $frozenPlayerProvenance) {
            $frozenPlayerProvenance.BuildOutcome = $buildResult
            $frozenPlayerProvenance.BuildObservation = [pscustomobject]$buildObservation
        }

        # Validate the fresh player independently of the process outcome. Accepted output
        # does not establish the timing or cause of a native exit.
        $standaloneBuildProblem = Test-StandalonePlayerBuildOutput `
            -ExpectedExe $standaloneExe `
            -BuildStartedUtc $standaloneBuildStartedUtc `
            -RequireGameAssembly:($StandaloneScriptingBackend -eq 'IL2CPP')

        # Positive exits normally report deliberate failures. Unity can also exit
        # 255 after a complete build during post-build shutdown; accept that code
        # only with a fresh player and both durable build-success log markers.
        # The player run and NUnit results still determine the test outcome.
        if ([string]::IsNullOrWhiteSpace($standaloneBuildProblem) -and
            -not $buildResult.TimedOut -and
            -not (Test-BenignStandaloneBuildExit -ExitCode $buildResult.ExitCode -LogPath $logPath)) {
            $standaloneBuildProblem = "build exited $($buildResult.ExitCode) / $(Get-NativeExitCodeDescription -ExitCode $buildResult.ExitCode) without verified build success"
        }

        if (-not [string]::IsNullOrWhiteSpace($standaloneBuildProblem)) {
            Write-UnityRunFailureDiagnostics `
                -Project $ProjectPath `
                -LogPath $logPath `
                -CscLabel "$UnityVersion standalone build" `
                -DiagnosticsLabel "Unity $UnityVersion standalone build"
            Write-StandaloneBuildOutputDiagnostics `
                -Project $ProjectPath `
                -ExpectedExe $standaloneExe `
                -LogPath $logPath `
                -BuildStartedUtc $standaloneBuildStartedUtc
            if ($buildResult.TimedOut) {
                throw "Standalone test-player build timed out and the process tree was killed before producing a valid player at $standaloneExe ($standaloneBuildProblem). Raise the limit via UH_STANDALONE_BUILD_TIMEOUT_SECONDS (0 disables the timeout). See the build log at $logPath."
            }
            throw "Editor build produced invalid unity-helpers test player output at $standaloneExe ($standaloneBuildProblem; build exit code $($buildResult.ExitCode) / $(Get-NativeExitCodeDescription -ExitCode $buildResult.ExitCode)). The build modifier may not have run, Unity may have cleaned a Temp output, or a stale player was detected. See the build log at $logPath."
        }
        # Keep the observed exit visible when the existing artifact policy accepts the player.
        if ($buildResult.TimedOut -or $buildResult.ExitCode -ne 0) {
            Write-UnityBenignExitWarning -Label "Build standalone IL2CPP test player (Unity $UnityVersion)" -ExitCode $buildResult.ExitCode -TimedOut:$buildResult.TimedOut -LogPath $logPath
        }
        Assert-NoUnityCompilerWarnings `
            -LogPath $logPath `
            -Label "Unity $UnityVersion standalone build" `
            -PackageRoot $RepoRoot

        if ($null -ne $frozenPlayerProvenance) {
            Add-FrozenPlayerProvenanceSnapshot -Context $frozenPlayerProvenance -Stage 'after-build' -IncludePayload
        }

        # MISSED-CASE GUARD: even when the exe exists, scan the build log for the
        # signatures of a NON-redirected AutoRun build (PlayerWithTests /
        # AutoRunPlayer = True). If present, the modifier did not fully take and a
        # live run may still attempt the 10060 dial-out -- surface a ::warning::.
        if (Test-Path -LiteralPath $logPath -PathType Leaf) {
            $buildLogText = Get-Content -LiteralPath $logPath -Raw
            if ($buildLogText -match 'PlayerWithTests' -or $buildLogText -match 'options\.AutoRunPlayer = True') {
                Write-Host "::warning::Standalone build log mentions PlayerWithTests / AutoRunPlayer = True; the UhCiStandaloneBuildModifier may not have fully suppressed the player auto-run. If the player run hangs on a TcpProtobufClient 10060, verify the modifier compiled."
            }
        }

        # Delete any STALE results file before the player runs, so the
        # timeout-honors-file branch below can only honor results THIS player run
        # wrote -- never a prior run's leftover. (Defensive for local re-runs against
        # the same -ArtifactsPath; CI checkout already cleans the gitignored
        # .artifacts tree per job.)
        if (Test-Path -LiteralPath $resultsPath -PathType Leaf) {
            Remove-Item -LiteralPath $resultsPath -Force
        }

        # (2b) RUN the built exe directly (no PlayerConnection), under the watchdog.
        $playerTimeoutSeconds = Get-StandaloneTestPlayerTimeoutSeconds
        if ($null -ne $frozenPlayerProvenance) {
            Add-FrozenPlayerProvenanceSnapshot -Context $frozenPlayerProvenance -Stage 'before-launch' -IncludePayload
            $frozenPlayerProvenance.LaunchAttempted = $true
        }
        $playerResult = Invoke-StandaloneTestPlayer `
            -EditorBuiltExePath $standaloneExe `
            -ResultsPath $resultsPath `
            -LogPath $playerLogPath `
            -TimeoutSeconds $playerTimeoutSeconds

        if ($null -ne $frozenPlayerProvenance) {
            $frozenPlayerProvenance.InvocationObserved = $true
            $frozenPlayerProvenance.PlayerOutcome = $playerResult
        }

        # A watchdog timeout is fatal ONLY when the player wrote no results. If the
        # results file exists, honor it as the source of truth (Application.Quit can be
        # deferred in -batchmode -nographics IL2CPP after RunFinished already wrote the
        # file) and fall through to Test-NUnitResults; otherwise fail with the timeout.
        $playerExitForValidation = $playerResult.ExitCode
        if ($playerResult.TimedOut) {
            if (Test-Path -LiteralPath $resultsPath -PathType Leaf) {
                Write-Host "::warning::Standalone test player exceeded the ${playerTimeoutSeconds}s watchdog and was tree-killed, but it had already written $resultsPath; honoring that results file as the source of truth (Application.Quit was likely deferred in -batchmode IL2CPP). Raise UH_STANDALONE_PLAYER_TIMEOUT_SECONDS if this recurs."
                # The inline timeout warning above is the single, correctly-phrased
                # notice for this case; pass exit 0 to the validator so it does NOT
                # re-warn and MISLABEL the watchdog timeout (sentinel 124) as a
                # native shutdown crash.
                $playerExitForValidation = 0
            } else {
                throw "Standalone test player timed out after $playerTimeoutSeconds second(s) and was tree-killed before writing any results to $resultsPath. Raise the limit via UH_STANDALONE_PLAYER_TIMEOUT_SECONDS (0 disables the timeout). See the player log at $playerLogPath."
            }
        }

        # (2c) VALIDATE the FILE (the source of truth). The player log carries the
        # diagnostics for a missing/empty file (its stdout no longer flows through
        # unity.log). The player exit code is advisory only: a valid passing file
        # with a non-zero player exit gets a benign-crash ::warning::, not a failure.
        Test-NUnitResults -Path $resultsPath -Label "Unity $UnityVersion standalone" -LogPath $playerLogPath -Project $ProjectPath -UnityExitCode $playerExitForValidation -RequirePassedTests:$requireFilteredPass
        if ($null -ne $frozenPlayerProvenance) { $frozenPlayerProvenance.ResultsValidated = $true }
    } else {
        # MUST NOT include '-quit' alongside '-runTests': per the Unity Editor manual
        # (https://docs.unity3d.com/Manual/EditorCommandLineArguments.html), if the
        # Editor is running tests with -runTests, -quit causes it to QUIT IMMEDIATELY
        # before in-progress tests can complete -- the editor exits 0 having written
        # no results.xml.
        # Normal tests remain headless. The explicit capture campaign needs a real
        # device; D3D11 avoids the observed Unity 6 D3D12/native-window crash path.
        $graphicsArgs = @('-nographics')
        if ($EnableEditorGraphics) { $graphicsArgs = @('-force-d3d11') }
        $testArgs = @(
            '-batchmode'
        ) + $graphicsArgs + @(
            '-projectPath', $ProjectPath,
            '-runTests',
            '-testPlatform', $testPlatform,
            '-assemblyNames', $AssemblyNames,
            '-releaseCodeOptimization',
            '-logFile', '-'
        )
        $testArgs = $testArgs + $acceleratorArgs

        # Delete any STALE results file first so the file validation below can only
        # honor results THIS run wrote (defensive for local re-runs; CI checkout
        # already cleans the gitignored .artifacts tree per job).
        if (Test-Path -LiteralPath $resultsPath -PathType Leaf) {
            Remove-Item -LiteralPath $resultsPath -Force
        }

        # Run the editor; capture (do NOT throw on) its exit code. The NUnit
        # results.xml is the source of truth: Test-NUnitResults fails loudly on a
        # missing/invalid/failing file AND folds the exit code into its diagnostics,
        # but PASSES a valid run that exited non-zero only because Unity crashed in a
        # background thread during shutdown AFTER RunFinished wrote the file.
        $phases = @(New-UnityEditorTestPhases -ArtifactsPath $ArtifactsPath `
            -TestFilter $TestFilter -TestCategory $TestCategory `
            -IsolateCompilationFixtures:$IsolateCompilationFixtures -EditorPhaseGroup $EditorPhaseGroup)
        foreach ($phase in $phases) {
            $phaseArguments = @(New-UnityEditorPhaseArguments -Arguments $testArgs `
                -TestCategory $phase.TestCategory -TestFilter $phase.TestFilter -UnityVersion $UnityVersion)
            Invoke-UnityEditorTestPhase -EditorPath $UnityEditorPath `
                -Arguments $phaseArguments -Label "Run Unity $UnityVersion $TestMode tests" `
                -ArtifactsPath $phase.ArtifactsPath -Project $ProjectPath -PackageRoot $RepoRoot `
                -RequiredFixture $phase.RequiredFixture -RequirePassedTests:$phase.RequirePassedTests
        }
    }
    # Commit the inventory only after the selected mode produced valid passing
    # NUnit output. If import/compilation fails, the old or missing marker remains
    # and the next attempt invalidates compilation outputs again.
    Write-UnityCompilationSourceInventoryMarker -Project $ProjectPath -RepoRoot $RepoRoot
} catch {
    if ($null -ne $frozenPlayerProvenance) { $frozenPlayerProvenance.ExecutionError = $_.ToString() }
    throw
} finally {
    try {
        if ($null -ne $frozenPlayerProvenance) {
            try {
                Complete-FrozenPlayerProvenance -Context $frozenPlayerProvenance -ResultsPath $resultsPath `
                    -EvidencePaths @($resultsPath, $playerLogPath, $logPath, $configureLogPath) -PlayerLogPath $playerLogPath
            } catch {
                if ($null -eq $frozenPlayerProvenance.ExecutionError) { throw }
                Write-Warning "Frozen provenance finalization failed while preserving the original failure: $_"
            }
        }
    } finally {
        # Legacy callers return here as defense in depth. Central-lifecycle callers
        # deliberately leave the one authoritative return to the adjacent immutable
        # workflow action: a second local return consumes the seat first, making the
        # central executor observe 400006 and quarantine a successfully tested leg.
        if ($hasLicenseCreds -and -not $centralReturnOwnsLicense) {
            Invoke-UnityLicenseReturn -EditorPath $UnityEditorPath -Email $env:UNITY_EMAIL -Password $env:UNITY_PASSWORD -LogPath $returnLogPath
        }
    }
}
