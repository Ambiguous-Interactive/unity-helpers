#!/usr/bin/env node
// MIT License — Copyright (c) wallstop studios
//
// Contract tests for scripts/run-contract-tests.js.
//
// Turning `validate:tests:fast` from a serial `&&` chain into a registry buys 9 m 13 s of wall
// clock (#505, #425) and costs the one property the chain had for free: a check listed in
// package.json obviously ran. These are the assertions that replace it -- that the npm script still
// points at the runner, that every contract suite in `scripts/tests/` is reached by something, and
// that the heavy hook regressions stay out of the fast aggregate.

"use strict";

const assert = require("assert");
const { spawnSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const repoRoot = path.resolve(__dirname, "..", "..");
const runnerPath = path.join(repoRoot, "scripts", "run-contract-tests.js");
const { CHECKS, HOOK_CHECKS, checksFor, directChecksFor, runChecks } = require(runnerPath);
const repoLintChecks = require(path.join(repoRoot, "scripts", "run-repo-lint.js")).CHECKS;
const {
  expandNpmScript,
  scriptPathsIn,
  leafCommands,
  filesInvoking,
  csharpControlsInvoke,
  registeredControlsInvoke
} = require(path.join(repoRoot, "scripts", "tests", "test-run-repo-lint.js"));
const packageScripts = JSON.parse(
  fs.readFileSync(path.join(repoRoot, "package.json"), "utf8")
).scripts;

let passed = 0;
let failed = 0;
const failedTests = [];
const tests = [];

/** Queued rather than run inline, because the concurrency assertion below has to await. */
function runTest(name, fn) {
  tests.push({ name, fn });
}

async function runQueuedTests() {
  for (const test of tests) {
    try {
      await test.fn();
      console.log(`  [PASS] ${test.name}`);
      passed++;
    } catch (err) {
      console.log(`  [FAIL] ${test.name}`);
      console.log(`         ${err.message}`);
      failed++;
      failedTests.push(test.name);
    }
  }
}

runTest("every check has a unique, non-empty id and name", () => {
  const seen = new Set();
  for (const check of CHECKS) {
    assert.ok(check.id && check.id.trim(), `check has empty id: ${JSON.stringify(check)}`);
    assert.ok(check.name && check.name.trim(), `check ${check.id} has empty name`);
    assert.ok(check.run && check.run.trim(), `check ${check.id} has empty run`);
    assert.ok(!seen.has(check.id), `duplicate check id: ${check.id}`);
    seen.add(check.id);
  }
});

runTest("every check resolves to a real npm script or an existing file", () => {
  for (const check of CHECKS) {
    const npmScript = check.run.match(/^npm run ([\w:.-]+)$/);
    assert.ok(
      npmScript,
      `${check.id} must run an npm script so its definition lives in one place: ${check.run}`
    );
    assert.ok(
      packageScripts[npmScript[1]],
      `${check.id} runs npm script "${npmScript[1]}", which package.json does not define`
    );
    for (const file of scriptPathsIn(expandNpmScript(npmScript[1]))) {
      assert.ok(
        fs.existsSync(path.join(repoRoot, file)),
        `${check.id} runs a missing file: ${file}`
      );
    }
  }
});

runTest("validate:tests:fast is the runner, not a serial chain", () => {
  // The regression this prevents is the cheap one: someone adds a check by appending
  // `&& npm run test:x` to the npm script, and the registry -- which every assertion here reads --
  // silently stops describing what runs.
  assert.strictEqual(
    packageScripts["validate:tests:fast"],
    "uv run --project scripts/python~ --locked --no-dev python scripts/check_registries.py contracts --direct",
    "validate:tests:fast must delegate to the registry runner"
  );
});

runTest("the heavy hook regressions stay out of the fast aggregate", () => {
  // They synthesize whole repositories and run the hooks against them; they are minutes, not
  // seconds, and `validate:tests` opts them into its complete registry. The separate command keeps this
  // readable at a glance, so it has to be asserted now that the chain is gone.
  const heavy = [
    "test:agent-preflight",
    "test:precommit-integration",
    "test:pre-push-changed-files"
  ];
  const registered = new Set(CHECKS.map((check) => check.run));
  for (const script of heavy) {
    assert.ok(
      !registered.has(`npm run ${script}`),
      `${script} belongs in validate:tests:hook-regressions, not the fast registry`
    );
  }
  assert.strictEqual(
    packageScripts["validate:tests:hook-regressions"],
    heavy.map((script) => `npm run ${script}`).join(" && "),
    "the hook regressions must still be their own aggregate"
  );
});

runTest("the full aggregate selects exactly the fast checks and all hook regressions", () => {
  assert.strictEqual(
    packageScripts["validate:tests"],
    "uv run --project scripts/python~ --locked --no-dev python scripts/check_registries.py contracts --include-hook-regressions --direct"
  );
  assert.strictEqual(
    checksFor(false),
    CHECKS,
    "the fast registry must retain its existing order and identity"
  );
  const combined = checksFor(true);
  assert.deepStrictEqual(combined, [...HOOK_CHECKS, ...CHECKS]);
  assert.strictEqual(new Set(combined.map((check) => check.id)).size, combined.length);
  assert.strictEqual(
    HOOK_CHECKS.map((check) => check.run).join(" && "),
    packageScripts["validate:tests:hook-regressions"]
  );
  assert.deepStrictEqual(
    combined.filter((check) => check.exclusive).map((check) => check.id),
    ["npm-package-changelog"]
  );
});

runTest("the combined CLI lists the exact registry and retains selection failures", () => {
  const listed = spawnSync(process.execPath, [runnerPath, "--include-hook-regressions", "--list"], {
    cwd: repoRoot,
    encoding: "utf8"
  });
  assert.strictEqual(listed.status, 0);
  assert.deepStrictEqual(
    listed.stdout.trim().split(/\r?\n/),
    checksFor(true).map((check) => check.id)
  );
  const refused = spawnSync(
    process.execPath,
    [runnerPath, "--include-hook-regressions", "--only", "not-a-real-check"],
    { cwd: repoRoot, encoding: "utf8" }
  );
  assert.notStrictEqual(refused.status, 0);
  assert.match(refused.stdout + refused.stderr, /Unknown check id/);
});

runTest("direct mode resolves every check to its package command and keeps its scope", () => {
  for (const includeHookRegressions of [false, true]) {
    const original = checksFor(includeHookRegressions);
    const direct = directChecksFor(includeHookRegressions);
    assert.strictEqual(direct.length, original.length);
    for (let index = 0; index < original.length; index++) {
      const scriptName = original[index].run.match(/^npm run ([\w:.-]+)$/)[1];
      assert.strictEqual(direct[index].run, packageScripts[scriptName]);
      assert.strictEqual(direct[index].id, original[index].id);
      assert.strictEqual(direct[index].exclusive, original[index].exclusive);
    }
  }
  assert.deepStrictEqual(
    CHECKS.map((check) => check.run),
    checksFor(false).map((check) => check.run)
  );
});

runTest("direct mode runs a selected contract and refuses an unknown id", () => {
  const selected = spawnSync(
    process.execPath,
    [runnerPath, "--direct", "--only", "lint-comparison-direction"],
    { cwd: repoRoot, encoding: "utf8" }
  );
  assert.strictEqual(selected.status, 0, selected.stdout + selected.stderr);
  assert.match(selected.stdout, /pytest scripts\/tests\/test_comparison_direction\.py -q/);
  assert.match(selected.stdout, /\b[1-9]\d* passed\b/);
  assert.match(selected.stdout, /1\/1 checks passed/);

  const refused = spawnSync(process.execPath, [runnerPath, "--direct", "--only", "unknown"], {
    cwd: repoRoot,
    encoding: "utf8"
  });
  assert.notStrictEqual(refused.status, 0);
  assert.match(refused.stdout + refused.stderr, /Unknown check id/);
});

runTest("runChecks runs every check even after one fails", async () => {
  // The property that distinguishes a registry from `&&`, asserted rather than inferred.
  const results = await runChecks(
    [
      { id: "ok-first", name: "ok first", run: "true" },
      { ...HOOK_CHECKS[0], run: "exit 3" },
      { id: "ok-last", name: "ok last", run: "true" }
    ],
    2
  );
  assert.deepStrictEqual(
    results.map((result) => `${result.id}:${result.ok}`),
    ["ok-first:true", `${HOOK_CHECKS[0].id}:false`, "ok-last:true"],
    "a failure must not stop the checks after it, and results stay in registry order"
  );
});

runTest("an exclusive check never overlaps another", async () => {
  // The property the registry's `exclusive` flag claims, asserted by observation rather than by
  // reading the scheduler. Each check records the interval it ran in; the exclusive one must not
  // intersect any other.
  const marker = path.join(os.tmpdir(), `exclusive-probe-${process.pid}`);
  const stamp = (id) =>
    `date +%s%N | sed "s/^/${id} /" >> ${marker}; sleep 0.4; ` +
    `date +%s%N | sed "s/^/${id} /" >> ${marker}`;

  fs.rmSync(marker, { force: true });
  await runChecks(
    [
      { id: "a", name: "a", run: stamp("a") },
      { id: "solo", name: "solo", run: stamp("solo"), exclusive: true },
      { id: "b", name: "b", run: stamp("b") },
      ...HOOK_CHECKS.map((check) => ({ ...check, run: stamp(check.id) }))
    ],
    4
  );

  const spans = new Map();
  for (const line of fs.readFileSync(marker, "utf8").trim().split(/\r?\n/)) {
    const [id, at] = line.split(" ");
    const span = spans.get(id) || [];
    span.push(Number(at));
    spans.set(id, span);
  }
  fs.rmSync(marker, { force: true });

  const solo = spans.get("solo");
  assert.ok(solo && solo.length === 2, "the exclusive check must have run");
  for (const [id, span] of spans) {
    if (id === "solo") {
      continue;
    }
    const overlaps = span[0] <= solo[1] && solo[0] <= span[1];
    assert.ok(!overlaps, `${id} overlapped the exclusive check: ${span} vs ${solo}`);
  }
});

runTest("--only with an unknown id fails instead of passing vacuously", () => {
  const result = spawnSync(process.execPath, [runnerPath, "--only", "not-a-real-check"], {
    cwd: repoRoot,
    encoding: "utf8"
  });
  assert.notStrictEqual(result.status, 0, "an unknown id must fail");
  assert.ok(
    /Unknown check id/.test(result.stdout + result.stderr),
    "the failure must name the unknown id"
  );
});

runTest("--list prints every registered id", () => {
  const result = spawnSync(process.execPath, [runnerPath, "--list"], {
    cwd: repoRoot,
    encoding: "utf8"
  });
  assert.strictEqual(result.status, 0, "--list must succeed");
  assert.deepStrictEqual(
    result.stdout.trim().split(/\r?\n/).filter(Boolean).sort(),
    CHECKS.map((check) => check.id).sort(),
    "--list output must match the registry exactly"
  );
});

function reachablePowerShellSuites(initial, sources) {
  const reachable = new Set(initial);
  let expanded = true;
  while (expanded) {
    expanded = false;
    for (const [owner, source] of sources) {
      if (!reachable.has(owner)) {
        continue;
      }
      const text = source
        .split(/\r?\n/)
        .filter((line) => !/^\s*#/.test(line))
        .join("\n");
      const calls =
        /^\s*&\s+(?:\(\[Environment\]::ProcessPath\)\s+-NoProfile\s+-File\s+)?\(Join-Path\s+\$PSScriptRoot\s+['"]([A-Za-z0-9.-]+\.ps1)['"]\)\s*$/gm;
      for (const match of text.matchAll(calls)) {
        const target = path.posix.join(path.posix.dirname(owner), match[1]);
        if (sources.has(target) && !reachable.has(target)) {
          reachable.add(target);
          expanded = true;
        }
      }
    }
  }
  return reachable;
}

runTest("nested PowerShell suites require a reachable executable owner", () => {
  const owner = "scripts/tests/root.ps1";
  const child = "scripts/tests/child.ps1";
  const leaf = "scripts/tests/leaf.ps1";
  const call = "& (Join-Path $PSScriptRoot 'child.ps1')";
  const sources = new Map([
    [owner, call],
    [child, "& ([Environment]::ProcessPath) -NoProfile -File (Join-Path $PSScriptRoot 'leaf.ps1')"],
    [leaf, "& (Join-Path $PSScriptRoot 'child.ps1')"]
  ]);
  assert.deepStrictEqual([...reachablePowerShellSuites([owner], sources)], [owner, child, leaf]);
  for (const replacement of [
    "",
    `# ${call}`,
    "Write-Host 'child.ps1'",
    "(Join-Path $PSScriptRoot 'child.ps1')"
  ]) {
    const removed = new Map(sources);
    removed.set(owner, replacement);
    assert.deepStrictEqual([...reachablePowerShellSuites([owner], removed)], [owner]);
  }
  assert.deepStrictEqual([...reachablePowerShellSuites([], sources)], []);
  const removed = new Map(sources);
  removed.set(child, "");
  assert.deepStrictEqual([...reachablePowerShellSuites([owner], removed)], [owner, child]);
});

runTest("native acceptance requires its completion receipt in both invocation modes", () => {
  for (const checks of [CHECKS, directChecksFor(false), directChecksFor(true)]) {
    const check = checks.find((entry) => entry.id === "unity-acceptance-runner");
    assert.ok(check && typeof check.completionPattern === "string");
    const receipt = new RegExp(check.completionPattern, "m");
    assert.ok(
      receipt.test("184 orchestration, exact XML and raw evidence integration controls passed.\r")
    );
    assert.ok(
      !receipt.test("0 orchestration, exact XML and raw evidence integration controls passed.")
    );
    assert.ok(!receipt.test("unexpected early return"));
  }
  const source = fs.readFileSync(
    path.join(repoRoot, "scripts/tests/test-unity-acceptance.ps1"),
    "utf8"
  );
  const completion = source.indexOf(
    'Write-Host "$checks orchestration, exact XML and raw evidence integration controls passed."'
  );
  const cleanup = source.lastIndexOf("Remove-Item -LiteralPath $temporary -Recurse -Force");
  assert.ok(0 <= cleanup && cleanup < completion, "the completion receipt must follow cleanup");
});

runTest("no contract test in scripts/tests/ has been left unreachable", () => {
  // The same shape as the linter-orphan assertion in test-run-repo-lint.js, for the same reason:
  // consolidation trades a loud failure (a chain that visibly lost an entry) for a quiet one (a
  // suite that still exists and no longer runs). The excuse is a PREDICATE, not prose.
  const runElsewhere = new Map([
    ["scripts/tests/test-lint-comparison-direction.js", "comparison-controls"],
    ["scripts/tests/test-build-lock-action-input-parser.js", "policy-controls"],
    ["scripts/tests/test-check-code-fence-syntax.sh", "fence-controls"],
    ["scripts/tests/test-sync-readme-mirror.js", "readme-controls"],
    ["scripts/tests/test-lint-dependabot.ps1", "dependabot-controls"],
    ["scripts/tests/test-lint-tests.ps1", "lifecycle-controls"],
    ["scripts/tests/test-validate-lint-error-codes.ps1", "lint-code-controls"],
    ["scripts/tests/test-fixture-runspace.ps1", "lint-code-controls"],
    ["scripts/tests/test-check-eol.ps1", "eol-controls"],
    ["scripts/tests/test-extract-code-samples.ps1", "sample-controls"],
    ["scripts/tests/test-extract-doc-samples.js", "doc-sample-controls"],
    ["scripts/tests/test-lint-comment-block-form.js", "comment-controls"],
    ["scripts/tests/test-lint-drawer-multiobject.ps1", "drawer-controls"],
    ["scripts/tests/test-gitignore-docs.ps1", "gitignore-controls"],
    ["scripts/tests/test-lint-workflow-run-expression-length.ps1", "workflow-expression-controls"],
    ["scripts/tests/test-lint-concurrent-cache-fill.ps1", "cache-controls"],
    ["scripts/tests/test-lint-unity-test-modules.ps1", "module-controls"],
    ["scripts/tests/test-lint-duplicate-usings.ps1", "duplicate-using-controls"],
    ["scripts/tests/test-lint-odin-undo-safety.ps1", "csharp-controls"],
    ["scripts/tests/test-lint-unity-file-naming.ps1", "naming-controls"],
    ["scripts/tests/test-lint-skill-sizes.ps1", "size-controls"],
    ["scripts/tests/test-llm-instructions-lint.ps1", "workflow"],
    ["scripts/tests/test-protobuf-candidate.py", "workflow"],
    ["scripts/tests/test_pr_feedback.py", "workflow"],
    ["scripts/tests/test_meta_lint.py", "workflow"],
    ["scripts/tests/test_markdown_checks.py", "workflow"],
    ["scripts/tests/test_runner_maintenance_matrix.py", "workflow"],
    ["scripts/tests/test_verify_shipped_analyzers.py", "workflow"],
    ["scripts/tests/test-reference-upstream-drift.js", "reference-controls"],
    ["scripts/tests/test-sync-issue-template-versions.ps1", "workflow"]
  ]);
  const owners = new Map([
    [
      "comparison-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_comparison_direction.py")
    ],
    [
      "policy-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_build_lock_inputs.py")
    ],
    [
      "fence-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_code_fence_syntax.py")
    ],
    [
      "reference-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_reference_upstream_drift.py")
    ],
    [
      "readme-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_readme_mirror.py")
    ],
    [
      "lifecycle-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_lifecycle_lint.py")
    ],
    [
      "dependabot-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_dependabot.py")
    ],
    [
      "comment-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_comment_block_form.py")
    ],
    [
      "lint-code-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_lint_error_codes.py")
    ],
    ["eol-controls", (file) => registeredControlsInvoke(file, "scripts/tests/test_check_eol.py")],
    [
      "doc-sample-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_doc_samples.py")
    ],
    [
      "sample-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_code_samples.py")
    ],
    [
      "size-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_skill_sizes.py")
    ],
    [
      "drawer-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_drawer_multiobject.py")
    ],
    [
      "gitignore-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_gitignore_docs.py")
    ],
    [
      "workflow-expression-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_workflow_expression_length.py")
    ],
    [
      "cache-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_concurrent_cache_fill.py")
    ],
    [
      "module-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_unity_test_modules.py")
    ],
    [
      "duplicate-using-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_duplicate_usings.py")
    ],
    ["csharp-controls", csharpControlsInvoke],
    [
      "naming-controls",
      (file) => registeredControlsInvoke(file, "scripts/tests/test_unity_file_naming.py")
    ],
    ["workflow", (file) => filesInvoking(".github/workflows", file).length > 0]
  ]);

  const directlyReachable = new Set([
    ...scriptPathsIn(leafCommands(CHECKS)),
    ...scriptPathsIn(leafCommands(repoLintChecks)),
    ...scriptPathsIn(expandNpmScript("validate:tests:hook-regressions")),
    ...scriptPathsIn(expandNpmScript("validate:local")),
    ...scriptPathsIn(expandNpmScript("typecheck:unity"))
  ]);

  const suites = fs
    .readdirSync(path.join(repoRoot, "scripts", "tests"))
    .filter((name) => /^test[-_].*\.(?:ps1|sh|js|mjs|py)$/.test(name))
    .map((name) => `scripts/tests/${name}`)
    .sort();

  const sources = new Map(
    suites
      .filter((file) => file.endsWith(".ps1"))
      .map((file) => [file, fs.readFileSync(path.join(repoRoot, file), "utf8")])
  );
  const reachable = reachablePowerShellSuites(directlyReachable, sources);

  const orphans = suites.filter((file) => !reachable.has(file) && !runElsewhere.has(file));
  assert.deepStrictEqual(
    orphans,
    [],
    `these contract tests exist but nothing runs them -- add them to CHECKS in ` +
      `scripts/run-contract-tests.js, or to runElsewhere here with the kind of owner that does: ` +
      `${orphans.join(", ")}`
  );

  const stale = [...runElsewhere.keys()].filter(
    (file) => !fs.existsSync(path.join(repoRoot, file))
  );
  assert.deepStrictEqual(
    stale,
    [],
    `allowlist names files that no longer exist: ${stale.join(", ")}`
  );

  const unfounded = [...runElsewhere.entries()]
    .filter(([file, kind]) => {
      const owner = owners.get(kind);
      return !owner || !owner(file);
    })
    .map(([file, kind]) => `${file} (claimed: ${kind})`);
  assert.deepStrictEqual(
    unfounded,
    [],
    `these contract tests are excused by an owner that does not run them: ${unfounded.join(", ")}`
  );
});

if (require.main === module) {
  console.log("Testing scripts/run-contract-tests.js...\n");

  runQueuedTests().then(() => {
    console.log(`\n${passed} passed, ${failed} failed`);
    if (failed > 0) {
      console.log(`Failed: ${failedTests.join(", ")}`);
      process.exit(1);
    }
    process.exit(0);
  });
}
