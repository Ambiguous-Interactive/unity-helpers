# Contributing

Thanks for helping make Unity Helpers better! This project uses a few automated checks and formatters to keep the codebase consistent and easy to review.

This guide is for changing Unity Helpers itself. To add the package to your game, use
[Getting Started](../overview/getting-started.md). The tools and runner access below are for
repository development.

## Development and maintainer guides

Choose the setup you need:

- [Unity container licensing](../guides/unity-devcontainer-licensing.md) for local container tests.
- [MCP local setup](../guides/mcp-local-setup.md) for repository coding-tool connections.
- [AI model backends](../guides/ai-model-backends.md) for optional development launchers.
- [MCP ecosystem notes](../guides/mcp-ecosystem.md) for the shared tool catalog's design.

## Dev Container Setup (Recommended)

The easiest way to contribute is using the included dev container, which has all CI/CD tools pre-installed:

1. Open in VS Code with the Dev Containers extension
2. Click "Reopen in Container" when prompted
3. Run `npm run verify:tools` to confirm all tools are available

Run `bash scripts/validate-devcontainer-urls.sh` to check the Dockerfile's download URLs.
If HEAD probes fail, the validator confirms reachability with a GET limited to one byte.
This fallback requires [curl 8.4.0 or newer](https://curl.se/docs/manpage.html#--max-filesize);
older or unrecognized versions retain the failed HEAD result.
A successful 200 or 206 response also permits curl's size-limit stop when a server ignores the range.
Missing resources, HTTP errors, and other transfer failures still fail validation.
Run `npm run test:validate-devcontainer-urls` for the offline HTTP and parser controls.

Use `npm run eol:fix` to normalize supported tracked text files through locked uv.
The allowlist in `scripts/check_eol.py` controls selection. The fixer skips `.py` and `.js` files. The PowerShell
launcher still accepts `-Paths`, `-DryRun`, and `-ModifiedPathList` for scoped repairs. A dry
run returns 2 when changes are needed and can write a NUL-delimited list of affected paths.
Preflight uses that list to check for unstaged changes before editing. The fixer refuses
files and links outside the checkout, hard-linked files, and invalid text that would need rewriting.
Internal symbolic links use the target's path and line-ending policy in the repair plan.

### Fast C# Feedback

Use fixture-scoped builds while editing runtime or Editor tests. The npm command runs the
locked Python tool through uv and uses the installed .NET SDK:

```bash
npm run typecheck:iterate -- tests --server --files Tests/Runtime/Serialization/WProtoEnumFormatterTests.cs
npm run typecheck:iterate -- editor-tests --server --files Tests/Editor/Tools/OdinMigration/OdinMigrationLiveDictionaryTests.cs
```

Add dependent fixtures to the same `--files` list. Production code, shared test support, test types,
and test doubles remain included. Each scope accepts files only from its corresponding test tree.
These commands retain source generators and compiler errors but omit performance analyzers.
Run the normal applicable typecheck commands and changed-file preflight before publishing.

The analyzer placement check evaluates MSBuild compiler inputs for each owned .NET project with
both protobuf oracle settings. Each shipped analyzer must appear exactly once at its package
path. Normal assembly references, including the compiler compatibility test reference, do not
count as compiler inputs. Run it with `node scripts/tests/test-analyzer-placement.js`.

The WProto compatibility inventory checks referenced enum values independently of source file
order. Its regression compiles both declaration orders and requires the same inventory, including
the enum underlying type and constants. Preserve the frozen inventory when fixing its collector.

### Test runtime reports

Use the typed NUnit timing reporter to rank slow fixtures and cases:

```bash
uv run --project scripts/python~ --locked --no-dev python scripts/unity/report_slow_tests.py --results-path results.xml --top 30 --fixture-budget-seconds 120 --step-summary
```

Add `--fail-over-budget` to enforce the fixture budget; otherwise overruns produce warnings.
The budget covers every fixture, including those outside `--top`. Names use ordinal tie ordering.
Malformed, negative or nonfinite durations and results without fixtures or cases fail the command;
missing durations on skipped tests count as zero. A step summary appends UTF-8 Markdown when
`GITHUB_STEP_SUMMARY` is set. The existing PowerShell command retains its parameter names.

`AssetPostprocessorContractTests` caches compiled method-signature expressions while retaining
its complete source scan and eight case identities. On Windows x64 Unity 6000.6.7f1 Editor Mono,
three alternating process pairs reduced median fixture duration from 7.81 to 5.82 seconds.
Paired candidate/baseline ratios ranged from 0.589 to 0.903; all six processes passed eight cases,
exited zero and reached both stream ends. These are fixture timings, not the whole EditMode suite
or editor startup. The [source variants, NUnit results and receipts](../performance/editor-contract-regex.zip)
make the scoped comparison reproducible.

### Pure EditMode fixtures

Keep pure string and value tests in fixtures without asset setup. The singleton path tests now
retain all 30 input/expected-value cases in a plain fixture, while the 13 asset integration cases
keep their existing setup and cleanup. Three alternating fresh Unity 6000.6.7f1 process pairs pass
all 43 cases with equal canonical case inventories. The moved cases take a median 1.368 seconds
before and 0.002 after. The whole cohort medians are 10.557 and 8.667 seconds, with one slower
candidate pair. This does not establish full-suite or CI timing. The
[replay capture](../performance/editmode-path-fixtures.zip) retains source variants, all six NUnit
results, process receipts, source hashes and the complete case inventory.

### Typed Python scripts

`npm run lint:comparison-direction` and its `:fix` variant run the typed Python comparison
checker. The Node entry points remain compatibility launchers. The port retains token handling
for generics, shifts, patterns, strings and interpolation holes, along with the existing cautious
rewrite rules. `npm run test:lint-comparison-direction` replays 56 frozen original findings and
rewrites and exercises CLI failures, source ownership, build-output exclusions and line endings.
The original 41 controls passed before capture. Reports retain UTF-16 columns and physical line
numbers; rewrites preserve CRLF bytes. These observations establish parity for the retained corpus,
not a complete C# parser or permission to reorder arbitrary property getters.

A local full-tree comparison over the same 2915 files used three alternating pairs. Median
process times were 7.001 seconds for the original Node checker and 10.014 seconds for Python.
The port is slower in all three pairs; this change establishes typed tooling and retained behavior,
not a startup-speed improvement. The [replay data](../performance/local-pool-runtime-qualification.zip)
retains the commands, source hashes, coverage validation and all six observations.

Documentation links run through `scripts/lint_doc_links.py` in locked uv. The `doc-links`
and `doc-links-test` Repo Lint subjects and both npm link commands use Python directly. The Node
and PowerShell commands remain compatibility entry points. `--mode Targets` checks local file and directory targets;
`--mode Format` checks Markdown style; `All` does both. `--paths` accepts literal repository paths
and refuses missing or external sources. Empty supported-source scans fail. Git inventories use NUL delimiters, preserve exact case,
and include untracked files while respecting ignore rules. Targets must exist inside the repository.
Angle-bracket targets preserve spaces; URL-encoded paths are decoded before resolution.

The frozen `scripts/tests/fixtures/doc-links-v1.json` replays 41 actual invocations of the original
checker after its complete 51-assertion suite passed. Additional Python controls cover source
masking, shell heredocs, JavaScript regex literals, lexical case, missing indexed files, links
outside the repository, and actual compatibility launches from another working directory.
Markdown targets resolve from their document directory; source references retain repository-root
fallback. Reference definitions keep target validation without prose-only style errors. Fences
track their marker and length. Python docstrings are identified by syntax, while assigned and
returned multiline strings remain visible. Source references do not truncate longer extensions
such as `.mdx` to `.md`.

The checker retains the earlier inline-link grammar limitation for parentheses inside targets.
The [replay capture](../performance/doc-link-checker-port.zip) retains the original corpus, source
identities, native Windows results and six suite timing observations. The expanded 90-case suite
takes about eight seconds locally, as did the original 51-assertion suite; no consistent suite
speedup is established.

```bash
uv run --project scripts/python~ --locked pytest scripts/tests/test_doc_links.py -q
```

`npm run lint:tests` runs the typed Python test-lifecycle checker. The PowerShell lint and test
commands remain compatibility entry points. Explicit `--paths` are literal files; absent,
linked or unreadable inputs fail. Full scans require a nonempty `Tests` tree and exclude Unity's
hidden consumer folders. Null-assertion repair validates the full input batch before writing,
preserves encoding and line endings, and refuses writable hard links. Comments and string literals
are neither repaired nor treated as test code. Calls left for manual repair retain inline suppressions.
Editor-reference guards must exclude player builds even
when another symbol is enabled; merely mentioning `UNITY_EDITOR` in an OR condition is insufficient.

The regression corpus in `scripts/tests/fixtures/test-lifecycle-v1.json` records 144 actual
invocations of the previous linter at `a86ec34b`, including diagnostics and repaired contents.
The original PowerShell suite passed all 157 assertions before the port. The Python suite replays
those captures and adds input, scanner, repair and compatibility-launcher controls:

```bash
uv run --project scripts/python~ --locked pytest scripts/tests/test_lifecycle_lint.py -q
```

At commit `87fc1cd1`, three alternating fresh-process pairs over the same 1,785 C# files retained identical
75 path/line/code diagnostics. Median complete-command time fell from 26.05 to 9.25 seconds
on this Linux host. This includes process launch and the full scan; it does not predict CI timing.
The [timing captures and replay sources](../performance/lifecycle-checker-port.zip) retain the
unchanged source inventory, all six observations and tool identities. The timing data applies to that version. Later fixes to assertion repair and category detection
have separate correctness coverage.

Documentation counts use `scripts/doc_counts.py` through locked uv. `npm run lint:doc-counts`
checks without writing; `npm run sync:doc-counts` updates only the documented target files.
Counts ignore C# comments and literal contents. Linked target files and parent directories are rejected.
For metadata JSON, run `uv run --project scripts/python~ --locked --no-dev python scripts/doc_counts.py generate`.
The three PowerShell commands remain compatibility entry points. Run `npm run test:lint-doc-counts`
for count, encoding, newline, read-only, and wrapper exit-code controls.

`npm run eol:check` runs the typed Python line-ending checker. It checks worktree line endings
and UTF-8 BOMs, plus committed text blobs whose CR bytes would make fresh clones appear dirty.
Use `-- --paths <path> <path>` for literal file scopes. Missing selected text files, linked inputs,
and failed Git reads fail explicitly. A full scan requires nonempty tracked text input.
`npm run test:check-eol` runs the Git-blob, worktree, path-scope and compatibility-launcher controls.
The two PowerShell entry points remain available for existing hooks and callers.

`npm run validate:lint-error-codes` harvests error-code prefixes from lint scripts, their controls,
and Git hooks, including typed Python names. It sends one batch through the repository's actual
cspell configuration and prints source locations plus a root-word patch for rejected families.
`npm run test:validate-lint-error-codes` also runs the retained PowerShell runspace controls, which
continue to protect the fixture host while other PowerShell suites still use it.

`npm run lint:code-samples` runs the typed Python documentation sample extractor. Its report
keeps each C# fence's actual opening line across LF, CRLF, and CR input.
The CommonMark parser handles matching backtick/tilde markers, blockquotes and nested lists.
Source maps retain the opening line; extracted code omits the Markdown container prefixes.
The sample commands select the documentation dependency group; metadata-only tools keep an empty base environment.
The default scan uses Git's tracked and nonignored file inventory, so local evidence and dependency directories do not
extend the walk. `CODE_SAMPLES_ROOT` or `--scan-root` selects an explicit fixture tree instead.
The Node launcher and PowerShell test launcher remain compatible entry points.

`npm run test:extract-code-samples` covers classification, source locations, generated files,
name collisions, empty inputs, path ownership, and both launchers. The extractor retains the
existing JSON report fields. Corrected source lines can change generated filenames.
Source paths on another Windows volume remain absolute in reports and generated identities.
Complete struct and interface examples remain at type scope when compilation units are generated.
Generation is a heuristic convenience; the standalone documentation compiler checks remain the
separate compilation gate.

Release payload staging, archive creation, and Unity metadata generation run through uv. Install uv 0.13.7, then use:

```bash
python -m pip install --disable-pip-version-check uv==0.13.7
uv sync --project scripts/python~ --locked
npm run lint:python
npm run test:create-unitypackage
npm run test:asmdef
npm run test:protobuf-candidate
npm run test:native-debugger-download
npm run test:meta-generation
npm run test:fixture-assets
npm run test:frozen-files
npm run meta:generate -- Runtime/Example.cs
uv run --project scripts/python~ --locked --no-dev python scripts/unity/create_unitypackage.py --output .artifacts/release/local.unitypackage
uv run --project scripts/python~ --locked --no-dev python scripts/unity/stage_unitypackage.py --project-dir .artifacts/unity/local-export
```

`lint:repo`, `validate:local`, `validate:tests:fast`, `validate:tests:hook-regressions`, and
`test:agent-preflight` require uv, including the metadata parity check. Outside the devcontainer,
run the bootstrap and locked sync above before these developer entry points.

Image fixture generators use the locked `fixtures` dependency group. They keep existing `.meta`
files byte for byte, including asset GUIDs and sprite IDs. Missing metadata is created once;
competing creators preserve the first file. Pixel output remains the same on repeated runs.
New metadata is published with a hard link after its temporary file closes. Unsupported filesystems
report an error and leave the destination absent; failed writes do not leave a partial metadata file.
Use `--output-dir` to generate an isolated fixture set:

```bash
uv run --project scripts/python~ --locked --no-dev --group fixtures python scripts/generate-test-sprites.py --output-dir .artifacts/sprites
uv run --project scripts/python~ --locked --no-dev --group fixtures python scripts/generate-test-textures.py --extended --output-dir .artifacts/textures
```

Repository lint and contract execution share `scripts/check_runner.py`. Existing Node entry points
retain their importable interfaces and delegate process execution, concurrency, selection, and
reporting to the locked Python environment. Exclusive checks finish before concurrent checks start;
failed checks do not prevent the remaining checks from running. Windows uses the Bash executable
from its Git for Windows installation. `npm run test:check-runner`
exercises these contracts, including an interrupted child that exits zero.
Linux checks receive separate temporary cache roots to isolate PowerShell startup profiles.
The runner preserves the existing uv cache directory and removes each temporary root after its
child exits, including failed checks. This prevents concurrent suites from sharing the startup
profile implicated in PowerShell issue 26528.
[Upstream issue](https://github.com/PowerShell/PowerShell/issues/26528)

A check can declare a `completionPattern` when exit status alone is insufficient. The native
acceptance self-test requires its final completion line after cleanup as well as exit zero.
Missing completion evidence fails the aggregate and preserves the captured output; it cannot count
as a passing suite. This requirement does not imply that other checks have completion receipts.

The WProto player and host source censuses use `scripts/unity/frozen_files.py` through locked uv. The PowerShell
library entry points retain their names and result properties. Census walks include untracked and
hidden inputs, prune only generated compiler output, and bind the Python project and lock alongside
the source files. The host census also binds its Python implementation and requires the actual Git
repository root. Spaces in Git root directory names are preserved.
Each variant retains its own selection rules: the host scans every physical file
in its four source trees, while the player filters compiler sources and also scans Unity scripts.
The scans reject redirects and missing roots. They compare file identity, size and timestamps
before opening, after reading and through the final path, refusing observed changes. Windows
hashing permits concurrent readers while excluding writers and deletion until its handle closes.
On other platforms, metadata checks cannot detect a rewrite that preserves every observed value.
Keep source inputs unchanged throughout a capture on every platform.
Every request reads the current bytes. A PowerShell process reuses one locked Python worker for
source scans. It checks the implementation, project and lock hashes before and after each request;
changes restart the worker or refuse the capture. Protocol, request and process identities must
match. The worker exits when its owner's input closes, or callers can explicitly call
`Stop-WProtoSourceCensusWorker`. Small player inventories retain
their existing implementation to avoid process startup overhead. Run `npm run test:frozen-files`
for the focused controls.

The devcontainer runs the locked sync during creation. Python 3.11.8 or newer
is required; uv can provision a compatible interpreter. The environment lives under
`scripts/python~/.venv`, separate from the documentation environment. Unity ignores that tooling
folder. The release CLI still accepts `--output`; staging still accepts `--project-dir` and
`UNITY_VERSION`, with the same safe scratch-directory restrictions. Invalid framework and module policies fail
before an existing export project is removed. Archive checksums support UTF-8 output filenames.

All repository Python sources now belong to the strict scope, including the standard-library-only
agent-state tool that runs before uv is available during container startup. The source registry
also covers Python stubs. The bounded-random proof uses the locked `proof` group and a narrow
stub for the public Z3 API it uses. Z3 comparisons return symbolic formulas; their stub return
types state that behavior explicitly. Production arithmetic is parsed with a closed Python AST
grammar rather than evaluated as Python code.

The production test-hook naming gate also runs in Python. It checks identifiers and explicit
markers in production source, plus literal and concatenated C# emitted by generators. It is a
naming check, not a semantic C# parser: references inside interpolation expressions remain outside
its scope. Existing Node commands and imports remain compatibility entry points; import the Python
helpers for content tests that make many calls.

The MIT-header and conditional-call checks also run in typed Python. Use
`npm run lint:license-headers` and `npm run lint:conditional-call-chains`; the PowerShell entry points
forward existing calls. Both checks require their source roots and a nonempty corpus, avoid linked
or generated directories, and fail on unreadable input. Body checks require UTF-8; header checks also retain BOM-marked UTF-16 and UTF-32 support. Header reads stop after 20 lines and use at most eight concurrent readers; findings keep a fixed order.
The conditional check masks comments and string literals, includes same-line bodies and generic
calls, and rejects methods whose bodies cannot be inspected. It remains a source check by method
name, with explicit external receivers; it does not replace C# semantic analysis.
The Odin Undo check shares that lexer and keeps its PowerShell path selectors. Missing inputs fail;
an unrelated nearby null check cannot excuse an unsafe array cast. Suppressions must be comments,
not string literals. Its remaining nearby-filter recognition is a source heuristic, not proof that
every Undo target is valid. `npm run lint:odin-undo-safety` checks drawers and
`npm run test:odin-undo-safety` runs its focused tests.
Run `npm run test:csharp-lints` for discovery, parser and direct/PowerShell CLI controls.

Multiline ordinary comment checks use typed Python through `npm run lint:comment-block-form`.
The PowerShell entry point retains explicit paths, fixture roots, and `-Fix`; its JavaScript test
entry point forwards to the same Python tests. Both use the shared C# scanner to distinguish
comments from literals and XML documentation. Conversion preserves newline style and any existing
UTF-8 BOM, and refuses runs containing comment delimiters. Full scans require a nonempty corpus in every owned root;
missing or unreadable explicit inputs fail before any file is rewritten. Git discovery includes
untracked sources and excludes ignored files and unstaged deletions. Discovered dangling links
still fail validation. Run `npm run test:lint-comment-block-form` for the
focused controls.

Region checks run as typed Python through the `no-regions` Repo Lint subject. The
PowerShell entry point forwards `-VerboseOutput`, `-Fix`, `-Paths` and `-StagedOnly`.
The shared C# scanner keeps directive-like text in multiline strings and comments
intact. Repair preserves other bytes, UTF-8 BOMs and line endings. Full scans cover
Runtime, Editor, Tests and Generator sources through Git's tracked and unignored
inventory. Git-discovered filenames stay literal, including Unix backslashes.
Staged checks read index blobs; repair is a worktree operation, so fix
explicit paths and stage reviewed changes separately. CI never applies repairs.
Run `uv run --project scripts/python~ --locked pytest scripts/tests/test_no_regions.py -q`
for parser, index, path and launcher controls.

The concurrent-cache checker also runs in typed Python through `npm run lint:concurrent-cache-fill`.
It requires Runtime, Editor and Styles source roots, ignores comments and literal text, and preserves
explicit overwrite reasons. Only a plain `SINGLE_THREADED` guard exempts writes; compound conditions
remain checked because another symbol may enable that branch in a concurrent build. Use
`npm run test:lint-concurrent-cache-fill` for the original fixtures, parser boundaries and both CLI routes.
The PowerShell entry points remain compatibility launchers.

YAML validation uses the same locked Python project through `npm run lint:yaml`.
The PowerShell command remains a compatibility launcher with multiple-path support.
The `metadata` dependency group installs yamllint. The runner checks tracked and untracked,
nonignored YAML files without walking ignored build trees. Missing explicit inputs and invalid
configuration fail visibly. `--staged-only` reads Git index blobs, so unstaged edits cannot hide
invalid staged YAML. Warnings remain nonblocking. Run the `yaml-controls` contract check for
source-discovery, staged-content, parser and launcher coverage.

Dependabot structure checks also use typed Python and the `metadata` group. Run
`npm run lint:dependabot` and `npm run test:lint-dependabot`. The checker accepts
multi-ecosystem groups with inherited schedules, YAML aliases and merges, and
mapping keys in any order. Ordinary dependency groups may select dependency or
update types without a `patterns` field. Duplicate keys, cyclic aliases, missing
inputs and malformed shapes fail visibly. GitHub's
[options reference](https://docs.github.com/en/code-security/reference/supply-chain-security/dependabot-options-reference)
defines the ecosystem-specific options beyond these structural checks.

The lockfile pins Ruff, mypy, Pyright, pytest, and their dependencies. `lint:python` checks Ruff
formatting and correctness rules plus both type checkers in strict mode. Function signatures must
be fully annotated and explicit `Any` is forbidden. CI runs these checks on Linux and Windows,
along with the package tests.

Local MkDocs builds and Pages deployment write `.artifacts/site/`. The dot directory keeps copied
Unity metadata outside asset import scope. Use the default destination for local checks; building
into a visible package folder can duplicate GUIDs when Unity imports the copied `.meta` files.

The existing `scripts/generate-meta.sh` entry point delegates to Python and retains `--force`,
CRLF metadata, and importer defaults. Use `npm run meta:generate -- <path>` or invoke
`scripts/generate_meta.py` through uv for a shell-independent entry point. Existing metadata is
refused unless `--force` is explicit; a competing creation also preserves the first file. Runtime
commands use `--no-dev`, so they do not install analysis or test packages into a fresh environment.
They retain tools already installed in a shared warm environment; compatible Python may still need
to be provisioned on the first run.

The documentation identifier, runtime attribute-preservation, and spelling-bucket tools also use
the locked Python environment. Their npm commands invoke Python directly; the old Node and
PowerShell paths remain compatibility launchers. The preservation gate includes generic reflection
calls such as `GetCustomAttribute<PoolPurgePolicyAttribute>()`. Spelling fixes retain the first
spelling of each word and the file's line endings; word insertion refuses cross-bucket duplicates
before writing. Fixes leave path-only dictionaries and absent word lists unchanged.
Use `--config <path>` when checking or updating a separate spelling configuration.
Set `PRESERVE_ATTRIBUTES_ROOT` to check a separate runtime source tree. Diagnostics use absolute
paths when that tree is on a different Windows drive from the repository.
These command-line tools write UTF-8 diagnostics even when Windows pipes use a legacy encoding.

```bash
npm run lint:doc-identifiers
npm run lint:preserve-attributes
npm run lint:spelling:config
npm run lint:spelling:add -- tech-terms ExampleWord
uv run --project scripts/python~ --locked pytest scripts/tests/test_doc_identifiers.py scripts/tests/test_preserve_attributes.py scripts/tests/test_cspell_tools.py
```

`npm run pr:feedback -- <number>` uses the locked Python environment to read all four
PR feedback surfaces and audit author identities. The shell entry point remains available;
`uv run --project scripts/python~ --locked --no-dev python scripts/pr_feedback.py <number>`
also works directly. Run its offline controls with `--self-test`, or its full regression
suite with `uv run --project scripts/python~ --locked pytest scripts/tests/test_pr_feedback.py`.
CodeRabbit is trusted only when its exact login belongs to a Bot account. Unknown bots
and outside people still require issue-specific direction before action.
HTTP redirects fail closed to keep credentials on the GitHub API origin.

`npm run verify:shipped-analyzers` compares all three committed compiler-input DLLs
with isolated Release builds through the same locked environment. Add `:fix` to refresh
stale or missing payloads. A failed copy or replacement preserves the previous DLL and
its importer metadata. The Node entry points remain compatibility launchers.

`npm run lint:repo -- --only meta-files` checks tracked asset coverage and C# importer shapes through typed Python.
The PowerShell and shell test commands remain compatibility launchers. C# companions require
one valid `fileFormatVersion: 2`, one 32-digit hexadecimal GUID, and a nonempty `MonoImporter`
mapping with valid YAML syntax and distinct setting keys. Changed-path preflight checks metadata-only edits and validates
both the working copy and any indexed companion. Validation reads at most 1 MiB
per C# companion and never rewrites existing bytes or index entries. Keep customized references,
execution order, and other importer settings; repair a stub by retaining its headers and adding
the generated importer block. Samples retain their companions when imported into Assets;
Unity-ignored tooling folders remain excluded.
Metadata checks select the `metadata` dependency group; generation uses only Python's standard library.

The three standalone Markdown checkers under `.github/scripts` also join strict validation.
Invoke them through the locked environment, for example:

```bash
uv run --project scripts/python~ --locked --no-dev python .github/scripts/validate_markdown_links.py docs
uv run --project scripts/python~ --locked pytest scripts/tests/test_meta_lint.py scripts/tests/test_markdown_checks.py
```

They retain their link policies and diagnostics. Missing inputs, empty source scans, and
unreadable Markdown now fail rather than reporting an unchecked pass. These standalone checks
remain separate from the repository's normal documentation lint commands.

Wiki generation and its test suite use the same locked Python project. The deployment and
validation workflows provision uv before running these commands. Link text, code blocks, page
names, sidebars, and footer output retain their existing contracts.

```bash
uv run --project scripts/python~ --locked pytest scripts/wiki/test_wiki_scripts.py -v
uv run --project scripts/python~ --locked --no-dev python scripts/wiki/prepare_wiki.py --source . --dest /tmp/test-wiki --verbose
npm run test:wiki-generation
```

New Python files must join the strict `tool.pyright.include` list in
`scripts/python~/pyproject.toml`; a Git-backed inventory rejects unregistered files. The explicit
legacy list records existing Python scripts still awaiting migration. Remove an entry when its
script joins strict validation; do not add new scripts to that backlog.

Assembly-definition and bundled-BCL validation, the protobuf candidate builder and verifier, and
the native-debugger downloader also use this locked environment. The PowerShell assembly-check
entry points remain compatibility launchers; npm calls Python directly. The assembly check rejects
missing source roots, empty assembly scans, invalid references and version expressions, and
package defines used without a declaration in the owning assembly. File fixtures cover nested
assemblies, optional package guards, case-insensitive cache exclusions, and hidden files. Unreadable
C# files report their relative paths without hiding later ownership errors. JSON input is validated
before using its typed values. CI runs these assembly fixtures on Linux and Windows; the Windows
job exercises real hidden attributes on both files and directories.

`npm run test:protobuf-candidate` exercises real child-process exit, timeout, descendant cleanup,
source inventory and shipped-byte checks. `npm run test:native-debugger-download` serves a local
nested archive to check bounded range requests, hashes, sizes and destination paths. These tests
do not download or execute a debugger, rebuild shipped binaries, or qualify Unity player behavior.
Native fault capture requires `uv` on the Windows host for its locked downloader command; it keeps
the existing process watchdog and retained download receipt.

The package tests check archive headers, GUIDs, checksums, repeated output, failure preservation,
CLI errors, policy validation, and the real npm payload. They also inject type, lint, and formatting
defects to prove each gate rejects them. Port remaining scripts incrementally while keeping their
CLI contracts and executable controls.

### Marked Documentation Compiler Samples

`npm run lint:doc-samples` extracts marked C# fences through the locked Python toolchain and
compiles both runtime and Editor corpora. Use `<!-- doc-sample: compiles -->` before a complete
runtime example, or `<!-- doc-sample: compiles-editor -->` for Editor-only APIs. CommonMark
backtick and tilde fences are supported. Source line numbers identify the first code line.
Markers inside other code blocks are data; misplaced markers, empty claimed samples and
sanitized filename collisions fail before output changes.

The extractor shares the C# literal scanner with the other Python checks. It preserves literal
text when hoisting using directives and classifying compilation scopes. Explicit `DOC_SAMPLES_ROOT`,
`DOC_SAMPLES_OUT` and `DOC_SAMPLES_REQUIRE_BOTH` values retain fixture and automation support.
Outputs cannot replace documentation or traverse links. Stale generated sources are removed;
unrelated files in the output directory are preserved. The two legacy Node commands remain thin
compatibility launchers, including the explicit Editor compiler failure control.

### GitHub Credentials in the Container

The container resolves github.com credentials from a cached token. The Dev Containers credential
helper is out of the path entirely: that helper raises a dialog on the host desktop on **every**
invocation, and `git push`, `git fetch` and every API call invoke it.

With a token cached, nothing prompts. With an **empty** cache, git used to fall back to the editor's
own askpass dialog, another window on the host desktop from a different mechanism. The container
points `GIT_ASKPASS` at `scripts/git-askpass-refuse.sh` instead, so that path now ends in an error
naming the commands below rather than in a dialog. (The editor's own Git UI is unaffected: the Git
extension sets `GIT_ASKPASS` explicitly for the processes it launches.)

Supply the token once per container, either way:

```bash
npm run github:token:bootstrap   # asks the Dev Containers helper once; answer the dialog
npm run github:token:store       # paste a personal access token on stdin; no dialog at all
```

`git push`, `git fetch` and `scripts/github-token.sh` then read the same 0600 cache. A missing
credential is reported with the command that fixes it, never prompted for.

### Pre-installed CI/CD Tools (Container Only)

The dev container includes these additional tools that are **not required** on your host machine. Git hooks gracefully skip them if not present; CI will catch any issues:

- **actionlint**: GitHub Actions workflow linter
- **shellcheck**: Shell script linter
- **yamllint**: YAML linter
- **lychee**: Fast link checker

The container also installs the coding agent CLIs at startup. With npm 12, the installer
allows the OpenCode and Claude install scripts by package name, then checks that each
launcher responds to `--version`. It repairs a broken launcher even when its package is
already current. Registry failures remain nonfatal and are reported in the startup log.

### Required Tools (All Environments)

These tools are required and installed via npm/dotnet:

- **markdownlint**: Markdown linter (via npm)
- **prettier**: Markdown/JSON/YAML formatter (via npm)
- **cspell**: Spell checker (via npm)
- **CSharpier**: C# formatter (via .NET tools)
- **uv**: Locked Python script environment and analysis tools

## Formatting and Linting

- C# formatting: CSharpier (via dotnet tools)
- Markdown/JSON/YAML formatting: Prettier
- Markdown linting: markdownlint
- Link checks: lychee and custom script
- YAML linting: yamllint
- Workflow linting: actionlint

`npm run lint:markdown` checks tracked Markdown and new files that Git does not ignore,
then applies `.markdownlintignore`. Tracked files remain eligible even when a Git ignore rule
matches them. Hidden paths stay excluded, and generated, ignored local artifacts do not slow
file discovery. The command fails if discovery fails or finds no eligible documents.

`npm run lint:unsafe-code` refuses compiler-unsafe code, unchecked memory access, disabled IL2CPP
safety checks, and unbounded stack allocations. A variable stack allocation must be the direct
branch of an assignment whose condition compares that length with a constant. For example,
`count <= Max ? stackalloc int[count] : default` and
`count > Max ? default : stackalloc int[count]` are bounded. Reversing those branches is refused.
Compound conditions and intervening expressions are refused because a nearby comparison alone
does not establish the bound on the path that allocates.

IL2CPP safety options must omit the value or use the exact literal `true`. A constant expression
such as `!true` disables checks even though it contains that word. Named constants, compound
expressions, attribute aliases and numeric option casts follow the same rule. Each scan must report both a
literal-false control and a negated-true control before it can report a clean package.

Memory-access and IL2CPP option checks parse C# syntax, including Unicode escapes, invisible identifier format characters and
interpolation expressions. Comments, literal text and format strings remain excluded. Every conditional branch
is checked, and each source site is counted once. Aliases and static imports of `Unsafe` are
refused because they hide member names. Size and reference-identity queries remain permitted.
The positive controls require plain, escaped, formatted and interpolated calls to be found.
Separate sources exercise format characters without an ordinary spelling that could mask a prefilter regression.

Stack-allocation and memory-access checks use the existing Roslyn policy tool and require .NET SDK 9.0.320.
CI installs that SDK into an isolated runner directory and verifies the selected version.
A newer SDK preinstalled on the runner cannot override the declared compiler.

The compiler resolves constants and the actual length symbol;
parameters, locals, readonly fields and properties cannot borrow an unrelated constant's name.
Constant expressions and shared constants remain supported. The scan covers conditional branches
and follows the declarations and base types used by a bound to include their conditional symbols.
Unresolved bounds fail validation. Compiler contexts are cached only within one source snapshot,
with at most eight cached contexts; concurrent commands build into separate temporary output folders.

To scan another package checkout with the current tool, pass `--root /path/to/checkout`.
Report paths are relative to that checkout regardless of argument order. The checkout must contain
the normal required source trees, runtime assembly definition and check projects.

During linter development, `npm run test:lint-unsafe-code -- --filter "semantic binding"` selects
matching controls without running the full corpus. The summary reports the unselected count, and
an empty selection fails. Run the unfiltered suite before publication.

Use `npm run lint:unsafe-code -- --sarif artifacts/unsafe-code.sarif` to retain a
[SARIF 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/os/schemas/sarif-schema-2.1.0.json)
report. Repo Lint retains the same report as the `unsafe-code-sarif` artifact. Findings use the
`unsafe-code` rule, repository-relative URI paths and deterministic fingerprints. Every finding
fails the gate; there is no exception baseline. Reports include per-tree source and assembly
counts plus positive-control results. Missing required subjects, discovery/read errors and report
write failures fail validation; an execution failure cannot be mistaken for a clean result list.

## Python Tooling

Use Python 3.11.8 or newer for the repository's Python checks. The dev container pins `uv==0.13.7` and
exposes it as `uv`. Documentation CI installs that same version with pip, then installs the
fully pinned `requirements-docs.lock` with uv. `requirements-docs.txt` lists the direct
constraints; the lock records their transitive versions. Run locally with:

```bash
uv venv .venv --python '>=3.11.8,<3.12'
uv pip install --python .venv/bin/python -r requirements-docs.lock
.venv/bin/mkdocs build --strict
```

| Python path                                   | Dependency source                                     | Installer and cache                                                 | Invocation                                                                                                                  |
| --------------------------------------------- | ----------------------------------------------------- | ------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| Documentation validation and Pages deployment | `requirements-docs.lock` from `requirements-docs.txt` | Pinned uv; `setup-python` caches the pip bootstrap wheel            | `mkdocs build --strict`                                                                                                     |
| Wiki validation and generation                | `scripts/python~/uv.lock`                             | Pinned uv; the shared project installs test tools only for tests    | `uv run --project scripts/python~ --locked pytest scripts/wiki/test_wiki_scripts.py -v`; generation uses `--no-dev`         |
| Local Gates bounded-random proof              | `scripts/python~/uv.lock`                             | locked uv environment                                               | `uv run --project scripts/python~ --locked --no-dev --group proof python scripts/random-quality/verify-bounded-sampling.py` |
| Dev container image                           | `.devcontainer/requirements-tools.txt`                | Pinned uv installs yamllint and pinned MCP tools; pip bootstraps uv | Tools run from the image, not during hooks                                                                                  |
| Optional local hooks and Unity/result helpers | No Python packages installed by hooks                 | Existing interpreter or optional yamllint tool                      | Hooks call `yamllint` when available; helper scripts call `python3`                                                         |

Release, metadata, binary-check, feedback, wiki, changelog, XML-summary, and README mirror commands use the shared locked uv project.
The asset fixture generators use its `fixtures` group, and the bounded-random proof uses its `proof` group.
Every Python source is in strict scope; PowerShell, Bash, JavaScript, and inline workflow implementations
still need migration. The old
`requirements-wiki.in` and `requirements-wiki.txt` remain compatibility inputs for existing
standalone environments; current wiki CI uses the shared uv lock.

`npm run sync:readme-mirror` generates [the documentation front page](../readme.md) from the root README with
`readme_mirror.py`. `npm run lint:readme-mirror` checks it without writing. Both use
locked Python and the shared documentation parser; the historical Node commands
remain compatibility launchers.
Prettier still formats the generated Markdown. Cross-document fragments map from
the target headings; source prose and fenced examples retain their content.
Missing or empty sources, unsafe output links, and formatter errors fail the
command. Successful writes replace the complete mirror atomically.
The [port evidence](../performance/readme-mirror-port.zip) retains the original
corpus, native Windows checks and paired startup captures. Startup remains slower
than the original Node command; the port makes no startup performance claim.
The archive records the initial 64-case source snapshot. Later fixes also reject
missing documentation assets and preserve inline-code link examples; their current
regressions remain in the source suite. Historical captures keep their recorded identities.

`npm run check:reference-upstream-drift` checks the pinned sort and random source hashes through
locked typed Python. `--manifest` and `--report` retain the historical CLI and JSON report shape;
the Node entry points remain compatibility launchers. Downloads use a 30-second timeout and a
16 MiB source limit. Source and redirect URLs stay on `raw.githubusercontent.com` over HTTPS.
The checker rejects missing local files, paths escaping the repository, duplicate names, and
empty coverage. Its tests replay frozen reports captured from the original JavaScript, plus
manifest, URL, download, failure, and launcher controls. These checks do not update local source
adaptations or their pinned hashes.

The code-fence syntax validator and its regression suite also run through locked typed Python.
The historical shell entry points remain compatibility launchers. The validator retains its
comma-attribute rules, source locations, scan counts and failure exits. Seven original-executable
corpora freeze its output. Pure parser controls cover fence lengths, indentation, nested paths,
multiple findings and physical line endings; the suite also invokes both shell launchers.

Six pure singleton policy tests avoid asset setup and refresh while integration
cases retain their cleanup. See the [fixture measurements](../performance/singleton-policy-fixtures.md).

Earlier installer comparisons measured the bootstrap costs. On Python 3.11, fresh environments with separate cold and
warm caches gave documentation installs of 8.66/5.90 seconds with pip and 5.42/0.15 seconds
with uv. Pytest took 1.26/0.85 seconds with pip and 0.35/0.04 seconds with uv; Z3 took
2.94/0.76 seconds with pip and 2.20/0.04 seconds with uv. Bootstrapping pinned uv itself
with pip took another 3.57/0.99 seconds. Wiki CI and the bounded-random proof now use the shared uv project; these
historical install measurements do not describe its current end-to-end runtime.

To update Python dependencies, edit the direct constraints, then regenerate the locks with
the pinned uv version:

```bash
uv lock --project scripts/python~
uv pip compile --universal --python-version 3.11.8 requirements-docs.txt --output-file requirements-docs.lock
uv pip compile --universal --python-version 3.11 requirements-wiki.in --output-file requirements-wiki.txt
```

Review the lock diff, install into a fresh Python 3.11.8 or newer environment, run the strict MkDocs
build and wiki tests, and keep the CI `uv` pin aligned with `.devcontainer/Dockerfile`. The
single Z3 requirement and container tooling requirements are exact pins; update those and
their checks together. The `pip install` commands that bootstrap uv are deliberate because
uv cannot install itself into an otherwise empty runner or container.

## LLM Scratch Artifacts

- Files or folders starting with `_llm_` are git-ignored and automatically removed from the Unity package during imports.
- Keep temporary AI outputs outside the package root (or rename them) to avoid unexpected deletions by the asset cleaner.

### Dependabot PRs

Dependabot PRs are auto-formatted by CI. The bot pushes commits (same‑repo PRs) or opens a formatting PR (forked PRs) so they pass formatting gates.

### Opt‑In Formatting for Contributor PRs

If you want the bot to apply formatting to your PR:

- Comment on your PR with `/format` (aliases: `/autofix`, `/lint-fix`).
  - If your branch is in this repo, the bot pushes a commit with fixes.
  - If your PR is from a fork, the bot opens a formatting PR targeting the base branch.
  - The commenter must be the PR author or a maintainer/collaborator.
- Or run manually from the Actions tab: select "Opt‑in Formatting", click "Run workflow", and enter the PR number.

What gets auto‑fixed:

- C# via CSharpier
- Markdown/JSON/YAML via Prettier
- Markdown lint via markdownlint with `--fix`

What does not auto‑fix:

- Broken links (lychee)
- YAML issues that require manual edits

## Run Checks Locally

For browser correctness checks, `scripts/unity/run-browser-consumer.py` builds an isolated
WebGL consumer and runs retained-map, enum, RNG, and spatial-query cases in Chromium. It requires
an installed Unity Editor with WebGL support and Playwright. The runner uses Release IL2CPP,
High stripping, and `SINGLE_THREADED`; it checks exact golden bytes and rejects corrupt-byte and
stale-source controls. Install its matching Chromium and view the editor, browser, and artifact
path options with:

```bash
uv run --project scripts/python~ --locked --group browser playwright install chromium
uv run --project scripts/python~ --locked --group browser python scripts/unity/browser_consumer.py --help
```

Use `--browser-executable` to select an existing browser instead. This manual check does not replace
the supported Unity CI matrix or provide performance measurements. The browser runner and its tests
use the shared locked Python toolchain; the former hyphenated entry point remains a compatibility launcher.

- Install tools once:
  - `npm install --no-audit --no-fund` (the generated root lockfile stays ignored)
  - `dotnet tool restore`
  - `npm run hooks:install`: installs git hooks. The install script also configures `push.autoSetupRemote=true` and `push.default=simple` locally, so `git push` on a new branch sets tracking automatically.
- Verify all tools: `npm run verify:tools`
- Format C#: `dotnet tool run csharpier format`
- Check member ordering: `npm run lint:nested-type-placement`. Tuple return types, including
  tuples inside generic return types, keep methods in their method tier. Tuple fields and
  properties keep their field or property tier; initializer calls do not turn them into methods.
- Check docs/JSON/YAML: `npm run validate:content`
- Run the complete contract suite: `npm run validate:tests`. Hook regressions share the bounded
  worker pool with the fast checks; any check that mutates the repository runs exclusively first.
  `npm run validate:tests:fast` keeps its smaller scope, and
  `npm run validate:tests:hook-regressions` remains available for hook changes.
  To select a hook check in the full runner, use
  `node scripts/run-contract-tests.js --include-hook-regressions --only agent-preflight`.
- Run changed-file checks with `npm run agent:preflight` (or `agent:preflight:fix`).
  Select paths with `-Paths first/path second/path`, or use `-PathList list.txt` for a file
  containing one path per line or separated by NUL characters. Relative list filenames resolve
  from the repository root. Missing, directory and unreadable list inputs fail before any mutation,
  including with `-Fix`. An empty readable list selects no files.
  Unsupported options such as `--files` fail before any mutation.
  Trailing paths require `-Paths`; prefix filenames starting with a hyphen with `./`, or use
  an absolute path. With no path arguments, preflight checks the changed-file set.
  A failed required Git query stops preflight with Git's status and diagnostic. Initial index
  queries run before any fixes.
  Explicit selections use literal Git path scopes for their safety checks and known generated
  outputs. Read-only C# metadata validation also follows selected staged rename destinations
  to their former companion paths; formatter targets and write scope remain unchanged. Fixes must resolve inside the repository; linked targets keep partial-staging
  protection. A linked destination that resolves to the repository root is refused before tools start. Changed destinations outside the checked scope and hard links with unknown
  destinations fail before writing. Metadata recovery checks every staged source and its parent/file companions,
  including sources outside the selected validation list. With no explicit selection, discovery
  still covers the whole repository.
- Enforce EOL/encoding: `npm run eol:check`
- Lint GitHub Actions: `actionlint`
- Verify Markdown/code links: `npm run lint:doc-links` (locked uv Python)
  - The wrapper lives at `scripts/run-doc-link-lint.js` so you can also run `node ./scripts/run-doc-link-lint.js --verbose` if you are not using npm scripts.
  - The Python checker validates intra-repo Markdown links and `docs/...` references inside source files or scripts. Repo Lint runs it on every PR, so run it locally before pushing large doc updates.

## Style and Naming

Please follow the conventions outlined in `.editorconfig` and the repository guidelines (PascalCase types, camelCase fields, explicit types, braces required, no regions).

## Releases and Versioning

This project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html). Key points:

- **Git tags** use the format `3.1.5` (no `v` prefix)
- **package.json** contains the authoritative version number
- **SVG banner** displays the version with a `v` prefix (e.g., `v3.1.5`) for visual consistency, synced automatically via pre-commit hook

When installing via Git URL, reference versions without the `v` prefix:

```text
https://github.com/wallstop/unity-helpers.git#3.1.5
```

Maintainers can dispatch **Unity Benchmarks** to validate the licensed benchmark lifecycle. The
weekly hosted scheduler dispatches it on protected main. Both workflows must be enabled in the
repository. Branch dispatches retain diagnostics without updating the canonical performance
baseline.

Maintainers prepare releases from the default branch with the **Release Prepare** workflow. Choose a `major`, `minor`, or `patch` bump, review the generated release PR, and squash-merge it with the default `release: X.Y.Z` title. **Auto publish** is enabled by default. After the merged commit passes Unity Tests, Local Gates, Repo Lint, and every other triggered push validation workflow, automation starts **Release Publish** with that exact commit. It validates and packs npm, creates the `.unitypackage` without opening Unity, creates the release tag when needed, and publishes npm and GitHub Release assets.

Clear **Auto publish** during preparation to publish manually. In **Release Publish**, choose a branch, tag, or commit with **source_ref**; leave **version** blank to read it from that source's `package.json`. **Export only** validates and produces downloadable archives without changing tags or publishing. Automatic publication never moves an existing tag. A failed validation or prior publication attempt requires inspection and manual recovery; duplicate completion events do not dispatch the same release twice. Remove `<!-- unity-helpers:auto-publish -->` from an unmerged release PR to cancel its automatic publication.

Before dispatch, automation atomically creates the internal `release-publish-claims/X.Y.Z` tag at the validated commit. This retained claim prevents duplicate dispatch even before GitHub lists the publication run. A lost response or interrupted publisher leaves the claim in place: inspect the publication history, then use **Release Publish** manually with the claimed source commit. Every main validation workflow uses a separate concurrency group for each pushed commit; newer pull-request revisions still cancel older pull-request runs. Documentation deployment, issue-template synchronization and devcontainer publication have separate recovery paths and do not validate release archives, so their pending or superseded runs do not block publication.

## Rebuild bundled serialization dependencies

These are maintainer steps for changing the shipped assemblies, not package-installation steps.
The [assembly conflict guide](../guides/bundled-assembly-conflicts.md) explains consumer diagnosis.

```bash
uv run --project scripts/python~ --locked --no-dev python scripts/build-protobuf-candidate.py --output /tmp/protobuf-candidate
uv run --project scripts/python~ --locked --no-dev python scripts/verify-protobuf-shipped.py --candidate-root /tmp/protobuf-candidate/assemblies
```

The retained candidate builder requires SDK 9.0.319 and produces isolated binaries with a source-bound build receipt. Repository validation uses SDK 9.0.320; install the older SDK separately when rebuilding that retained candidate.
The independent current lane uses `ProtobufNetOracle=candidate` and
`ProtobufNetCandidateRoot=/tmp/protobuf-candidate/assemblies`. Frozen v2/v3 lanes retain their
original DLLs under `Generator~`; dependency upgrades must not refresh those historical oracles.
The retained Dox consumer suite exercises the frozen v3 and current builds.

Keep the Unity-version constraints, importer GUIDs and assembly ownership policy when rebuilding.
`npm run lint:bundled-assemblies` checks the `Runtime/Binaries/` constraints and absence rules.
It does not inventory the separate protobuf dependency directory. Preserve the documented source
and binary hashes when updating provenance.

A .NET Standard target and passing host tests do not establish Unity assembly ownership or backend
health. The complete supported-version, stripped IL2CPP, WebGL and native process qualification
remains tracked in [the dependency qualification issue](https://github.com/Ambiguous-Interactive/unity-helpers/issues/1052).

### Documentation environment

Use Python 3.11.8 or later within the 3.11 series for the documentation lock. An older
existing environment may build successfully with stale plugins while failing to install the
current lock. Create a supported environment and sync `requirements-docs.lock` before running
`mkdocs build --strict`; the repository's documentation CI uses that lock.

### Pinned build-lock input checks

`npm run test:build-lock-action-inputs` runs the typed Python validator against
`BUILD_LOCK_POLICY_ROOT`, a full-history checkout of the central policy repository. Every call
is checked against its own pinned action definition. The validator refuses missing required
inputs, unknown supplied inputs, unreadable pins and zero-call scans. A missing policy checkout
is an explicit local skip and a failure under GitHub Actions.

The Node entry points remain compatibility launchers, including the exported pin resolver. The
resolver reads live `uses:` lines and refuses absent, conflicting or non-commit references. Its
twelve original observations accompany twelve parser observations captured after the earlier
seventeen parser assertions passed. Additional controls create
real local Git commits to check different pinned contracts, declaration caching, missing history,
output bounds, timeouts and full CLI execution. The checker reads local Git objects and does not
fetch or modify either checkout. Git reads discard inherited `GIT_*` overrides and disable
replacement objects so a pinned definition refers to its physical commit. Controls exercise both
environment redirection and a real replacement object. Python and uv setup precede the workflow
step that resolves the policy checkout pin.
