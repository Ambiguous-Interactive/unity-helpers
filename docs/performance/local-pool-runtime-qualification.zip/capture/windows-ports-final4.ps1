$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
Push-Location $repository
try {
    $env:UV_PROJECT_ENVIRONMENT = Join-Path ([IO.Path]::GetTempPath()) 'uh-python-20261113'
    $env:PYTHONUTF8 = '0'
    $env:PYTHONIOENCODING = 'cp1252'
    & uv run --quiet --project scripts/python~ --locked --python 3.11 python -c "import sys,locale;print(sys.version);print(locale.getencoding());print(sys.flags.utf8_mode)" *> (Join-Path $PSScriptRoot 'windows-ports-final4-environment.log')
    if ($LASTEXITCODE -ne 0) { throw 'Could not inspect the native Python environment.' }
    $sources = @('scripts/tests/test-run-repo-lint.js','scripts/tests/test-run-contract-tests.js','scripts/resolve-build-lock-pin.js','scripts/tests/fixtures/build-lock-pin-original.json','scripts/tests/fixtures/build-lock-inputs-original.json','scripts/build_lock_inputs.py','scripts/tests/test_build_lock_inputs.py','scripts/validate-build-lock-action-inputs.js','scripts/tests/test-build-lock-action-input-parser.js','scripts/lint_comparison_direction.py','scripts/tests/test_comparison_direction.py','scripts/tests/fixtures/comparison-direction-original.json','scripts/python~/uv.lock','scripts/lint-comparison-direction.js','scripts/tests/test-lint-comparison-direction.js','scripts/cli_encoding.py','package.json')
    $before = @{}
    foreach ($source in $sources) { $before[$source] = (Get-FileHash $source -Algorithm SHA256).Hash }
    & uv run --quiet --project scripts/python~ --locked --python 3.11 pytest scripts/tests/test_comparison_direction.py scripts/tests/test_build_lock_inputs.py -q *> (Join-Path $PSScriptRoot 'windows-ports-final4.log')
    $exitCode = $LASTEXITCODE
    $after = @{}
    foreach ($source in $sources) { $after[$source] = (Get-FileHash $source -Algorithm SHA256).Hash; if ($after[$source] -ne $before[$source]) { throw 'Sources changed during Windows test execution.' } }
    @{ exitCode=$exitCode; before=$before; after=$after; completedUtc=[DateTime]::UtcNow } | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'windows-ports-final4-result.json')
} finally { Pop-Location }
