$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113-editor'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$variants = @(Get-Content (Join-Path $PSScriptRoot 'editor-variants.json') -Raw | ConvertFrom-Json)
$filter = (($variants | ForEach-Object type) + @('WallstopStudios.UnityHelpers.Tests.Core.TestUtils.SynchronousEditorTestBaseTests')) -join ';'
$results = @()
$expectedCases = $null
$known = @{}
foreach ($variant in $variants) {
    $known[$variant.relative] = @('baseline','candidate','restore' | ForEach-Object { (Get-FileHash (Join-Path $PSScriptRoot $variant.$_)).Hash })
}
try {
    foreach ($index in 1..3) {
        $arms = if ($index -eq 2) { @('candidate','baseline') } else { @('baseline','candidate') }
        foreach ($arm in $arms) {
            foreach ($variant in $variants) {
                $path = Join-Path $repository $variant.relative
                if ((Get-FileHash $path).Hash -notin $known[$variant.relative]) { throw "Unexpected source before swap: $path" }
                [IO.File]::WriteAllBytes($path,[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $variant.$arm)))
            }
            $before=@{}
            foreach ($variant in $variants) { $before[$variant.relative]=(Get-FileHash (Join-Path $repository $variant.relative)).Hash }
            $artifacts = Join-Path $PSScriptRoot "editor-scope-v3-$arm-$index"
            & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Core.Editor;WallstopStudios.UnityHelpers.Tests.Editor.Core;WallstopStudios.UnityHelpers.Tests.Editor.CustomDrawers;WallstopStudios.UnityHelpers.Tests.Editor.Tools;WallstopStudios.UnityHelpers.Tests.Editor.Validation;WallstopStudios.UnityHelpers.Tests.Editor.WButton' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter $filter -TestCategory '!Performance;!Stress' *> (Join-Path $PSScriptRoot "editor-scope-v3-$arm-$index-driver.log")
            $exitCode=$LASTEXITCODE
            $after=@{}
            foreach ($variant in $variants) { $after[$variant.relative]=(Get-FileHash (Join-Path $repository $variant.relative)).Hash; if ($before[$variant.relative] -ne $after[$variant.relative]) { throw 'Variant changed during capture' } }
            $observation=Get-Content (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
            [xml]$xml=Get-Content (Join-Path $artifacts 'results.xml') -Raw
            $cases=@($xml.SelectNodes('//test-case'))
            $identities = @($cases | ForEach-Object fullname | Sort-Object)
            if ($null -eq $expectedCases) { $expectedCases=$identities }
            if (Compare-Object $expectedCases $identities) { throw 'Actual case identities differ between captures' }
            $healthy=$observation.Process.RawExitCode -eq 0 -and $observation.Process.StandardOutputEndObserved -and $observation.Process.StandardErrorEndObserved -and -not $observation.Process.OutputDrainStopped
            $complete=$xml.'test-run'.result -eq 'Passed' -and $cases.Count -gt 300 -and @($cases|Where-Object result -ne 'Passed').Count -eq 0
            $log = Get-Content (Join-Path $artifacts 'unity.log') -Raw
            $loaded = @()
            foreach ($variant in $variants) {
                $matches = [regex]::Matches($log,'SYNC_SCOPE_VARIANT\|([^|\r\n]+)\|([^|\r\n]+)\|([0-9a-f-]{36})')
                $gate = @($matches | Where-Object { $_.Groups[1].Value -ceq $variant.type })
                if ($gate.Count -ne 1) { throw "Missing/duplicate loaded fixture gate: $($variant.type)" }
                $expectedBase = if ($arm -eq 'baseline') { 'WallstopStudios.UnityHelpers.Tests.Core.CommonTestBase' } else { 'WallstopStudios.UnityHelpers.Tests.Core.SynchronousEditorTestBase' }
                if ($gate[0].Groups[2].Value -cne $expectedBase) { throw "Loaded fixture has wrong base: $($variant.type)" }
                $loaded += @{type=$gate[0].Groups[1].Value;base=$gate[0].Groups[2].Value;mvid=$gate[0].Groups[3].Value}
            }
            $fixtureRows=@($xml.SelectNodes('//test-suite[@type="TestFixture"]') | ForEach-Object { @{ name=$_.fullname;duration=[double]$_.duration;count=[int]$_.testcasecount } })
            $results += @{ arm=$arm;index=$index;exitCode=$exitCode;before=$before;after=$after;healthy=$healthy;complete=$complete;cases=$cases.Count;fixtures=$fixtureRows;loaded=$loaded }
            $results | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $PSScriptRoot 'editor-scope-v3-paired-live.json')
            if ($exitCode -ne 0 -or -not $healthy -or -not $complete) { throw "Capture $arm/$index is incomplete or unhealthy" }
        }
    }
    @{ completedUtc=[DateTime]::UtcNow;results=$results } | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $PSScriptRoot 'editor-scope-v3-paired-result.json')
} finally {
    foreach ($variant in $variants) {
        $path=Join-Path $repository $variant.relative
        if ((Get-FileHash $path).Hash -in $known[$variant.relative]) { [IO.File]::WriteAllBytes($path,[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $variant.restore))) }
        else { Write-Error "Source changed outside experiment; leaving it untouched: $path" }
    }
}
