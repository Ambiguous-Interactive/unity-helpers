$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113-pools'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$inputs = @('Runtime/Utils/SpriteMaskReader.cs','Tests/Runtime/Utils/SpriteMaskReaderTests.cs','Runtime/Utils/LocalPool.cs','Runtime/Utils/ThreadLocalArrayPool.cs','Tests/Runtime/Utils/LocalPoolTests.cs','Tests/Runtime/Utils/ThreadLocalArrayPoolTests.cs')
$before = @($inputs | ForEach-Object { @{ path=$_; sha256=(Get-FileHash (Join-Path $repository $_) -Algorithm SHA256).Hash } })
& $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime' -TestFilter 'SpriteArtBoundsTests;SpriteMaskReaderTests;SpriteAlphaMaskTests;SpriteMaskExtensionsTests;BendableLineTests;SpriteHelpersTests;WallstopStudios.UnityHelpers.Tests.Utils.LocalPoolTests;WallstopStudios.UnityHelpers.Tests.Utils.ThreadLocalArrayPoolTests' -TestCategory '!Performance;!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath (Join-Path $PSScriptRoot 'native-runtime-final') -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot 'native-runtime-final-driver.log')
$exitCode=$LASTEXITCODE
$after = @($inputs | ForEach-Object { @{ path=$_; sha256=(Get-FileHash (Join-Path $repository $_) -Algorithm SHA256).Hash } })
@{ exitCode=$exitCode; completedUtc=[DateTime]::UtcNow; before=$before; after=$after } | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $PSScriptRoot 'native-runtime-final-result.json')
if ($exitCode -ne 0) { throw "Native runtime command exited $exitCode" }
for ($index=0; $index -lt $before.Count; ++$index) { if ($before[$index].sha256 -ne $after[$index].sha256) { throw 'Runtime source changed during validation' } }
$artifacts = Join-Path $PSScriptRoot 'native-runtime-final'
[xml]$xml=Get-Content (Join-Path $artifacts 'results.xml') -Raw
$cases=@($xml.SelectNodes('//test-case'))
if (@($cases | Where-Object result -eq 'Passed').Count -ne 224 -or @($cases | Where-Object result -eq 'Skipped').Count -ne 72 -or @($cases | Where-Object result -eq 'Failed').Count) { throw 'Unexpected runtime case results' }
[xml]$original=Get-Content (Join-Path $PSScriptRoot 'native-sprite-byte-final/results.xml') -Raw
if (Compare-Object @($original.SelectNodes('//test-case') | ForEach-Object fullname | Sort-Object) @($cases | ForEach-Object fullname | Sort-Object)) { throw 'Runtime case identities changed' }
$receipt=Get-Content (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
$healthy=$receipt.Process.RawExitCode -eq 0 -and $receipt.Process.StandardOutputEndObserved -and $receipt.Process.StandardErrorEndObserved -and -not $receipt.Process.OutputDrainStopped
if (-not $healthy) { throw 'Unhealthy runtime process receipt' }
@{ exitCode=$exitCode; healthy=$healthy; passed=224; skipped=72; completedUtc=[DateTime]::UtcNow; before=$before; after=$after } | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $PSScriptRoot 'native-runtime-final-result.json')
