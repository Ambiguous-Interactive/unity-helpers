$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113-pools'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
@{pid=$PID;startUtc=[DateTime]::UtcNow} | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'native-pool-performance-identity.json')
$inputs=@('Runtime/Utils/LocalPool.cs','Runtime/Utils/ThreadLocalArrayPool.cs','Runtime/Utils/Buffers.cs','Runtime/Utils/DisposalLease.cs','Tests/Runtime/Utils/LocalPoolTests.cs','Tests/Runtime/Utils/ThreadLocalArrayPoolTests.cs','Tests/Runtime/Performance/LocalPoolPerformanceTests.cs')
$before=@{}
foreach($source in $inputs){$before[$source]=(Get-FileHash (Join-Path $repository $source)).Hash}
$records=@()
$code=1
try {
 foreach($index in 1..3){
  $artifacts=Join-Path $PSScriptRoot "native-pool-performance-$index"
  & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime;WallstopStudios.UnityHelpers.Tests.Runtime.Performance' -TestFilter 'WallstopStudios.UnityHelpers.Tests.Utils.LocalPoolTests;WallstopStudios.UnityHelpers.Tests.Utils.ThreadLocalArrayPoolTests;WallstopStudios.UnityHelpers.Tests.Runtime.Performance.LocalPoolPerformanceTests' -TestCategory '!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot "native-pool-performance-$index-driver.log")
  if($LASTEXITCODE -ne 0){throw "Native command failed: $index exit $LASTEXITCODE"}
  [xml]$xml=Get-Content (Join-Path $artifacts 'results.xml') -Raw
  $cases=@($xml.SelectNodes('//test-case'))
  if($cases.Count -ne 33 -or @($cases|Where-Object result -ne 'Passed').Count){throw 'Missing or failing cases'}
  $receipt=Get-Content (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw|ConvertFrom-Json
  $healthy=$receipt.Process.RawExitCode -eq 0 -and $receipt.Process.StandardOutputEndObserved -and $receipt.Process.StandardErrorEndObserved -and -not $receipt.Process.OutputDrainStopped
  if(-not $healthy){throw 'Unhealthy process/output receipt'}
  $text=Get-Content (Join-Path $artifacts 'results.xml') -Raw
  $rows=@([regex]::Matches($text,'LOCALPOOL,\d+,[A-Za-z]+,\d+,[0-9.Ee+-]+,[0-9.Ee+-]+'))
  if($rows.Count -ne 84){throw 'Expected 84 timing rows'}
  $module=[regex]::Match($text,'LOCALPOOL_MODULE,([0-9a-f-]{36})').Groups[1].Value
  $dll=Join-Path $project 'Library/ScriptAssemblies/WallstopStudios.UnityHelpers.dll'
  $stream=[IO.File]::OpenRead($dll)
  try {
    $pe=[Reflection.PortableExecutable.PEReader]::new($stream)
    try {
      $metadata=[Reflection.Metadata.PEReaderExtensions]::GetMetadataReader($pe)
      $loaded=$metadata.GetGuid($metadata.GetModuleDefinition().Mvid).ToString()
    } finally { $pe.Dispose() }
  } finally { $stream.Dispose() }
  if($module -cne $loaded){throw 'Loaded runtime module differs from the captured DLL'}
  $after=@{}
  foreach($source in $inputs){$after[$source]=(Get-FileHash (Join-Path $repository $source)).Hash;if($after[$source] -ne $before[$source]){throw "Input changed: $source"}}
  $records+=@{index=$index;cases=$cases.Count;healthy=$healthy;rows=@($rows|ForEach-Object Value);module=$module;dllSha256=(Get-FileHash $dll).Hash;before=$before;after=$after}
  $records|ConvertTo-Json -Depth 8|Set-Content (Join-Path $PSScriptRoot 'native-pool-performance-live.json')
 }
 $code=0
} catch { $_|Out-String|Set-Content (Join-Path $PSScriptRoot 'native-pool-performance-controller.log') }
finally { @{exitCode=$code;records=$records;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json -Depth 8|Set-Content (Join-Path $PSScriptRoot 'native-pool-performance-result.json') }
exit $code
