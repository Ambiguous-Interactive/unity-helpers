$ErrorActionPreference = 'Stop'
@{pid=$PID;startedUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'windows-final4-identity.json')
& (Join-Path $PSScriptRoot 'windows-ports-final4.ps1')
& (Join-Path $PSScriptRoot 'windows-strict-final2.ps1')
$ports=Get-Content (Join-Path $PSScriptRoot 'windows-ports-final4-result.json') -Raw|ConvertFrom-Json
$strict=Get-Content (Join-Path $PSScriptRoot 'windows-strict-final2-result.json') -Raw|ConvertFrom-Json
@{ports=$ports.exitCode;strict=$strict.exitCode;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'windows-final4-result.json')
