param([Parameter(Mandatory)][string]$Script)
$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$target = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $Script))
if (-not (Test-Path $target -PathType Leaf)) { throw 'Missing owned controller' }
$shell = New-Object -ComObject Shell.Application
try {
    $shell.ShellExecute((Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'),('-NoProfile -File "' + $target + '"'),$repository,'open',0)
} finally { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) }
