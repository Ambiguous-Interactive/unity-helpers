$ErrorActionPreference = 'Stop'
$code=1
try {
    & (Join-Path $PSScriptRoot 'editor-scope-v4-paired.ps1') *> (Join-Path $PSScriptRoot 'editor-scope-v4-controller.log')
    $code=0
} catch {
    $_ | Out-String | Add-Content (Join-Path $PSScriptRoot 'editor-scope-v4-controller.log')
} finally {
    @{ exitCode=$code;completedUtc=[DateTime]::UtcNow } | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'editor-scope-v4-controller-result.json')
}
exit $code
