$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113-pools'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$inputs = @('Runtime/Utils/SpriteMaskReader.cs','Tests/Runtime/Utils/SpriteMaskReaderTests.cs','Runtime/Utils/LocalPool.cs','Runtime/Utils/ThreadLocalArrayPool.cs','Tests/Runtime/Utils/LocalPoolTests.cs','Tests/Runtime/Utils/ThreadLocalArrayPoolTests.cs')
$before = @($inputs | ForEach-Object { @{ path=$_; sha256=(Get-FileHash (Join-Path $repository $_) -Algorithm SHA256).Hash } })
& $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime' -TestFilter 'SpriteArtBoundsTests;SpriteMaskReaderTests;SpriteAlphaMaskTests;SpriteMaskExtensionsTests;BendableLineTests;SpriteHelpersTests;WallstopStudios.UnityHelpers.Tests.Utils.LocalPoolTests;WallstopStudios.UnityHelpers.Tests.Utils.ThreadLocalArrayPoolTests' -TestCategory '!Performance;!Stress' -RepoRoot $repository -ProjectPath $project -ArtifactsPath (Join-Path $PSScriptRoot 'native-sprite-byte-final') -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') *> (Join-Path $PSScriptRoot 'native-sprite-byte-final-driver.log')
$exitCode=$LASTEXITCODE
$after = @($inputs | ForEach-Object { @{ path=$_; sha256=(Get-FileHash (Join-Path $repository $_) -Algorithm SHA256).Hash } })
@{ exitCode=$exitCode; completedUtc=[DateTime]::UtcNow; before=$before; after=$after } | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $PSScriptRoot 'native-sprite-byte-final-result.json')
