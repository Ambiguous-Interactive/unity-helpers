$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261113-editor'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$variants = @(Get-Content (Join-Path $PSScriptRoot 'editor-variants.json') -Raw | ConvertFrom-Json)
$filter = (($variants | ForEach-Object type) + @('WallstopStudios.UnityHelpers.Tests.Core.TestUtils.SynchronousEditorTestBaseTests')) -join ';'
$inputs = @($variants | ForEach-Object relative) + @('Runtime/TestSupport/UnityObjectTrackingTestBase.cs','Tests/Core/Editor/SynchronousEditorTestBaseTests.cs','Tests/Core/Editor/SynchronousScopeDisposable.cs')
$before=@{}
foreach ($source in $inputs) { $before[$source]=(Get-FileHash (Join-Path $repository $source)).Hash }
$artifacts = Join-Path $PSScriptRoot 'editor-final'
& $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Core.Editor;WallstopStudios.UnityHelpers.Tests.Editor.Core;WallstopStudios.UnityHelpers.Tests.Editor.CustomDrawers;WallstopStudios.UnityHelpers.Tests.Editor.Tools;WallstopStudios.UnityHelpers.Tests.Editor.Validation;WallstopStudios.UnityHelpers.Tests.Editor.WButton' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter $filter -TestCategory '!Performance;!Stress' *> (Join-Path $PSScriptRoot 'editor-final-driver.log')
$code=$LASTEXITCODE
$after=@{}
foreach ($source in $inputs) { $after[$source]=(Get-FileHash (Join-Path $repository $source)).Hash; if ($after[$source] -ne $before[$source]) { throw "Source changed: $source" } }
[xml]$xml=Get-Content (Join-Path $artifacts 'results.xml') -Raw
$cases=@($xml.SelectNodes('//test-case'))
$receipt=Get-Content (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
$healthy=$receipt.Process.RawExitCode -eq 0 -and $receipt.Process.StandardOutputEndObserved -and $receipt.Process.StandardErrorEndObserved -and -not $receipt.Process.OutputDrainStopped
$passed=$cases.Count -eq 357 -and @($cases | Where-Object result -ne 'Passed').Count -eq 0
@{exitCode=$code;healthy=$healthy;passed=$passed;cases=$cases.Count;before=$before;after=$after;completedUtc=[DateTime]::UtcNow} | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $PSScriptRoot 'editor-final-result.json')
if ($code -ne 0 -or -not $healthy -or -not $passed) { throw 'Final Editor verification failed' }
