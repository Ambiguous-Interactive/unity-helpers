$ErrorActionPreference = 'Stop'
@{pid=$PID;startedUtc=[DateTime]::UtcNow} | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'native-final-campaign-identity.json')
$code=1
try {
    & (Join-Path $PSScriptRoot 'editor-final.ps1')
    & (Join-Path $PSScriptRoot 'native-runtime-final.ps1')
    & (Join-Path $PSScriptRoot 'windows-ports-final3.ps1')
    $python=Get-Content (Join-Path $PSScriptRoot 'windows-ports-final3-result.json') -Raw | ConvertFrom-Json
    if ($python.exitCode -ne 0) { throw 'Final Windows Python tests failed' }
    $code=0
} catch { $_ | Out-String | Set-Content (Join-Path $PSScriptRoot 'native-final-campaign-error.log') }
finally { @{exitCode=$code;completedUtc=[DateTime]::UtcNow} | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'native-final-campaign-result.json') }
exit $code
