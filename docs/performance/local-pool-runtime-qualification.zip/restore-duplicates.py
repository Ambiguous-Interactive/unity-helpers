import hashlib,json,pathlib,shutil
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'manifest-sha256.json').read_text())
for destination,source in json.loads((root/'duplicate-files.json').read_text()).items():
 target=root/destination;original=root/source
 assert hashlib.sha256(original.read_bytes()).hexdigest()==manifest[destination]
 if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==manifest[destination]
 else:target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
