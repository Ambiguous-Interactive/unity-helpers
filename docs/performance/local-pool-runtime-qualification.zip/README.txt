Session evidence, 2026-11-13. Base commit: e180654305a0888ec71e45a0d859301213e83024.

Duplicate files are stored once. After extraction, run python restore-duplicates.py from the archive root to recreate identical logical paths. All Unity test-framework source ZIPs and their original receipts are retained. The final-source overlay contains text changes and their metadata; published ZIP assets are supplied separately.

The archive retains native pool measurements, byte-format sprite correctness, Editor ownership scope comparisons and known failed/incomplete attempts. Process receipts, complete NUnit trees, source seals, runtime module IDs and controllers are authoritative. Final-source is an overlay onto that base. Use a fresh owned temporary project, the named Unity version, exact assembly filters and category gates. Preserve new replay receipts separately.

Pool timing: three processes, 33 passed each, 84 rows each. The measured ThreadLocalArrayPoolTests source is capture/ThreadLocalArrayPoolTests.measured.txt; final sources add a post-owner-disposal lease assertion to an existing case. Runtime implementations are identical. Final native-runtime-final verifies that strengthened case.

Editor timing: three alternating fresh pairs, 357 identical cases, comprising 347 migrated cases plus 10 controls. Totals in editor-scope-v7-summary.json exclude controls. Overlay each variant from editor-variants.json for replay. Its relative paths are repository paths; baseline/candidate/restore files are under capture/. Two neighboring unmeasured classes also changed base in the experimental file, but final source restores them. Final controls have a bounded reentry negative control and a stronger caught-failure assertion added after timing; their final-source copy is NOT a literal snapshot of the earlier ten control bodies. Measured fixture variants are exact. No speed improvement is established for this cohort. Final editor-final verifies shipped sources without timing instrumentation.

Failed/incomplete attempts: v2 includes five unchanged cold-GUI-style failures (#1193); v3 has a wrong log-location gate; v4 lacks direct TestSupport asmdef references; v5 lacks NewGameObject. Those compile/harness failures are separate from accepted timings. v6 lost controller/children during startup without a final receipt; the cause remains unknown (#1195). Successful v7 captures do not resolve it. Sprite byte-green records the initial white-RGB Alpha8 error; final sources match observed GetPixels32 black RGB. Byte-red uses the original reader. No failed attempt counts as passing evidence.

Windows ports-final3 records the earlier 130-case corpus. The exact two Python test sources for that corpus are in python-ports-130-source. Final ports-final4 adds two real test-launcher compatibility controls, for 132 cases; final strict analysis retains all 139 sources.

Comparison checker timings are full-tree local observations with matching 2915-file coverage verified separately on unchanged sources, not a CI speed claim. The original timing script expects scripts/.comparison-original.cjs; restore capture/comparison-original.cjs there only for replay. Frozen original parser observations used CRLF bytes; comparison-original-captured.cjs matches that exact hash. comparison-source-provenance.json explains the LF Git-blob timing input. Both original snapshots are retained.

Dependency admission retains official package hashes and framework metadata only. It does not qualify BCL 11 or install CSharpier 1.4; #1052 and #1194 retain those remaining upgrades.

Runtime/platform qualification is limited to the named captures. Unity 2021/2022 and stripped IL2CPP acceptance are independent CI obligations. This evidence does not close #859, #1113, #1106 or #1131.
