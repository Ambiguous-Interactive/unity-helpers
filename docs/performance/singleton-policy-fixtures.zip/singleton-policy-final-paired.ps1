$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261112b'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$names=@('SingletonAssetPollutionPreventionTests','SingletonAssetPolicyTests')
$known=@{}
foreach ($name in $names) { $known[$name]=@((Get-FileHash (Join-Path $PSScriptRoot "$name.original.cs.txt")).Hash,(Get-FileHash (Join-Path $PSScriptRoot "$name.candidate.cs.txt")).Hash) }
$registry=Join-Path $repository 'Tests/Editor/Utils/SingletonTestTypes.cs'
$registryHash=(Get-FileHash $registry).Hash
$results=@()
$caseNames=$null
try {
    foreach ($index in 1..3) {
        $arms=if ($index -eq 2) { @('candidate','baseline') } else { @('baseline','candidate') }
        foreach ($arm in $arms) {
            if ((Get-FileHash $registry).Hash -ne $registryHash) { throw 'Shared type registry changed.' }
            $variant=if($arm -eq 'baseline'){'original'}else{'candidate'}
            $hashes=@{}
            foreach ($name in $names) {
                $source=Join-Path $repository "Tests/Editor/Utils/$name.cs"
                if ((Get-FileHash $source).Hash -notin $known[$name]) { throw "Unexpected source state for $name" }
                [IO.File]::WriteAllBytes($source,[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "$name.$variant.cs.txt")))
                $hashes[$name]=(Get-FileHash $source).Hash
            }
            $artifacts=Join-Path $PSScriptRoot "singleton-policy-final-$arm-$index"
            & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Editor.Utils' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter 'WallstopStudios.UnityHelpers.Tests.Utils.SingletonAssetPollutionPreventionTests;WallstopStudios.UnityHelpers.Tests.Utils.SingletonAssetPolicyTests' -TestCategory '!Performance;!Stress' *> (Join-Path $PSScriptRoot "singleton-policy-final-$arm-$index-driver.log")
            $code=$LASTEXITCODE
            [xml]$xml=Get-Content (Join-Path $artifacts 'results.xml') -Raw
            $cases=@($xml.SelectNodes('//test-case'))
            $pureCount=@($cases | Where-Object { $_.fullname -like '*.SingletonAssetPolicyTests.*' }).Count
            if (($arm -eq 'baseline' -and $pureCount -ne 0) -or ($arm -eq 'candidate' -and $pureCount -ne 6)) { throw 'Loaded fixture ownership does not match the selected variant.' }
            $identities=@($cases | ForEach-Object { $_.fullname -replace 'WallstopStudios.UnityHelpers.Tests.Utils.SingletonAsset(?:PollutionPrevention|Policy)Tests\.','' } | Sort-Object)
            if ($null -eq $caseNames) { $caseNames=$identities }
            if ($identities.Count -ne 13 -or @((Compare-Object $caseNames $identities)).Count -ne 0) { throw 'The same thirteen case identities must be retained.' }
            $process= (Get-Content (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json).Process
            $healthy=$process.RawExitCode -eq 0 -and $process.StandardOutputEndObserved -and $process.StandardErrorEndObserved -and -not $process.OutputDrainStopped
            foreach ($name in $names) { if((Get-FileHash (Join-Path $repository "Tests/Editor/Utils/$name.cs")).Hash -ne $hashes[$name]) { throw 'Source changed within a capture.' } }
            $duration=0d
            foreach ($fixture in $xml.SelectNodes('//test-suite[@type="TestFixture"]')) { $duration += [double]::Parse($fixture.duration,[Globalization.CultureInfo]::InvariantCulture) }
            $results+=@{arm=$arm;index=$index;exitCode=$code;healthy=$healthy;duration=$duration;caseNames=$identities;sourceHashes=$hashes;registrySha256=$registryHash;pureCases=$pureCount;assemblySha256=(Get-FileHash (Join-Path $project "Library/ScriptAssemblies/WallstopStudios.UnityHelpers.Tests.Editor.Utils.dll")).Hash}
            $results | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $PSScriptRoot 'singleton-policy-final-paired-live.json')
            if($code -ne 0 -or -not $healthy -or $xml.'test-run'.result -ne 'Passed' -or @($cases | Where-Object result -ne 'Passed').Count -ne 0) { throw 'Capture lacks passing cases and healthy completion.' }
        }
    }
    @{results=$results;completedUtc=[DateTime]::UtcNow} | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'singleton-policy-final-paired-result.json')
} finally {
    foreach($name in $names) {
        $source=Join-Path $repository "Tests/Editor/Utils/$name.cs"
        if((Get-FileHash $source).Hash -in $known[$name]) { [IO.File]::WriteAllBytes($source,[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "$name.candidate.cs.txt"))) }
        else { Write-Error 'Unexpected external source edit; left intact.' }
    }
}
