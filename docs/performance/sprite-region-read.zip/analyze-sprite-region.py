from pathlib import Path
import json,statistics,xml.etree.ElementTree as E
root=Path(__file__).resolve().parent
receipt=json.loads((root/'sprite-region-final-paired-result.json').read_text(encoding='utf-8-sig'))
assert len(receipt['results'])==6
captures={};identities={}
for row in receipt['results']:
 assert row['exitCode']==0 and row['healthy'] and row['complete'] and row['before']==row['after']
 path=root/f"sprite-region-final-{row['arm']}-{row['index']}/results.xml"
 if not path.exists():path=root/f"{row['arm']}-{row['index']}/results.xml"
 tree=E.parse(path).getroot();assert tree.get('result')=='Passed'
 cases=list(tree.iter('test-case'));assert len(cases)==6
 capture={};ids=set()
 for case in cases:
  assert case.get('result')=='Passed'
  lines=(case.findtext('output') or '').strip().splitlines()
  identity=next(line.split('|',1)[1] for line in lines if line.startswith('SPRITE_REGION_ID|'));ids.add(identity)
  samples=[float(line) for line in lines if line and line[0].isdigit()];assert len(samples)==21 and min(samples)>0
  header=next(line for line in lines if line.startswith('SPRITE_REGION|')).split('|');iterations=int(header[-1]);assert iterations>0
  capture[case.get('name')]={'samples':samples,'min':min(samples),'median':statistics.median(samples),'batch':iterations,'mvid':identity}
 assert len(ids)==1
 captures[(row['arm'],row['index'])]=capture
 identities.setdefault(row['arm'],set()).update(ids)
assert len(identities['baseline'])==len(identities['candidate'])==1 and identities['baseline']!=identities['candidate']
rows=[]
for key in captures[('baseline',1)]:
 b=[captures[('baseline',i)][key]['median'] for i in [1,2,3]];c=[captures[('candidate',i)][key]['median'] for i in [1,2,3]]
 row={'case':key,'baselineMediansNs':b,'candidateMediansNs':c,'baselineMedianNs':statistics.median(b),'candidateMedianNs':statistics.median(c),'pairedRatios':[y/x for x,y in zip(b,c)]};rows.append(row)
 print(key,round(row['baselineMedianNs']/1000,3),round(row['candidateMedianNs']/1000,3),[round(r,4) for r in row['pairedRatios']])
(root/'sprite-region-summary.json').write_text(json.dumps({'rows':rows,'mvids':{k:list(v) for k,v in identities.items()}},indent=2)+'\n')
