import json, math, pathlib, statistics
root = pathlib.Path(__file__).resolve().parent / 'intmap-first-probe-result'
summary = {}
for runtime in ('net10','mono'):
    runs = []
    for index in range(1,4):
        receipt = json.loads((root / f'{runtime}-{index}.receipt.json').read_text())
        assert receipt['exit'] == 0 and receipt['stdout_eof'] and receipt['stderr_eof'] and receipt['sources_stable'] and receipt['payloads_stable'] and receipt['rows'] == 195 and receipt['distinct'] == 195
        rows = [json.loads(line) for line in (root / f'{runtime}-{index}.stdout.jsonl').read_text().splitlines()]
        runs.append({(r['shape'],r['size'],r['op'],r['arm']):r for r in rows})
    assert all(set(run) == set(runs[0]) for run in runs)
    cells=[]
    for shape,size,op,arm in sorted(runs[0]):
        if arm != 'IntMapCurrent': continue
        before=[run[(shape,size,op,'IntMapMain')]['median'] for run in runs]
        after=[run[(shape,size,op,'IntMapCurrent')]['median'] for run in runs]
        dictionary=[run[(shape,size,op,'Dictionary')]['median'] for run in runs]
        before_median=statistics.median(before); after_median=statistics.median(after)
        assert before_median > 0 and after_median > 0
        cells.append(dict(shape=shape,size=size,op=op,before=before,after=after,dictionary=dictionary,ratio=after_median/before_median,pairedRatios=[b/a for a,b in zip(before,after)]))
    lookups=[c['ratio'] for c in cells if c['op'] in ('hit','miss')]
    geomean=math.exp(statistics.mean(math.log(r) for r in lookups))
    slower=[c for c in cells if c['ratio']>1.10]
    summary[runtime]=dict(lookupGeomean=geomean,passes=geomean<=.95 and not slower,slowerCells=slower,cells=cells)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for runtime,r in summary.items():
    print(runtime,'lookup geomean',r['lookupGeomean'],'pass',r['passes'],'slower cells',len(r['slowerCells']))
    for c in r['slowerCells']: print(c['shape'],c['size'],c['op'],round(c['ratio'],3),[round(x,3) for x in c['pairedRatios']])
