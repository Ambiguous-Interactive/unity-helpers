from pathlib import Path
import json,re,statistics,xml.etree.ElementTree as ET,hashlib,zipfile,math
root=Path(__file__).resolve().parent
receipt=json.loads((root/'ink-paired-final-result.json').read_text())
assert len(receipt['results'])==6
files={};rows={};mvids={};caseids=None
for r in receipt['results']:
 assert r['healthy'] and r['exitCode']==0 and r['before']==r['after'] and r['rows']==4 and r['identities']==4
 path=root/f"ink-final-{r['arm']}-{r['index']}";key=f"{r['arm']}-{r['index']}"
 data=(path/'results.xml').read_bytes();xml=ET.fromstring(data)
 assert xml.get('result')=='Passed' and xml.get('failed')=='0' and xml.get('skipped')=='0'
 ids=sorted(c.get('fullname') for c in xml.iter('test-case'));assert len(ids)==59
 if caseids is None:caseids=ids
 assert ids==caseids
 raw=re.findall(r'^INK-ROWS .+', (path/'unity.log').read_text(errors='replace'), re.M); assert len(raw)==4
 for line in raw:
  m=re.fullmatch(r'INK-ROWS pattern=(\d+) calls=(\d+) mvid=([\w-]+) nanoseconds=(.*)',line);assert m
  numbers=list(map(float,m[4].strip().split(',')));assert len(numbers)==21 and all(math.isfinite(v) and v>0 for v in numbers)
  rows[r['arm'],r['index'],int(m[1])]=numbers;mvids.setdefault(r['arm'],set()).add(m[3])
 files[f'{key}/results.xml']=data
 files[f'{key}/rounds.log']=('\n'.join(raw)+'\n').encode()
 files[f'{key}/unity.execution-diagnostics.json']=(path/'unity.execution-diagnostics.json').read_bytes()
assert not mvids['baseline']&mvids['candidate']
summary=[]
for pattern in range(4):
 old=[statistics.median(rows['baseline',i,pattern]) for i in range(1,4)];new=[statistics.median(rows['candidate',i,pattern]) for i in range(1,4)]
 summary.append({'pattern':pattern,'baselineProcessMedianNanoseconds':old,'candidateProcessMedianNanoseconds':new,'pairedRatios':[b/a for a,b in zip(old,new)],'baselineMedianNanoseconds':statistics.median(old),'candidateMedianNanoseconds':statistics.median(new)})
for arm in ('baseline','candidate'):
 data=(root/f'SpriteInk.{arm}.cs').read_bytes();files[f'SpriteInk.{arm}.cs']=data
 expected={r['before'] for r in receipt['results'] if r['arm']==arm};assert expected=={hashlib.sha256(data).hexdigest().upper()}
for name in ('Tests/Runtime/Utils/SpriteInkRegionTests.cs','Tests/Runtime/Utils/SpriteInkRegionTimingTests.cs','Runtime/Utils/SpritePixelRegion.cs'):
 data=(root.parents[2]/name).read_bytes();assert all(r['otherSources'][name]==hashlib.sha256(data).hexdigest().upper() for r in receipt['results'])
 files['source/'+Path(name).name]=data
files['controller.ps1']=(root/'ink-paired-final.ps1').read_bytes()
files['controller-result.json']=(root/'ink-paired-final-result.json').read_bytes()
files['summary.json']=(json.dumps({'unity':'6000.6.7f1','backend':'Windows x64 Editor Mono','caseIds':caseids,'loadedModuleIds':{k:sorted(v) for k,v in mvids.items()},'measurements':summary},indent=2)+'\n').encode()
files['package-evidence.py']=Path(__file__).read_bytes()
files['README.txt']=b'''Extract into progress/.artifacts/ink-replay in an isolated checkout of af80061e. Copy source/SpriteInkRegionTests.cs and source/SpriteInkRegionTimingTests.cs into Tests/Runtime/Utils, generating metadata for the new file. Confirm source/SpritePixelRegion.cs matches Runtime/Utils/SpritePixelRegion.cs. Run controller.ps1 with native PowerShell and Unity 6000.6.7f1 installed. It alternates both root SpriteInk variants into Runtime/Utils/SpriteArtBounds.Ink.cs and restores the baseline in finally. Use a unique project path if the recorded temporary project is already in use. Native results are written to ink-final-* directories; retained original captures are in baseline-* and candidate-* directories. Rebuilding on a different checkout or host gives new module identities and measurements. The recorded performance applies only to the captured variants and environment.
'''
files['inventory.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())},indent=2)+'\n').encode()
out=root.parents[2]/'docs/performance/sprite-ink-traversal.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()): z.writestr(name,data)
with zipfile.ZipFile(out) as z:
 for name,data in files.items(): assert z.read(name)==data
print(json.dumps(summary,indent=2));print(out,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
