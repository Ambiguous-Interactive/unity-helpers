import argparse, hashlib, json, os, pathlib, shutil, subprocess, threading, time
root=pathlib.Path(__file__).resolve().parent
os.chdir(root)
parser=argparse.ArgumentParser();parser.add_argument('--runtime',choices=['net10','mono'],required=True);parser.add_argument('--processes',type=int,default=2);parser.add_argument('--first',type=int,default=1);parser.add_argument('--reuse-build',action='store_true');args=parser.parse_args()
sources=[*root.glob('src/*.cs'),root/'IntMapAb.csproj',root/'global.json',pathlib.Path(__file__)]
def hashes(paths):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes(sources)
if args.reuse_build:
 seal=json.loads((root/'seal.json').read_text())
 assert seal['sources']==before
else:
 assert not (root/'seal.json').exists()
 build=subprocess.run(['dotnet','build','IntMapAb.csproj','-c','Release','--nologo'],capture_output=True)
 (root/'build.stdout').write_bytes(build.stdout);(root/'build.stderr').write_bytes(build.stderr)
 if build.returncode:raise SystemExit(build.returncode)
 seal={'sources':before,'payloads':hashes(sorted(p for p in (root/'bin').rglob('*') if p.is_file()))}
 (root/'seal.json').write_text(json.dumps(seal,indent=2)+'\n')
assert seal['payloads']==hashes([root/p for p in seal['payloads']])
payload=root/('bin/Release/net10.0/IntMapAb.dll' if args.runtime=='net10' else 'bin/Release/net48/IntMapAb.exe')
command=[shutil.which('dotnet' if args.runtime=='net10' else 'mono'),str(payload),args.runtime]
for index in range(args.first,args.first+args.processes):
 prefix=root/f'{args.runtime}-{index}'
 assert not prefix.with_suffix('.receipt.json').exists()
 stdout=prefix.with_suffix('.stdout.jsonl');stderr=prefix.with_suffix('.stderr')
 start=time.monotonic();child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (root/'live.json').write_text(json.dumps({'controller':os.getpid(),'child':child.pid,'runtime':args.runtime,'index':index})+'\n')
 observed={}
 def drain(stream,path,key):
  with path.open('wb') as target:
   while True:
    data=stream.read(8192)
    if not data:break
    target.write(data);target.flush()
  observed[key]=True
 threads=[threading.Thread(target=drain,args=(child.stdout,stdout,'stdout_eof')),threading.Thread(target=drain,args=(child.stderr,stderr,'stderr_eof'))]
 for thread in threads:thread.start()
 code=child.wait()
 for thread in threads:thread.join(10)
 rows=[json.loads(line) for line in stdout.read_bytes().splitlines()]
 identities={(r['shape'],r['size'],r['op'],r['arm']) for r in rows}
 receipt={'runtime':args.runtime,'index':index,'pid':child.pid,'exit':code,'seconds':time.monotonic()-start,'rows':len(rows),'distinct':len(identities),**observed,'sources_stable':before==hashes(sources),'payloads_stable':seal['payloads']==hashes([root/p for p in seal['payloads']])}
 prefix.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 (root/'live.json').unlink()
 assert code==0 and observed.get('stdout_eof') is True and observed.get('stderr_eof') is True and len(rows)==195 and len(identities)==195 and receipt['sources_stable'] and receipt['payloads_stable'],receipt
