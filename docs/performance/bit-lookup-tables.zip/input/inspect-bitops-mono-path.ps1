$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.nuget/packages/mono.cecil/0.11.5/lib/netstandard2.0/Mono.Cecil.dll')
$module=[Mono.Cecil.ModuleDefinition]::ReadModule((Join-Path $PSScriptRoot 'bitops-candidate.dll'))
try {
 $type=$module.GetType('WallstopStudios.UnityHelpers.Core.Helper.BitOps')
 $names=@('MonoTrailingZeroIndices','MonoLog2UintIndices','MonoLog2UlongIndices')
 foreach($name in $names) { if(-not ($type.Fields | Where-Object { $_.Name -eq $name -and $_.IsStatic -and $_.IsInitOnly })) { throw "Missing Mono cache $name" } }
 $methods=@($type.Methods | Where-Object { ($_.Name -eq 'Log2' -and $_.Parameters[0].ParameterType.FullName -in @('System.UInt32','System.UInt64')) -or ($_.Name -eq 'TrailingZeroCount' -and $_.Parameters[0].ParameterType.FullName -eq 'System.UInt64') })
 if($methods.Count -ne 3) { throw 'Wrong lookup method count' }
 $records=@()
 foreach($method in $methods) {
  $loads=@($method.Body.Instructions | Where-Object { $_.OpCode.Name -eq 'ldsfld' -and $_.Operand.Name -in $names })
  if($loads.Count -ne 1) { throw "Lookup does not use exactly one Mono cache: $method" }
  if(@($method.Body.Instructions | Where-Object { $_.OpCode.Name -in @('newarr','box','newobj','call') }).Count -ne 0) { throw "Lookup has an allocating or indirect operation: $method" }
  $records+=@{method=$method.FullName;instructions=@($method.Body.Instructions | ForEach-Object { $_.ToString() })}
 }
 $initializer=$type.Methods | Where-Object { $_.Name -eq '.cctor' }
 @{mvid=$module.Mvid.ToString();assemblySha256=(Get-FileHash (Join-Path $PSScriptRoot 'bitops-candidate.dll') -Algorithm SHA256).Hash;fields=$names;lookups=$records;initializer=@($initializer.Body.Instructions | ForEach-Object { $_.ToString() })} | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $PSScriptRoot 'bitops-mono-cache-il.json')
} finally { $module.Dispose() }
