$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261112'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$source = Join-Path $repository 'Runtime/Core/Helper/BitOps.cs'
$variants = @{ baseline = (Join-Path $PSScriptRoot 'BitOps.baseline.cs'); candidate = (Join-Path $PSScriptRoot 'BitOps.mono-cache.candidate.cs') }
$otherSources = @('Runtime/Core/Helper/Objects.cs','Runtime/Core/DataStructure/HoldSet.cs','Runtime/Core/Threading/ThreadAmbient.cs','Tests/Runtime/Helper/BitOpsTests.cs','Tests/Runtime/Helper/BitOpsLookupTests.cs','Tests/Runtime/Helper/BitOpsLookupTimingTests.cs')
$identities = @{}
foreach ($relative in $otherSources) { $identities[$relative]=(Get-FileHash (Join-Path $repository $relative) -Algorithm SHA256).Hash }
$results = @()
try {
foreach ($index in 1..3) {
    foreach ($arm in @('baseline','candidate')) {
        foreach ($relative in $otherSources) { if ($identities[$relative] -ne (Get-FileHash (Join-Path $repository $relative) -Algorithm SHA256).Hash) { throw "A frozen input changed: $relative" } }
        [IO.File]::WriteAllBytes($source, [IO.File]::ReadAllBytes($variants[$arm]))
        $before = (Get-FileHash $source -Algorithm SHA256).Hash
        $artifacts = Join-Path $PSScriptRoot "bitops-mono-cache-final-$arm-$index"
        & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode playmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Runtime' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter 'WallstopStudios.UnityHelpers.Tests.Helper.BitOps' -TestCategory '!Stress' *> (Join-Path $PSScriptRoot "bitops-mono-cache-final-$arm-$index-driver.log")
        $exitCode = $LASTEXITCODE
        $after = (Get-FileHash $source -Algorithm SHA256).Hash
        $observation = Get-Content -LiteralPath (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
        [xml]$xml = Get-Content -LiteralPath (Join-Path $artifacts 'results.xml') -Raw
        $log = [string]::Join("`n", @($xml.SelectNodes('//test-case/output') | ForEach-Object { $_.InnerText }))
        $rowCount = [regex]::Matches($log,'(?m)^BIT-ROWS ').Count
        $identityCount = [regex]::Matches($log,'(?m)^BIT-ROWS .*mvid=[a-z0-9-]+ ').Count
        $healthy = $observation.Process.RawExitCode -eq 0 -and $observation.Process.StandardOutputEndObserved -and $observation.Process.StandardErrorEndObserved -and -not $observation.Process.OutputDrainStopped
        $assembly = Join-Path $project 'Library/ScriptAssemblies/WallstopStudios.UnityHelpers.dll'
        Copy-Item -LiteralPath $assembly -Destination (Join-Path $PSScriptRoot "bitops-$arm.dll") -Force
        $results += @{ arm=$arm;index=$index;exitCode=$exitCode;before=$before;after=$after;healthy=$healthy;rows=$rowCount;identities=$identityCount;assemblySha256=(Get-FileHash $assembly -Algorithm SHA256).Hash;otherSources=$identities }
        $results | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'bitops-paired-mono-cache-final-live.json')
        if ($exitCode -ne 0 -or $after -ne $before -or -not $healthy -or $rowCount -ne 6 -or $identityCount -ne 6) { throw "Capture $arm/$index lacks healthy, complete timing evidence." }
    }
}
@{ completedUtc=[DateTime]::UtcNow;results=$results } | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'bitops-paired-mono-cache-final-result.json')

} finally { [IO.File]::WriteAllBytes($source, [IO.File]::ReadAllBytes($variants.candidate)) }
