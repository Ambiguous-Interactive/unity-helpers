$ErrorActionPreference='Stop'
$cecil=Join-Path ([Environment]::GetFolderPath('UserProfile')) '.nuget/packages/mono.cecil/0.11.5/lib/netstandard2.0/Mono.Cecil.dll'
Add-Type -Path $cecil
$module=[Mono.Cecil.ModuleDefinition]::ReadModule((Join-Path $PSScriptRoot 'bitops-candidate.dll'))
try {
    $type=$module.GetType('WallstopStudios.UnityHelpers.Core.Helper.BitOps')
    if ($null -eq $type) { throw 'Missing measured BitOps type' }
    $records=@()
    foreach($name in @('get_TrailingZeroIndices','get_Log2UintIndices','get_Log2UlongIndices')) {
        $method=$type.Methods | Where-Object { $_.Name -eq $name }
        if ($null -eq $method -or -not $method.HasBody) { throw "Missing span getter $name" }
        $operations=@($method.Body.Instructions | ForEach-Object { $_.OpCode.Name })
        if ($operations -contains 'newarr' -or $operations -contains 'box' -or $operations -contains 'ldsfld') { throw "Getter $name allocates or reads a cached array" }
        if (-not ($operations -contains 'ldsflda' -or $operations -contains 'ldtoken')) { throw "Getter $name lacks constant data identity" }
        $records += @{method=$name;instructions=@($method.Body.Instructions | ForEach-Object { $_.ToString() })}
    }
    @{assemblySha256=(Get-FileHash (Join-Path $PSScriptRoot 'bitops-candidate.dll') -Algorithm SHA256).Hash;mvid=$module.Mvid.ToString();getters=$records} | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'bitops-constant-data-il.json')
} finally { $module.Dispose() }
