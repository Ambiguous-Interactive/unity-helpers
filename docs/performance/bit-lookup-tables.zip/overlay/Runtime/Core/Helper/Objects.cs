// MIT License - Copyright (c) 2023 wallstop
// Full license text: https://github.com/wallstop/unity-helpers/blob/main/LICENSE

namespace WallstopStudios.UnityHelpers.Core.Helper
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Security.Cryptography;
    using Extension;

    /// <summary>
    /// Utilities for null checks (including UnityEngine.Object overloads) and hash code composition.
    /// </summary>
    /// <remarks>
    /// The <c>HashCode</c> family mixes its arguments with a fixed FNV-1a step, but each argument
    /// contributes its ordinary <see cref="object.GetHashCode"/> value -- which is randomized per
    /// process for <see cref="string"/>, is a session-local instance id for a
    /// <see cref="UnityEngine.Object"/>, and is whatever the author wrote for any other type.
    /// Destroyed Unity objects keep their instance hash; only managed null contributes no value.
    /// The composed result is therefore a hash code: valid for dictionaries and sets inside one process,
    /// and not a value to persist, compare across processes or put on a wire. For a value that
    /// survives all three, hash bytes you control with <see cref="StableHash32V1"/>.
    /// </remarks>
    public static class Objects
    {
        /// <summary>
        /// The standard 32-bit FNV-1a offset basis, the conventional seed for
        /// <see cref="StableHash32V1"/>.
        /// </summary>
        public const uint Fnv32OffsetBasis = 2166136261u;

        /// <summary>The standard 64-bit FNV-1a offset basis.</summary>
        public const ulong Fnv64OffsetBasis = 14695981039346656037UL;

        private const ulong Fnv64Prime = 1099511628211UL;

        private const uint Fnv32Prime = 16777619u;

        private const string HexDigits = "0123456789abcdef";

        /// <summary>
        /// Unity-aware null check for UnityEngine.Object types (handles destroyed objects returning true for == null).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Null<T>(T instance)
            where T : UnityEngine.Object
        {
            return instance == null;
        }

        /// <summary>
        /// Hybrid null check for boxed or unknown objects (handles UnityEngine.Object special null semantics).
        /// </summary>
        public static bool Null(object instance)
        {
            if (instance is null)
            {
                return true;
            }

            if (instance is UnityEngine.Object unityObject)
            {
                return unityObject == null;
            }

            return false;
        }

        /// <summary>
        /// Unity-aware not-null check for UnityEngine.Object types.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool NotNull<T>(T instance)
            where T : UnityEngine.Object
        {
            return instance != null;
        }

        /// <summary>
        /// Hybrid not-null check for boxed or unknown objects.
        /// </summary>
        public static bool NotNull(object instance)
        {
            return !Null(instance);
        }

        /// <summary>
        /// Combines hash codes for a span of values into one composite hash code. Process-local, like
        /// every value it mixes; see the remarks on <see cref="Objects"/>.
        /// </summary>
        public static int SpanHashCode<T>(ReadOnlySpan<T> values)
        {
            if (values.IsEmpty)
            {
                return 0;
            }

            HashCodeBuilder hash = default;
            foreach (ref readonly T value in values)
            {
                hash.Add(value);
            }

            return hash.ToHashCode();
        }

        /// <summary>
        /// Combines one value into a composite hash code. Process-local, like every value it mixes;
        /// see the remarks on <see cref="Objects"/>.
        /// </summary>
        public static int HashCode<T1>(T1 param1)
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            return hash.ToHashCode();
        }

        /// <summary>
        /// Combines two values into a composite hash code. Process-local, like every value it mixes;
        /// see the remarks on <see cref="Objects"/>.
        /// </summary>
        public static int HashCode<T1, T2>(T1 param1, T2 param2)
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3>(T1 param1, T2 param2, T3 param3)
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4>(T1 param1, T2 param2, T3 param3, T4 param4)
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8, T9>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            return hash.ToHashCode();
        }

        public static int HashCode<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            return hash.ToHashCode();
        }

        public static int HashCode<
            T1,
            T2,
            T3,
            T4,
            T5,
            T6,
            T7,
            T8,
            T9,
            T10,
            T11,
            T12,
            T13,
            T14,
            T15
        >(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14,
            T15 param15
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            hash.Add(param15);
            return hash.ToHashCode();
        }

        public static int HashCode<
            T1,
            T2,
            T3,
            T4,
            T5,
            T6,
            T7,
            T8,
            T9,
            T10,
            T11,
            T12,
            T13,
            T14,
            T15,
            T16
        >(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14,
            T15 param15,
            T16 param16
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            hash.Add(param15);
            hash.Add(param16);
            return hash.ToHashCode();
        }

        public static int HashCode<
            T1,
            T2,
            T3,
            T4,
            T5,
            T6,
            T7,
            T8,
            T9,
            T10,
            T11,
            T12,
            T13,
            T14,
            T15,
            T16,
            T17
        >(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14,
            T15 param15,
            T16 param16,
            T17 param17
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            hash.Add(param15);
            hash.Add(param16);
            hash.Add(param17);
            return hash.ToHashCode();
        }

        public static int HashCode<
            T1,
            T2,
            T3,
            T4,
            T5,
            T6,
            T7,
            T8,
            T9,
            T10,
            T11,
            T12,
            T13,
            T14,
            T15,
            T16,
            T17,
            T18
        >(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14,
            T15 param15,
            T16 param16,
            T17 param17,
            T18 param18
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            hash.Add(param15);
            hash.Add(param16);
            hash.Add(param17);
            hash.Add(param18);
            return hash.ToHashCode();
        }

        public static int HashCode<
            T1,
            T2,
            T3,
            T4,
            T5,
            T6,
            T7,
            T8,
            T9,
            T10,
            T11,
            T12,
            T13,
            T14,
            T15,
            T16,
            T17,
            T18,
            T19
        >(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14,
            T15 param15,
            T16 param16,
            T17 param17,
            T18 param18,
            T19 param19
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            hash.Add(param15);
            hash.Add(param16);
            hash.Add(param17);
            hash.Add(param18);
            hash.Add(param19);
            return hash.ToHashCode();
        }

        public static int HashCode<
            T1,
            T2,
            T3,
            T4,
            T5,
            T6,
            T7,
            T8,
            T9,
            T10,
            T11,
            T12,
            T13,
            T14,
            T15,
            T16,
            T17,
            T18,
            T19,
            T20
        >(
            T1 param1,
            T2 param2,
            T3 param3,
            T4 param4,
            T5 param5,
            T6 param6,
            T7 param7,
            T8 param8,
            T9 param9,
            T10 param10,
            T11 param11,
            T12 param12,
            T13 param13,
            T14 param14,
            T15 param15,
            T16 param16,
            T17 param17,
            T18 param18,
            T19 param19,
            T20 param20
        )
        {
            HashCodeBuilder hash = default;
            hash.Add(param1);
            hash.Add(param2);
            hash.Add(param3);
            hash.Add(param4);
            hash.Add(param5);
            hash.Add(param6);
            hash.Add(param7);
            hash.Add(param8);
            hash.Add(param9);
            hash.Add(param10);
            hash.Add(param11);
            hash.Add(param12);
            hash.Add(param13);
            hash.Add(param14);
            hash.Add(param15);
            hash.Add(param16);
            hash.Add(param17);
            hash.Add(param18);
            hash.Add(param19);
            hash.Add(param20);
            return hash.ToHashCode();
        }

        /// <summary>
        /// Combines hash codes for all elements in an enumerable (with optimized paths for common
        /// collection types). Process-local, like every value it mixes; see the remarks on
        /// <see cref="Objects"/>.
        /// </summary>
        public static int EnumerableHashCode<T>(IEnumerable<T> enumerable)
        {
            if (ReferenceEquals(enumerable, null))
            {
                return 0;
            }

            HashCodeBuilder hash = default;
            switch (enumerable)
            {
                case IReadOnlyList<T> list:
                {
                    for (int i = 0; i < list.Count; ++i)
                    {
                        hash.Add(list[i]);
                    }

                    break;
                }
                case HashSet<T> hashSet:
                {
                    foreach (T item in hashSet)
                    {
                        hash.Add(item);
                    }

                    break;
                }
                case Queue<T> queue:
                {
                    foreach (T item in queue)
                    {
                        hash.Add(item);
                    }

                    break;
                }
                case Stack<T> stack:
                {
                    foreach (T item in stack)
                    {
                        hash.Add(item);
                    }

                    break;
                }
                case SortedSet<T> sortedSet:
                {
                    foreach (T item in sortedSet)
                    {
                        hash.Add(item);
                    }

                    break;
                }
                default:
                {
                    foreach (T item in enumerable.AsValueEnumerableRequired())
                    {
                        hash.Add(item);
                    }

                    break;
                }
            }

            return hash.ToHashCode();
        }

        /// <summary>
        /// Computes a 32-bit FNV-1a hash over exactly the supplied bytes, using
        /// <paramref name="seed"/> as the initial state.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Unlike the <c>HashCode</c> family, this depends on nothing but its arguments. The same
        /// bytes and the same seed produce the same value in every process, on every platform, and
        /// in every later version of this package: the algorithm is frozen, which is what the
        /// <c>V1</c> names. A different algorithm would arrive as a differently named method, never
        /// as a new answer from this one. That makes it safe for save-file digests, content
        /// addressing and cross-machine agreement.
        /// </para>
        /// <para>
        /// It hashes bytes and only bytes. Encode text yourself -- <see cref="StringExtensions.GetBytes(string)"/>
        /// is the usual choice -- so the encoding is part of your format rather than an assumption
        /// of this one.
        /// </para>
        /// </remarks>
        /// <param name="bytes">The bytes to hash. An empty span returns <paramref name="seed"/> unchanged.</param>
        /// <param name="seed">The initial state. Pass <see cref="Fnv32OffsetBasis"/> for standard FNV-1a.</param>
        /// <returns>The FNV-1a hash of <paramref name="bytes"/> starting from <paramref name="seed"/>.</returns>
        /// <example>
        /// <code><![CDATA[
        /// byte[] payload = saveSlotName.GetBytes();
        /// uint digest = Objects.StableHash32V1(payload, Objects.Fnv32OffsetBasis);
        /// ]]></code>
        /// </example>
        public static uint StableHash32V1(ReadOnlySpan<byte> bytes, uint seed)
        {
            uint hash = seed;
            foreach (byte value in bytes)
            {
                hash ^= value;
                hash *= Fnv32Prime;
            }

            return hash;
        }

        /// <summary>Computes a versioned 64-bit FNV-1a hash over the supplied bytes.</summary>
        /// <param name="bytes">The bytes to hash; an empty span returns the seed.</param>
        /// <param name="seed">The initial state, conventionally <see cref="Fnv64OffsetBasis"/>.</param>
        /// <returns>The unsigned 64-bit hash.</returns>
        /// <remarks>The algorithm is frozen across platforms and package versions. Encode text as UTF-8 for interoperable text hashes. This is not a cryptographic hash.</remarks>
        public static ulong StableHash64V1(ReadOnlySpan<byte> bytes, ulong seed = Fnv64OffsetBasis)
        {
            ulong hash = seed;
            foreach (byte value in bytes)
            {
                hash = unchecked((hash ^ value) * Fnv64Prime);
            }

            return hash;
        }

        /// <summary>Appends an Int32's four little-endian two's-complement bytes to a stable hash.</summary>
        /// <remarks>The result equals hashing those bytes with <paramref name="hash"/> as the seed, without a temporary buffer.</remarks>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ulong AppendStableHash64V1(ulong hash, int value)
        {
            uint remaining = unchecked((uint)value);
            for (int index = 0; index < sizeof(int); ++index)
            {
                hash = unchecked((hash ^ (byte)remaining) * Fnv64Prime);
                remaining >>= 8;
            }
            return hash;
        }

        /// <summary>Appends an Int64's eight little-endian two's-complement bytes to a stable hash.</summary>
        /// <remarks>The result equals hashing those bytes with <paramref name="hash"/> as the seed, without a temporary buffer.</remarks>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ulong AppendStableHash64V1(ulong hash, long value)
        {
            ulong remaining = unchecked((ulong)value);
            for (int index = 0; index < sizeof(long); ++index)
            {
                hash = unchecked((hash ^ (byte)remaining) * Fnv64Prime);
                remaining >>= 8;
            }
            return hash;
        }

        /// <summary>Hashes raw UTF-16 code units as little-endian bytes with the frozen 64-bit FNV-1a algorithm.</summary>
        /// <remarks>
        /// No encoding buffer, normalization, surrogate replacement, or terminating null is used.
        /// Empty input returns the seed. The explicit name keeps existing byte-span calls unambiguous.
        /// This differs from UTF-8 text hashing and is not cryptographic.
        /// </remarks>
        public static ulong StableHashUtf16Le64V1(
            ReadOnlySpan<char> text,
            ulong seed = Fnv64OffsetBasis
        )
        {
            ulong hash = seed;
            foreach (char character in text)
            {
                hash = unchecked((hash ^ (byte)character) * Fnv64Prime);
                hash = unchecked((hash ^ (byte)(character >> 8)) * Fnv64Prime);
            }
            return hash;
        }

        /// <summary>Folds each unsigned word into one frozen 64-bit FNV-1a multiply step.</summary>
        /// <remarks>
        /// Empty input returns the seed. This hashes whole words, not their bytes, and gives different results
        /// from StableHash64V1. High-bit differences never reach lower bits, so this weak, noncryptographic
        /// fold must not be treated as a general-purpose content digest. Future algorithms use other names.
        /// </remarks>
        public static ulong Fnv1aWordFold64(
            ReadOnlySpan<ulong> words,
            ulong seed = Fnv64OffsetBasis
        )
        {
            ulong hash = seed;
            foreach (ulong word in words)
            {
                hash = unchecked((hash ^ word) * Fnv64Prime);
            }
            return hash;
        }

        /// <summary>Folds signed words by their two's-complement bit patterns with the frozen word-fold algorithm.</summary>
        /// <remarks>Shares the weak mixing and seed contract of <see cref="Fnv1aWordFold64(ReadOnlySpan{ulong}, ulong)"/>.</remarks>
        public static ulong Fnv1aWordFold64(ReadOnlySpan<long> words, ulong seed = Fnv64OffsetBasis)
        {
            ulong hash = seed;
            foreach (long word in words)
            {
                hash = unchecked((hash ^ (ulong)word) * Fnv64Prime);
            }
            return hash;
        }

        /// <summary>
        /// Computes the SHA-256 digest of <paramref name="text"/> as a lowercase hex string.
        /// </summary>
        /// <param name="text">The text to hash. Encoded as UTF-8 before hashing.</param>
        /// <returns>The 64-character lowercase hexadecimal SHA-256 digest.</returns>
        /// <remarks>
        /// <para>
        /// Unlike the <c>HashCode</c> family and <see cref="StableHash32V1"/>, SHA-256 is
        /// cryptographic: it is for content identity, cache keys and tamper detection, not for
        /// hash buckets. The answer depends only on the bytes of <paramref name="text"/>.
        /// </para>
        /// <para>
        /// UTF-8 is the encoding, and it is frozen. A <see cref="string"/> is UTF-16 in memory, so
        /// hashing that representation would produce a digest no other tool agrees with; encoding
        /// as UTF-8 first is what makes this digest interoperable. Hash bytes yourself with the
        /// <c>byte[]</c> overload when the encoding is part of your format.
        /// </para>
        /// </remarks>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="text"/> is null.</exception>
        public static string Sha256Hex(string text)
        {
            if (text == null)
            {
                throw new ArgumentNullException(nameof(text));
            }

            return Sha256Hex(text.GetBytes());
        }

        /// <summary>
        /// Computes the SHA-256 digest of <paramref name="bytes"/> as a lowercase hex string.
        /// </summary>
        /// <param name="bytes">The bytes to hash. Not mutated.</param>
        /// <returns>The 64-character lowercase hexadecimal SHA-256 digest.</returns>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="bytes"/> is null.</exception>
        public static string Sha256Hex(byte[] bytes)
        {
            if (bytes == null)
            {
                throw new ArgumentNullException(nameof(bytes));
            }

            using SHA256 sha256 = SHA256.Create();
            byte[] digest = sha256.ComputeHash(bytes);
            return ToHex(digest);
        }

        /// <summary>
        /// Computes the SHA-256 digest of a file's contents as a lowercase hex string.
        /// </summary>
        /// <param name="filePath">The path of the file to hash.</param>
        /// <param name="hex">
        /// When this method returns true, the 64-character lowercase hexadecimal SHA-256 digest of
        /// the file's contents. When it returns false, null.
        /// </param>
        /// <returns>
        /// True when the file was read and hashed; false when <paramref name="filePath"/> is null
        /// or whitespace, or when the file does not exist or cannot be read.
        /// </returns>
        public static bool TrySha256HexOfFile(string filePath, out string hex)
        {
            if (string.IsNullOrWhiteSpace(filePath))
            {
                hex = null;
                return false;
            }

            try
            {
                using FileStream stream = File.OpenRead(filePath);
                using SHA256 sha256 = SHA256.Create();
                byte[] digest = sha256.ComputeHash(stream);
                hex = ToHex(digest);
                return true;
            }
            catch
            {
                hex = null;
                return false;
            }
        }

        private static string ToHex(byte[] digest)
        {
            int digestLength = digest.Length;
            char[] hex = new char[digestLength * 2];
            for (int i = 0; i < digestLength; ++i)
            {
                hex[i * 2] = HexDigits[digest[i] >> 4];
                hex[(i * 2) + 1] = HexDigits[digest[i] & 0xF];
            }

            return new string(hex);
        }

        private struct HashCodeBuilder
        {
            private const uint Seed = Fnv32OffsetBasis;
            private const uint Prime = Fnv32Prime;

            private uint _hash;
            private bool _hasContribution;
            private bool _hasNonNullContribution;

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void Add<T>(T value)
            {
                uint valueHash = TypeTraits<T>.GetValueHash(value, out bool hasNonNullValue);

                if (!_hasContribution)
                {
                    // Defer seeding until the first value is observed so empty hashes stay at 0.
                    _hash = Seed;
                    _hasContribution = true;
                }

                _hash ^= valueHash;
                _hash *= Prime;

                if (hasNonNullValue)
                {
                    _hasNonNullContribution = true;
                }
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public int ToHashCode()
            {
                if (!_hasContribution || !_hasNonNullContribution)
                {
                    return 0;
                }

                return unchecked((int)_hash);
            }
        }

        private static class TypeTraits<T>
        {
            private const uint NullSentinel = 0x9E3779B9u;

            private static readonly EqualityComparer<T> EqualityComparer =
                EqualityComparer<T>.Default;

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public static uint GetValueHash(T value, out bool hasNonNullValue)
            {
                if (ObjectsTypeTraits<T>.IsValueType)
                {
                    hasNonNullValue = true;
                    return unchecked((uint)EqualityComparer.GetHashCode(value));
                }

                if (ObjectsTypeTraits<T>.IsObjectType)
                {
                    return GetBoxedObjectHash(value, out hasNonNullValue);
                }

                if (ObjectsTypeTraits<T>.IsUnityObject)
                {
                    return GetUnityObjectHash(value, out hasNonNullValue);
                }

                if (ReferenceEquals(value, null))
                {
                    hasNonNullValue = false;
                    return NullSentinel;
                }

                hasNonNullValue = true;
                return unchecked((uint)EqualityComparer.GetHashCode(value));
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            private static uint GetUnityObjectHash(T value, out bool hasNonNullValue)
            {
                UnityEngine.Object unityObject = value as UnityEngine.Object;

                if (ReferenceEquals(unityObject, null))
                {
                    hasNonNullValue = false;
                    return NullSentinel;
                }

                hasNonNullValue = true;
                return unchecked((uint)unityObject.GetHashCode());
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            private static uint GetBoxedObjectHash(T value, out bool hasNonNullValue)
            {
                object boxed = value;

                if (boxed is null)
                {
                    hasNonNullValue = false;
                    return NullSentinel;
                }

                hasNonNullValue = true;
                return unchecked((uint)EqualityComparer<object>.Default.GetHashCode(boxed));
            }
        }
    }
}
