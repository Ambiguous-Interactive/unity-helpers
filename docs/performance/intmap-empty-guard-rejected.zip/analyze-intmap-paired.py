from pathlib import Path
import json, statistics
root=Path(__file__).resolve().parent/'intmap-empty-paired-result'
rows=[]
for runtime in ['net10','mono']:
 captures=[]
 for index in range(1,4):
  receipt=json.loads((root/f'{runtime}-{index}.receipt.json').read_text());assert receipt['exit']==0 and all(receipt[k] for k in ['stdout_eof','stderr_eof','sources_stable','payloads_stable'])
  cells=[json.loads(line) for line in (root/f'{runtime}-{index}.stdout.jsonl').read_text().splitlines()]; assert len(cells)==159
  captures.append({(r['shape'],r['size'],r['op'],r['arm']):r for r in cells})
 keys=sorted({k[:3] for k in captures[0]})
 for key in keys:
  entry={'runtime':runtime,'shape':key[0],'size':key[1],'op':key[2]}
  for metric in ['min','median']:
   ratios=[c[(*key,'IntMapCurrent')][metric]/c[(*key,'IntMapMain')][metric] for c in captures]
   entry[metric+'Ratios']=ratios;entry[metric+'Ratio']=statistics.median(ratios)
  rows.append(entry)
out=root.parent/'intmap-empty-paired-analysis.json';out.write_text(json.dumps(rows,indent=2)+'\n')
for runtime in ['net10','mono']:
 for op in sorted({r['op'] for r in rows}):
  subset=[r for r in rows if r['runtime']==runtime and r['op']==op]
  print(runtime,op,'median ratio range',round(min(r['medianRatio'] for r in subset),3),round(max(r['medianRatio'] for r in subset),3))
print('robust regressions >5%')
for r in rows:
 if min(r['medianRatios'])>1.05:print(r)
