from pathlib import Path
import hashlib,json,re,statistics,zipfile,xml.etree.ElementTree as E
root=Path(__file__).resolve().parent
old='WallstopStudios.UnityHelpers.Tests.Utils.SingletonAssetPollutionPreventionTests.'
new='WallstopStudios.UnityHelpers.Tests.Utils.SingletonAssetProtectionPathTests.'
methods={'IsProtectedPathReturnsExpectedValue','IsKnownDuplicatePollutionReturnsExpectedValue'}
results=[];inventory=None;files={}
receipt=json.loads((root/'editmode-paths-paired-result.json').read_text());assert len(receipt['results'])==6
for r in receipt['results']:
 assert r['exitCode']==0 and r['healthy'] and r['stable']
 arm=r['arm'];index=r['index'];p=root/f'editmode-paths-{arm}-{index}/results.xml';tree=E.parse(p).getroot()
 assert tree.attrib['total']=='43' and tree.attrib['passed']=='43' and tree.attrib['failed']=='0' and tree.attrib['skipped']=='0'
 nodes=list(tree.iter('test-case'));assert len(nodes)==43 and all(n.attrib['result']=='Passed' for n in nodes)
 names=sorted(n.attrib['fullname'].replace(new,old) for n in nodes);assert len(set(names))==43
 if inventory is None:inventory=names
 else:assert inventory==names
 pure=[n for n in nodes if n.attrib.get('methodname') in methods];assert len(pure)==30
 results.append({'arm':arm,'index':index,'totalSeconds':float(tree.attrib['duration']),'pureCaseSeconds':sum(float(n.attrib['duration']) for n in pure)})
 files[f'capture/{p.parent.name}/results.xml']=p.read_bytes()
 files[f'capture/{p.parent.name}/unity.execution-diagnostics.json']=p.with_name('unity.execution-diagnostics.json').read_bytes()
files['case-inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
files['summary.json']=(json.dumps(results,indent=2)+'\n').encode()
for name in ['SingletonAssetPollutionPreventionTests.baseline.cs','SingletonAssetPollutionPreventionTests.candidate.cs','SingletonAssetProtectionPathTests.candidate.cs','ProtectedPathTestCase.candidate.cs','editmode-paths-paired.ps1','editmode-paths-paired-result.json','package-editmode-paths.py']:
 files['input/'+name]=root.joinpath(name).read_bytes()
files['input/CommonTestBase.cs']=Path('Tests/Core/CommonTestBase.cs').read_bytes()
files['README.txt']=b'''EditMode pure path case extraction, Windows x64 Unity6000.6.7f1, 2026-11-12.
Baseline: main af80061e SingletonAssetPollutionPreventionTests, 43 cases. Candidate moves ONLY the 15-case source, two assertion methods and their data model into separate files. New fixture does not inherit CommonTestBase. The 13 real asset integration cases retain their original fixture, setup and cleanup. The existing path classifier uses only string logic and was not changed.
All six fresh Unity processes pass exactly43 cases, no skips/failures/suite failures, exit0 and both outputEOFs withoutdrain stop. Canonical testcase fullnames, including inputs and descriptions, are equal after only renaming the new fixture prefix. Every method and expected-value case is retained. Loaded test DLL hashes and before/after source hashes are in the controller receipt. The native process receipts and complete NUnit XML are retained.
The 30 moved case durations sum to 1.368288/1.368384/1.364676 seconds before and 0.001961/0.002715/0.001734 seconds after. Root suite durations are 10.8723134/9.6695217/10.5574745 seconds before and 8.0780348/10.995152/8.6666372 after. One whole-cohort pair regresses; asset cleanup and startup remain variable. No full-CI EditMode or whole-process speed guarantee follows.
REPLAY: use an isolated checkout of main af80061e with this session's runtime/tests in place, retain input snapshots under progress/.artifacts/replay-paths, and run input/editmode-paths-paired.ps1 from that folder using native PowerShell. It alternates six isolated Unity processes via scripts/unity/run-ci-tests.ps1 and restores candidate source files in finally. Adjust the owned project folder and Unity path/version for your installation. Copy/generate the two new file metas alongside the snapshots first; the controller expects <newfile>.candidate.meta. Their GUIDs do not affect cases. The controller's repository offset assumes progress/.artifacts/replay-paths, and its artifact names remain the recorded names. Use a fresh artifact directory, never a personal Unity project.
'''
for name in ['SingletonAssetProtectionPathTests.cs.candidate.meta','ProtectedPathTestCase.cs.candidate.meta']:
 files['input/'+name]=root.joinpath(name).read_bytes()
files['inventory.json']=(json.dumps({n:hashlib.sha256(d).hexdigest() for n,d in sorted(files.items())},indent=2)+'\n').encode()
out=Path('docs/performance/editmode-path-fixtures.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out) as z:
 for name,data in files.items():assert z.read(name)==data
(root/'editmode-paths-summary.json').write_bytes(files['summary.json'])
print(json.dumps({'totalMedian':{a:statistics.median(r['totalSeconds'] for r in results if r['arm']==a) for a in ['baseline','candidate']},'pureMedian':{a:statistics.median(r['pureCaseSeconds'] for r in results if r['arm']==a) for a in ['baseline','candidate']},'zipBytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
