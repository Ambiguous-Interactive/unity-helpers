$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$project = Join-Path ([IO.Path]::GetTempPath()) 'uh-session-20261112'
$pwsh = Join-Path $env:USERPROFILE 'scoop/apps/pwsh/current/pwsh.exe'
$folder = Join-Path $repository 'Tests/Editor/Utils'
$original = 'SingletonAssetPollutionPreventionTests.cs'
$added = @('SingletonAssetProtectionPathTests.cs','ProtectedPathTestCase.cs')
$results = @()
function Restore-Candidate {
    foreach ($name in (@($original) + $added)) { [IO.File]::WriteAllBytes((Join-Path $folder $name),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $name.Replace('.cs','.candidate.cs')))) }
    foreach ($name in $added) { [IO.File]::WriteAllBytes((Join-Path $folder "$name.meta"),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "$name.candidate.meta"))) }
}
try {
foreach ($index in 1..3) {
foreach ($arm in @('baseline','candidate')) {
    Restore-Candidate
    if ($arm -eq 'baseline') {
        [IO.File]::WriteAllBytes((Join-Path $folder $original),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'SingletonAssetPollutionPreventionTests.baseline.cs')))
        foreach ($name in $added) { Remove-Item -LiteralPath (Join-Path $folder $name); Remove-Item -LiteralPath (Join-Path $folder "$name.meta") }
    }
    $sources = @((Join-Path $folder $original),(Join-Path $repository 'Tests/Core/CommonTestBase.cs'))
    if ($arm -eq 'candidate') { $sources += @($added | ForEach-Object { Join-Path $folder $_ }) }
    $before = @($sources | ForEach-Object { @{ path=$_;sha256=(Get-FileHash $_ -Algorithm SHA256).Hash } })
    $artifacts = Join-Path $PSScriptRoot "editmode-paths-$arm-$index"
    & $pwsh -NoProfile -File (Join-Path $repository 'scripts/unity/run-ci-tests.ps1') -UnityVersion '6000.6.7f1' -TestMode editmode -AssemblyNames 'WallstopStudios.UnityHelpers.Tests.Editor.Utils' -RepoRoot $repository -ProjectPath $project -ArtifactsPath $artifacts -UnityEditorPath (Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor/6000.6.7f1/Editor/Unity.exe') -TestFilter 'WallstopStudios.UnityHelpers.Tests.Utils.SingletonAssetPollutionPreventionTests;WallstopStudios.UnityHelpers.Tests.Utils.SingletonAssetProtectionPathTests' -TestCategory '!Performance;!Stress' *> (Join-Path $PSScriptRoot "editmode-paths-$arm-$index-driver.log")
    $exitCode=$LASTEXITCODE
    $observation = Get-Content -LiteralPath (Join-Path $artifacts 'unity.execution-diagnostics.json') -Raw | ConvertFrom-Json
    $healthy=$observation.Process.RawExitCode -eq 0 -and $observation.Process.StandardOutputEndObserved -and $observation.Process.StandardErrorEndObserved -and -not $observation.Process.OutputDrainStopped
    $after = @($sources | ForEach-Object { @{ path=$_;sha256=(Get-FileHash $_ -Algorithm SHA256).Hash } })
    $stable = ($before | ConvertTo-Json -Compress) -eq ($after | ConvertTo-Json -Compress)
    $assembly = Join-Path $project 'Library/ScriptAssemblies/WallstopStudios.UnityHelpers.Tests.Editor.Utils.dll'
    Copy-Item -LiteralPath $assembly -Destination (Join-Path $PSScriptRoot "editmode-paths-$arm.dll") -Force
    $results += @{arm=$arm;index=$index;exitCode=$exitCode;healthy=$healthy;stable=$stable;before=$before;after=$after;assemblySha256=(Get-FileHash $assembly -Algorithm SHA256).Hash}
    $results | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'editmode-paths-paired-live.json')
    if ($exitCode -ne 0 -or -not $healthy -or -not $stable) { throw "Invalid capture $arm/$index" }
}
}
@{ completedUtc=[DateTime]::UtcNow;results=$results } | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $PSScriptRoot 'editmode-paths-paired-result.json')
} finally { Restore-Candidate }
