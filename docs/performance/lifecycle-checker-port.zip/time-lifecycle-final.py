import hashlib,json,re,subprocess,time
from pathlib import Path
out=Path(__file__).parent
sources=sorted(Path('Tests').rglob('*.cs'))
def identity():return {p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
before=identity();rows=[]
commands={'original':['pwsh','-NoProfile','-File',str(out/'lint-tests-original.ps1'),'-VerboseOutput'],'python':['uv','run','--quiet','--project','scripts/python~','--locked','--no-dev','python','scripts/lint_tests.py','--verbose']}
for index,arms in enumerate([['original','python'],['python','original'],['original','python']],1):
 for arm in arms:
  assert identity()==before
  start=time.perf_counter();result=subprocess.run(commands[arm],capture_output=True,timeout=300);elapsed=time.perf_counter()-start
  (out/f'lifecycle-final-{arm}-{index}.log').write_bytes(result.stdout+result.stderr)
  findings=sorted((m[1].strip(),int(m[2]),m[3]) for m in re.finditer(r'(?m)^\s*(Tests/[^\r\n]*?):(\d+): (UNH\d+)\b',result.stdout.decode('utf-8')))
  assert result.returncode==0 and len(findings)>0 and identity()==before
  if rows: assert findings==rows[0]['findings'],(arm,'diagnostics changed')
  rows.append(dict(index=index,arm=arm,seconds=elapsed,exit=result.returncode,findings=findings));print(arm,index,elapsed,len(findings),flush=True)
  (out/'lifecycle-final-timing.json').write_text(json.dumps(dict(sources=before,results=rows),indent=2)+'\n')
