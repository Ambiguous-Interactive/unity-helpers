# PositionalBinding = $false so a stray value cannot be captured by a named parameter before
# the ValueFromRemainingArguments sibling sees it. With it on -- the default -- the sibling
# only works when every other parameter is a switch, which is an accident of this param list
# rather than a property of it (#556).
[CmdletBinding(PositionalBinding = $false)]
Param(
  [switch]$VerboseOutput,
  [string[]]$Paths,
  [switch]$FixNullChecks,
  # `pwsh -File <script> -Paths a b c` binds ONLY `a` to -Paths and silently drops the rest, so a
  # multi-file invocation scans one file and reports success. This catches the remainder; see
  # .llm/skills/bash-pwsh-invocation.md.
  [Parameter(ValueFromRemainingArguments = $true)]
  [string[]]$AdditionalPaths
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# The remaining-args catch above is only half of it: the two have to be merged before anything
# reads $Paths, or the extra files are collected and ignored.
if ($AdditionalPaths) {
  $Paths = @($Paths) + @($AdditionalPaths)
}

. '/workspaces/com.wallstop-studios.unity-helpers/scripts/comment-stripping.ps1'

function Write-Info($msg) {
  if ($VerboseOutput) { Write-Host "[lint-tests] $msg" -ForegroundColor Cyan }
}

# Heuristics and allowlists
$testRoots = @('Tests')
$allowedHelperFiles = @(
  'Tests/Runtime/Visuals/VisualsTestHelpers.cs',
  'Tests/Core/TextureTestHelper.cs',
  'Tests/Editor/Sprites/SpriteSheetExtractor/SharedSpriteTestFixtures.cs',
  'Tests/Editor/TestAssets/SharedAnimationTestFixtures.cs',
  'Tests/Editor/TestAssets/SharedEditorTestFixtures.cs',
  'Tests/Editor/TestAssets/SharedTextureTestFixtures.cs'
)

# Validate allowlisted paths exist (catches stale paths after file moves)
# Only validate when running from the repo root (package.json present)
if (Test-Path (Join-Path (Get-Location).Path 'package.json')) {
  foreach ($helperPath in $allowedHelperFiles) {
    $fullPath = Join-Path (Get-Location).Path $helperPath
    if (-not (Test-Path $fullPath)) {
      Write-Host "ERROR: Allowlisted helper file not found: $helperPath" -ForegroundColor Red
      Write-Host "  The file may have been moved or renamed. Update `$allowedHelperFiles in lint-tests.ps1." -ForegroundColor Yellow
      exit 1
    }
  }
}

# Removes C# string literals, character literals, and comments from a source
# string so downstream regex/bracket analysis ignores their contents. The
# content of each literal/comment is replaced with same-length whitespace so
# column positions (and therefore line counts) are preserved.
#
# Two-pass implementation:
#   1. Delegate comment masking (//, /* */ single- AND multi-line, /// XML
#      doc) to the shared helper in comment-stripping.ps1. The helper
#      additionally handles C# 11 raw string literals (""".."""), verbatim
#      strings (@"..."") with "" escapes, and interpolated strings ($"..."
#      and $@"...""), so no comment delimiter inside any string form can be
#      mistaken for a real comment opener.
#   2. Walk the comment-masked text to blank string contents: normal "..."
#      strings honor \" escapes; verbatim @"..." strings honor "" escapes;
#      character literals '...' have their content blanked.
#
# See scripts/comment-stripping.ps1 for the comment-masking language rules.
function Remove-CsStringLiteralsAndLineComments([string]$text) {
  if ([string]::IsNullOrEmpty($text)) { return $text }

  return Remove-CsStringLiteralsFromCommentMaskedText (Get-CsCommentMaskedText $text)
}

function Remove-CsStringLiteralsFromCommentMaskedText([string]$commentMasked) {
  if ([string]::IsNullOrEmpty($commentMasked)) { return $commentMasked }

  # Pass 2: blank string/char literal contents.
  $sb = New-Object System.Text.StringBuilder ($commentMasked.Length)
  $i = 0
  $n = $commentMasked.Length
  while ($i -lt $n) {
    $c = $commentMasked[$i]
    $next = if ($i + 1 -lt $n) { $commentMasked[$i + 1] } else { [char]0 }

    # Raw string literal: """...""" (C# 11). Opens with N >= 3 consecutive
    # `"` and closes with the same count. Content is blanked so embedded
    # code-like text (e.g. `[Test]`, `Object.Destroy(x)`) cannot match
    # downstream regexes. Newlines are preserved to keep line numbers.
    if ($c -eq '"' -and $next -eq '"' -and ($i + 2) -lt $n -and $commentMasked[$i + 2] -eq '"') {
      $quoteCount = 0
      $j = $i
      while ($j -lt $n -and $commentMasked[$j] -eq '"') { $quoteCount++; $j++ }
      # Emit the opening quote run verbatim.
      for ($q = 0; $q -lt $quoteCount; $q++) { [void]$sb.Append('"') }
      $i = $j
      while ($i -lt $n) {
        if ($commentMasked[$i] -eq '"') {
          $endCount = 0
          $k = $i
          while ($k -lt $n -and $commentMasked[$k] -eq '"') { $endCount++; $k++ }
          if ($endCount -ge $quoteCount) {
            # Emit the closing quote run verbatim; any trailing quotes
            # beyond $quoteCount belong to surrounding code and are
            # appended as-is so column offsets stay intact.
            for ($q = 0; $q -lt $endCount; $q++) { [void]$sb.Append('"') }
            $i = $k
            break
          }
          # Fewer than $quoteCount quotes — part of the body; blank them.
          for ($q = 0; $q -lt $endCount; $q++) { [void]$sb.Append(' ') }
          $i = $k
          continue
        }
        if ($commentMasked[$i] -eq "`n" -or $commentMasked[$i] -eq "`r") {
          [void]$sb.Append($commentMasked[$i])
        } else {
          [void]$sb.Append(' ')
        }
        $i++
      }
      continue
    }

    # Verbatim string: @"..." (possibly $@"..." interpolated verbatim).
    # The leading "$" on $@"..." is unremarkable to the blanker — we match
    # on @" and handle the string body the same way either form enters.
    if ($c -eq '@' -and $next -eq '"') {
      [void]$sb.Append('@')
      [void]$sb.Append('"')
      $i += 2
      while ($i -lt $n) {
        $ch = $commentMasked[$i]
        if ($ch -eq '"') {
          if ($i + 1 -lt $n -and $commentMasked[$i + 1] -eq '"') {
            # Escaped doubled quote — blank both and continue
            [void]$sb.Append(' ')
            [void]$sb.Append(' ')
            $i += 2
            continue
          }
          [void]$sb.Append('"')
          $i++
          break
        }
        if ($ch -eq "`n" -or $ch -eq "`r") {
          [void]$sb.Append($ch)
        } else {
          [void]$sb.Append(' ')
        }
        $i++
      }
      continue
    }

    # Normal string: "..." (also reached for $"..." interpolated strings;
    # the leading "$" is passed through unchanged and the string body is
    # blanked the same way).
    if ($c -eq '"') {
      [void]$sb.Append('"')
      $i++
      while ($i -lt $n) {
        $ch = $commentMasked[$i]
        if ($ch -eq '\') {
          [void]$sb.Append(' ')
          if ($i + 1 -lt $n) { [void]$sb.Append(' '); $i += 2 } else { $i++ }
          continue
        }
        if ($ch -eq '"') {
          [void]$sb.Append('"')
          $i++
          break
        }
        if ($ch -eq "`n" -or $ch -eq "`r") {
          [void]$sb.Append($ch)
        } else {
          [void]$sb.Append(' ')
        }
        $i++
      }
      continue
    }

    # Character literal: '...'
    if ($c -eq "'") {
      [void]$sb.Append("'")
      $i++
      while ($i -lt $n) {
        $ch = $commentMasked[$i]
        if ($ch -eq '\') {
          [void]$sb.Append(' ')
          if ($i + 1 -lt $n) { [void]$sb.Append(' '); $i += 2 } else { $i++ }
          continue
        }
        if ($ch -eq "'") {
          [void]$sb.Append("'")
          $i++
          break
        }
        if ($ch -eq "`n" -or $ch -eq "`r") {
          [void]$sb.Append($ch)
        } else {
          [void]$sb.Append(' ')
        }
        $i++
      }
      continue
    }

    [void]$sb.Append($c)
    $i++
  }
  return $sb.ToString()
}

function Get-CsCommentMaskedText([string]$text) {
  if ([string]::IsNullOrEmpty($text)) { return $text }

  $lines = $text -split "`n", -1
  $maskedLines = Get-CommentMaskedLines -Lines $lines -Language 'csharp'
  $commentMasked = [string]::Join("`n", $maskedLines)
  if ($commentMasked.Length -ne $text.Length) {
    return $text
  }

  return $commentMasked
}

function Test-CodeSpecificLineSuppression {
  Param(
    [string]$Line,
    [string]$CommentMaskedLine,
    [string]$Code
  )

  $suppressionPattern = [regex]('//\s*UNH-SUPPRESS\s+' + [regex]::Escape($Code) + '\b')
  foreach ($match in $suppressionPattern.Matches($Line)) {
    if ($match.Index -ge $CommentMaskedLine.Length) { continue }
    $length = [Math]::Min($match.Length, $CommentMaskedLine.Length - $match.Index)
    $maskedSuppression = $CommentMaskedLine.Substring($match.Index, $length)
    if ($maskedSuppression -match '^\s+$') { return $true }
  }

  return $false
}

function Test-CodeSpecificSuppressionInLineRange {
  Param(
    [string[]]$Lines,
    [string[]]$CommentMaskedLines,
    [int]$StartLine,
    [int]$EndLine,
    [string]$Code
  )

  for ($lineNumber = $StartLine; $lineNumber -le $EndLine; $lineNumber++) {
    $lineIndex = $lineNumber - 1
    if ($lineIndex -lt 0 -or $lineIndex -ge $Lines.Count) { continue }
    if ($lineIndex -ge $CommentMaskedLines.Count) { continue }
    if (
      Test-CodeSpecificLineSuppression `
        -Line $Lines[$lineIndex] `
        -CommentMaskedLine $CommentMaskedLines[$lineIndex] `
        -Code $Code
    ) {
      return $true
    }
  }

  return $false
}

function Get-InvocationArgumentText {
  Param([string]$Text, [int]$Start, [string]$OriginalText)

  $depth = 0
  for ($position = $Start; $position -lt $Text.Length; $position++) {
    $character = $Text[$position]
    if ($character -eq ')' -and $depth -eq 0) {
      if ($OriginalText.Length -eq $Text.Length) {
        return $OriginalText.Substring($Start, $position - $Start).Trim()
      }
      return ''
    }
    if ($character -eq '(' -or $character -eq '[' -or $character -eq '{') {
      $depth++
    } elseif ($character -eq ')' -or $character -eq ']' -or $character -eq '}') {
      $depth--
      if ($depth -lt 0) { return '' }
    }
  }
  return ''
}

$destroyPattern = [regex]'\b(?:UnityEngine\.)?Object\.(?:DestroyImmediate|Destroy)\s*\('
$createAssignObjectPattern = [regex]'(?<var>\b\w+)\s*=\s*new\s+(?<type>GameObject|Texture2D|Material|Mesh|Camera)\s*\('
$createInlineTrackPattern = [regex]'\bTrack\s*\(\s*new\s+(?:GameObject|Texture2D|Material|Mesh|Camera)\s*\('
$createSoAssignPattern = [regex]'(?<var>\b\w+)\s*=\s*ScriptableObject\.CreateInstance\s*<'

# Naming convention patterns (UNH004: No underscores in test names)
# Matches: TestName = "Some_Name" or TestName = @"Some_Name"
$testNameUnderscorePattern = [regex]'TestName\s*=\s*@?"[^"]*_[^"]*"'
# Matches: .SetName("Some_Name") or .SetName(@"Some_Name")
$setNameUnderscorePattern = [regex]'\.SetName\s*\(\s*@?"[^"]*_[^"]*"\s*\)'
# Matches: TestCaseSource method names with underscores (nameof(Some_Method) or "Some_Method")
$testCaseSourcePattern = [regex]'\[TestCaseSource\s*\(\s*(?:nameof\s*\(\s*(?<methodName>\w+)\s*\)|"(?<stringName>\w+)")\s*\)\]'
# Matches a C# method signature line and captures its name. Tolerates modifiers
# (public/private/internal/protected/static/async/override/virtual/sealed/new/extern/unsafe/partial),
# generic type parameters on the return type, ref/namespace-qualified return types, and
# optional leading attribute(s) on the same line (e.g. "[Test] public void Inline_Test()").
# Deliberately anchored to lines that end with "(" so we don't match variable
# declarations or calls. We re-check the body context before reporting.
$methodDeclPattern = [regex]'^\s*(?:\[[^\]]+\]\s*)*(?:(?:public|private|protected|internal|static|async|override|virtual|sealed|new|extern|unsafe|partial)\s+)+(?<retType>[\w\.\<\>\,\s\?\[\]]+?)\s+(?<name>[A-Za-z_]\w*)\s*\('
# Recognizes an attribute block (possibly multi-line, reconstructed with
# bracket-balance joining) whose FIRST attribute is a test-eligible attribute.
# Used against already-reconstructed attribute-block text, not raw lines.
# Accepts an optional "global::" root-namespace prefix, an optional
# namespace-qualified prefix (e.g. "NUnit.Framework."), and an optional
# "Attribute" suffix (NUnit allows both short and long forms).
$testAttributeLinePattern = [regex]'^\s*\[\s*(?:global\s*::\s*)?(?:[A-Za-z_][\w\.]*\.)?(?:Test|TestCase|TestCaseSource|UnityTest)(?:Attribute)?(?:\s*\(|\s*\]|\s*,)'
# Recognizes a reconstructed attribute-block (one or more [Attr(...)] on the
# same logical line, possibly followed by whitespace and an optional
# trailing // comment). Used on the reconstructed joined line, so multi-line
# attribute arguments are already collapsed by the bracket-balance walker.
$anyAttributeLinePattern = [regex]'^\s*\[[^\]]+\](?:\s*\[[^\]]+\])*\s*(?://.*)?$'
# Recognizes a same-line leading test attribute prefix on the signature line
# itself (e.g. "[Test] public void Inline_Test() { }"). Matches qualified and
# long-form attribute names consistent with $testAttributeLinePattern. Also
# recognizes the comma form inside a single bracket (e.g.
# "[Test, Category(\"Fast\")] public void Foo()").
$inlineTestAttributePattern = [regex]'^\s*\[\s*(?:global\s*::\s*)?(?:[A-Za-z_][\w\.]*\.)?(?:Test|TestCase|TestCaseSource|UnityTest)(?:Attribute)?(?:\s*\(|\s*\]|\s*,)'
# Detects a test-eligible attribute appearing anywhere on the signature line,
# not just as the first attribute. Catches stacked-inline forms like
# "[Category(\"Fast\")][Test] public void Foo()" that the anchored variant
# misses. Operates on a SCRUBBED line so "[Test]" inside a string literal
# cannot match.
$inlineTestAttributeAnywherePattern = [regex]'\[\s*(?:global\s*::\s*)?(?:[A-Za-z_][\w\.]*\.)?(?:Test|TestCase|TestCaseSource|UnityTest)(?:Attribute)?(?:\s*\(|\s*\]|\s*,)'
$testFileAttributePattern = [regex]'\[\s*(?:global\s*::\s*)?(?:(?:[A-Za-z_]\w*)\s*(?:\.|::)\s*)*(?:Test|TestCase|TestCaseSource|TestFixture|UnityTest)(?:Attribute)?(?:\s*\(|\s*\]|\s*,)'

# UNH005: Assert.IsNull/IsNotNull patterns (should use Assert.IsTrue for Unity null checks)
$assertIsNullPattern = [regex]'Assert\.IsNull\s*\('
$assertIsNotNullPattern = [regex]'Assert\.IsNotNull\s*\('
$testCaseDataReturnsNullPattern = [regex]'(?ms)\.Returns\s*\(\s*null\s*\)'
$unityTestAttributePattern = [regex]'\[\s*(?:global\s*::\s*)?(?:[A-Za-z_][\w\.]*\.)?UnityTest(?:Attribute)?(?:\s*\(|\s*\])'
$coroutineMethodPattern = [regex]'\bIEnumerator\s+(?<name>\w+)\s*\('
$tagsWaitInstructionPattern = [regex]'WaitForSeconds(?:Realtime)?'
$tagsWaitAliasPattern = [regex]'(?m)^\s*(?:global\s+)?using\s+(?<alias>[A-Za-z_]\w*)\s*=\s*(?:global\s*::\s*)?UnityEngine\s*(?:\.|::)\s*WaitForSeconds(?:Realtime)?\s*;'
$tagsUnityEngineAliasPattern = [regex]'(?m)^\s*(?:global\s+)?using\s+(?<alias>[A-Za-z_]\w*)\s*=\s*(?:global\s*::\s*)?UnityEngine\s*;'

# Returns true if the relative path matches an allowlisted helper file path.
function Is-AllowlistedFile([string]$relPath) {
  $normalized = ($relPath -replace '\\','/') -replace '^\.\/', ''
  foreach ($a in $allowedHelperFiles) {
    if ($normalized -ieq $a) { return $true }
  }
  return $false
}

function Get-RelativePath([string]$path) {
  $root = (Get-Location).Path
  $trimChars = [char[]]@(
    [System.IO.Path]::DirectorySeparatorChar,
    [System.IO.Path]::AltDirectorySeparatorChar,
    [char]'\'
  )
  $relative = $path.Substring($root.Length).TrimStart($trimChars)
  return (($relative -replace '\\','/') -replace '^\.\/', '')
}

$assemblyDefinitionEditorOnlyCache = @{}
$assemblyReferenceIndex = $null

function Test-AssemblyDefinitionEditorOnly([string]$asmdefPath) {
  try {
    $definition = Get-Content -LiteralPath $asmdefPath -Raw | ConvertFrom-Json
    $includePlatforms = @()
    if ($null -ne $definition.includePlatforms) {
      $includePlatforms = @($definition.includePlatforms)
    }

    $nonEditorPlatforms = @($includePlatforms | Where-Object { $_ -ne 'Editor' })
    return ($includePlatforms.Count -gt 0 -and $nonEditorPlatforms.Count -eq 0)
  } catch {
    return $false
  }
}

function Get-AssemblyReferenceIndex {
  if ($null -ne $script:assemblyReferenceIndex) {
    return $script:assemblyReferenceIndex
  }

  $byName = @{}
  $byGuid = @{}
  $root = (Get-Location).Path
  $asmdefs = @(Get-ChildItem -LiteralPath $root -Filter '*.asmdef' -Recurse -File -ErrorAction SilentlyContinue)
  foreach ($asmdef in $asmdefs) {
    try {
      $definition = Get-Content -LiteralPath $asmdef.FullName -Raw | ConvertFrom-Json
      $name = [string]$definition.name
      $editorOnly = Test-AssemblyDefinitionEditorOnly $asmdef.FullName
      if (-not [string]::IsNullOrWhiteSpace($name)) {
        $byName[$name] = $editorOnly
      }

      $metaPath = "$($asmdef.FullName).meta"
      if (Test-Path -LiteralPath $metaPath -PathType Leaf) {
        $metaText = Get-Content -LiteralPath $metaPath -Raw
        $guidMatch = [regex]::Match($metaText, '(?m)^guid:\s*(\S+)\s*$')
        if ($guidMatch.Success) {
          $byGuid[$guidMatch.Groups[1].Value] = $editorOnly
        }
      }
    } catch {
      continue
    }
  }

  $script:assemblyReferenceIndex = @{
    ByName = $byName
    ByGuid = $byGuid
  }
  return $script:assemblyReferenceIndex
}

function Test-AssemblyReferenceEditorOnly([string]$asmrefPath) {
  try {
    $definition = Get-Content -LiteralPath $asmrefPath -Raw | ConvertFrom-Json
    $reference = [string]$definition.reference
    if ([string]::IsNullOrWhiteSpace($reference)) {
      return $false
    }

    $index = Get-AssemblyReferenceIndex
    if ($reference.StartsWith('GUID:')) {
      $guid = $reference.Substring(5)
      return ($index.ByGuid.ContainsKey($guid) -and $index.ByGuid[$guid])
    }

    return ($index.ByName.ContainsKey($reference) -and $index.ByName[$reference])
  } catch {
    return $false
  }
}

function Get-FirstFileByName([string]$directory, [string]$pattern) {
  $first = $null
  foreach ($candidate in [System.IO.Directory]::EnumerateFiles($directory, $pattern)) {
    if ($null -eq $first -or [string]::CompareOrdinal(
        [System.IO.Path]::GetFileName($candidate),
        [System.IO.Path]::GetFileName($first)
      ) -lt 0) {
      $first = $candidate
    }
  }

  return $first
}

function Test-EditorOnlyAssemblyDefinition([string]$filePath, [string]$relPath) {
  $root = [System.IO.Path]::GetFullPath((Get-Location).Path).TrimEnd(
    [System.IO.Path]::DirectorySeparatorChar,
    [System.IO.Path]::AltDirectorySeparatorChar
  )
  $directory = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($filePath))

  # A directory with no asmdef/asmref of its own answers whatever its nearest ancestor answers, so
  # every directory walked past is cached with the resolved value. Caching only the directory that
  # SUPPLIES the answer left each leaf uncached forever, and this runs once per test file: the leaf
  # was re-enumerated 1,121 times. Cost is the same reason the file scan uses EnumerateFiles below --
  # Get-ChildItem measured 28.5 s against 0.8 s over this repository's C# files on the 9p mount.
  $walked = [System.Collections.Generic.List[string]]::new()

  while (-not [string]::IsNullOrWhiteSpace($directory)) {
    if ($assemblyDefinitionEditorOnlyCache.ContainsKey($directory)) {
      $cached = $assemblyDefinitionEditorOnlyCache[$directory]
      foreach ($seen in $walked) { $assemblyDefinitionEditorOnlyCache[$seen] = $cached }
      return $cached
    }

    $walked.Add($directory)

    $asmref = Get-FirstFileByName $directory '*.asmref'
    if ($null -ne $asmref) {
      $editorOnly = Test-AssemblyReferenceEditorOnly $asmref
      foreach ($seen in $walked) { $assemblyDefinitionEditorOnlyCache[$seen] = $editorOnly }
      return $editorOnly
    }

    $asmdef = Get-FirstFileByName $directory '*.asmdef'
    if ($null -ne $asmdef) {
      $editorOnly = Test-AssemblyDefinitionEditorOnly $asmdef
      foreach ($seen in $walked) { $assemblyDefinitionEditorOnlyCache[$seen] = $editorOnly }
      return $editorOnly
    }

    if ($directory -eq $root) {
      break
    }

    $parent = [System.IO.Directory]::GetParent($directory)
    if ($null -eq $parent) {
      break
    }
    $directory = $parent.FullName
  }

  return ($relPath -match '(^|/)Tests/Editor/')
}

function Fix-UnityNullAssertions {
  Param(
    [string]$Text
  )

  $originalText = $Text
  $callPattern = [regex]'(?m)^(?<indent>[ \t]*)Assert\.(?<kind>IsNotNull|IsNull)\s*\('
  $builder = [System.Text.StringBuilder]::new()
  $cursor = 0

  foreach ($match in $callPattern.Matches($Text)) {
    if ($match.Index -lt $cursor) {
      continue
    }

    $openParenIndex = $match.Index + $match.Length - 1
    $closeParenIndex = Get-MatchingCloseParenIndex -Text $Text -OpenParenIndex $openParenIndex
    if ($closeParenIndex -lt 0) {
      continue
    }

    $semicolonIndex = $closeParenIndex + 1
    while ($semicolonIndex -lt $Text.Length -and [char]::IsWhiteSpace($Text[$semicolonIndex])) {
      $semicolonIndex++
    }
    if ($semicolonIndex -ge $Text.Length -or $Text[$semicolonIndex] -ne ';') {
      continue
    }

    $argumentText = $Text.Substring($openParenIndex + 1, $closeParenIndex - $openParenIndex - 1)
    if (Test-HasAmbiguousLowercaseCommaAngle -Text $argumentText) {
      continue
    }

    $arguments = @(Split-TopLevelArguments -Text $argumentText)
    if ($arguments.Count -eq 0) {
      continue
    }

    $expr = ([string]$arguments[0]).Trim()
    if ([string]::IsNullOrWhiteSpace($expr)) {
      continue
    }

    $messageSuffix = ''
    if ($arguments.Count -gt 1) {
      $message = ([string]::Join(',', @($arguments[1..($arguments.Count - 1)]))).Trim()
      if (-not [string]::IsNullOrWhiteSpace($message)) {
        $messageSuffix = ", $message"
      }
    }

    $operator = if ($match.Groups['kind'].Value -eq 'IsNotNull') { '!=' } else { '==' }
    $replacement = $match.Groups['indent'].Value + "Assert.IsTrue($expr $operator null$messageSuffix);"
    [void]$builder.Append($Text.Substring($cursor, $match.Index - $cursor))
    [void]$builder.Append($replacement)
    $cursor = $semicolonIndex + 1
  }

  if ($cursor -gt 0) {
    [void]$builder.Append($Text.Substring($cursor))
    $Text = $builder.ToString()
  }

  $modified = ($originalText -ne $Text)
  return @{
    Text = $Text
    Modified = $modified
  }
}

function Get-MatchingCloseParenIndex {
  Param(
    [string]$Text,
    [int]$OpenParenIndex
  )

  $depth = 0
  $inString = $false
  $stringQuote = [char]0
  $verbatimString = $false

  for ($i = $OpenParenIndex; $i -lt $Text.Length; $i++) {
    $ch = $Text[$i]

    if ($inString) {
      if ($verbatimString -and $ch -eq '"') {
        if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '"') {
          $i++
          continue
        }
        $inString = $false
        continue
      }

      if (-not $verbatimString -and $ch -eq '\' -and $stringQuote -eq '"' -and $i + 1 -lt $Text.Length) {
        $i++
        continue
      }

      if ($ch -eq $stringQuote) {
        $inString = $false
      }
      continue
    }

    if ($ch -eq '"' -or $ch -eq "'") {
      $inString = $true
      $stringQuote = $ch
      $verbatimString = ($ch -eq '"' -and $i -gt 0 -and $Text[$i - 1] -eq '@')
      continue
    }

    if ($ch -eq '/' -and $i + 1 -lt $Text.Length) {
      if ($Text[$i + 1] -eq '/') {
        $newline = $Text.IndexOf("`n", $i + 2)
        if ($newline -lt 0) {
          return -1
        }
        $i = $newline
        continue
      }

      if ($Text[$i + 1] -eq '*') {
        $commentEnd = $Text.IndexOf('*/', $i + 2, [System.StringComparison]::Ordinal)
        if ($commentEnd -lt 0) {
          return -1
        }
        $i = $commentEnd + 1
        continue
      }
    }

    if ($ch -eq '(') {
      $depth++
      continue
    }

    if ($ch -eq ')') {
      $depth--
      if ($depth -eq 0) {
        return $i
      }
    }
  }

  return -1
}

function Split-TopLevelArguments {
  Param(
    [string]$Text,
    [bool]$TrackGenericAngles = $true,
    [AllowNull()]
    [System.Collections.Generic.HashSet[int]]$IgnoredAngleStartIndices = $null
  )

  $arguments = [System.Collections.Generic.List[string]]::new()
  $start = 0
  $depth = 0
  $angleDepth = 0
  $angleStartStack = [System.Collections.Generic.List[int]]::new()
  $inString = $false
  $stringQuote = [char]0
  $verbatimString = $false

  for ($i = 0; $i -lt $Text.Length; $i++) {
    $ch = $Text[$i]

    if ($inString) {
      if ($verbatimString -and $ch -eq '"') {
        if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '"') {
          $i++
          continue
        }
        $inString = $false
        continue
      }

      if (-not $verbatimString -and $ch -eq '\' -and $stringQuote -eq '"' -and $i + 1 -lt $Text.Length) {
        $i++
        continue
      }

      if ($ch -eq $stringQuote) {
        $inString = $false
      }
      continue
    }

    if ($ch -eq '"' -or $ch -eq "'") {
      $inString = $true
      $stringQuote = $ch
      $verbatimString = ($ch -eq '"' -and $i -gt 0 -and $Text[$i - 1] -eq '@')
      continue
    }

    if ($ch -eq '/' -and $i + 1 -lt $Text.Length) {
      if ($Text[$i + 1] -eq '/') {
        $newline = $Text.IndexOf("`n", $i + 2)
        if ($newline -lt 0) {
          break
        }
        $i = $newline
        continue
      }

      if ($Text[$i + 1] -eq '*') {
        $commentEnd = $Text.IndexOf('*/', $i + 2, [System.StringComparison]::Ordinal)
        if ($commentEnd -lt 0) {
          break
        }
        $i = $commentEnd + 1
        continue
      }
    }

    if ($ch -eq '(' -or $ch -eq '[' -or $ch -eq '{') {
      $depth++
      continue
    }

    if ($ch -eq ')' -or $ch -eq ']' -or $ch -eq '}') {
      if ($depth -gt 0) {
        $depth--
      }
      continue
    }

    if (
      $TrackGenericAngles -and
      $depth -eq 0 -and
      $ch -eq '<' -and
      ($null -eq $IgnoredAngleStartIndices -or -not $IgnoredAngleStartIndices.Contains($i)) -and
      (Test-LooksLikeGenericAngleStart -Text $Text -Index $i)
    ) {
      $angleDepth++
      $angleStartStack.Add($i) | Out-Null
      continue
    }

    if ($TrackGenericAngles -and $depth -eq 0 -and $ch -eq '>' -and $angleDepth -gt 0) {
      $angleDepth--
      $angleStartStack.RemoveAt($angleStartStack.Count - 1)
      continue
    }

    if ($ch -eq ',' -and $depth -eq 0 -and $angleDepth -eq 0) {
      $arguments.Add($Text.Substring($start, $i - $start)) | Out-Null
      $start = $i + 1
    }
  }

  if ($TrackGenericAngles -and $angleStartStack.Count -gt 0) {
    $ignored = [System.Collections.Generic.HashSet[int]]::new()
    if ($null -ne $IgnoredAngleStartIndices) {
      foreach ($index in $IgnoredAngleStartIndices) {
        $ignored.Add($index) | Out-Null
      }
    }
    foreach ($index in $angleStartStack) {
      $ignored.Add($index) | Out-Null
    }
    return @(Split-TopLevelArguments -Text $Text -TrackGenericAngles $true -IgnoredAngleStartIndices $ignored)
  }

  $arguments.Add($Text.Substring($start)) | Out-Null
  return @($arguments)
}

function Test-LooksLikeGenericAngleStart {
  Param(
    [string]$Text,
    [int]$Index
  )

  if ($Index -le 0 -or $Index + 1 -ge $Text.Length) {
    return $false
  }

  $previousIndex = Get-PreviousNonTriviaIndex -Text $Text -Index ($Index - 1)
  $nextIndex = Get-NextNonTriviaIndex -Text $Text -Index ($Index + 1)
  if ($previousIndex -lt 0 -or $nextIndex -ge $Text.Length) {
    return $false
  }

  $previous = $Text[$previousIndex]
  $hasTriviaBeforeAngle = ($Index - $previousIndex - 1) -gt 0
  $previousTokenStartsLower = $false
  if ([char]::IsLetterOrDigit($previous) -or $previous -eq '_') {
    $tokenStart = $previousIndex
    while (
      $tokenStart -gt 0 -and
      ([char]::IsLetterOrDigit($Text[$tokenStart - 1]) -or $Text[$tokenStart - 1] -eq '_')
    ) {
      $tokenStart--
    }
    $previousTokenStartsLower = [char]::IsLower($Text[$tokenStart])
    if ($hasTriviaBeforeAngle -and $previousTokenStartsLower) {
      return $false
    }
  }

  $hasGenericPrefix = (
    [char]::IsLetterOrDigit($previous) -or
    $previous -eq '_' -or
    $previous -eq ')' -or
    $previous -eq ']' -or
    $previous -eq '>'
  )
  if (-not $hasGenericPrefix) {
    return $false
  }

  $depth = 0
  $inString = $false
  $stringQuote = [char]0
  $verbatimString = $false

  for ($i = $Index; $i -lt $Text.Length; $i++) {
    $ch = $Text[$i]

    if ($inString) {
      if ($verbatimString -and $ch -eq '"') {
        if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '"') {
          $i++
          continue
        }
        $inString = $false
        continue
      }

      if (-not $verbatimString -and $ch -eq '\' -and $stringQuote -eq '"' -and $i + 1 -lt $Text.Length) {
        $i++
        continue
      }

      if ($ch -eq $stringQuote) {
        $inString = $false
      }
      continue
    }

    if ($ch -eq '"' -or $ch -eq "'") {
      $inString = $true
      $stringQuote = $ch
      $verbatimString = ($ch -eq '"' -and $i -gt 0 -and $Text[$i - 1] -eq '@')
      continue
    }

    if ($ch -eq '/' -and $i + 1 -lt $Text.Length) {
      if ($Text[$i + 1] -eq '/') {
        $newline = $Text.IndexOf("`n", $i + 2)
        if ($newline -lt 0) {
          return $false
        }
        $i = $newline
        continue
      }

      if ($Text[$i + 1] -eq '*') {
        $commentEnd = $Text.IndexOf('*/', $i + 2, [System.StringComparison]::Ordinal)
        if ($commentEnd -lt 0) {
          return $false
        }
        $i = $commentEnd + 1
        continue
      }
    }

    if ($ch -eq '<') {
      $depth++
      continue
    }

    if ($ch -ne '>') {
      continue
    }

    $depth--
    if ($depth -ne 0) {
      continue
    }

    $nextIndex = Get-NextNonTriviaIndex -Text $Text -Index ($i + 1)
    if ($nextIndex -ge $Text.Length) {
      return $true
    }

    $angleContent = $Text.Substring($Index + 1, $i - $Index - 1)
    if ($previousTokenStartsLower -and $angleContent.Contains(',')) {
      return $false
    }

    return ('(', ')', '[', ']', '{', '}', '.', ',', ';', '?') -contains $Text[$nextIndex]
  }

  return $false
}

function Get-MatchingAngleCloseIndex {
  Param(
    [string]$Text,
    [int]$OpenAngleIndex
  )

  $depth = 0
  $inString = $false
  $stringQuote = [char]0
  $verbatimString = $false

  for ($i = $OpenAngleIndex; $i -lt $Text.Length; $i++) {
    $ch = $Text[$i]

    if ($inString) {
      if ($verbatimString -and $ch -eq '"') {
        if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '"') {
          $i++
          continue
        }
        $inString = $false
        continue
      }

      if (-not $verbatimString -and $ch -eq '\' -and $stringQuote -eq '"' -and $i + 1 -lt $Text.Length) {
        $i++
        continue
      }

      if ($ch -eq $stringQuote) {
        $inString = $false
      }
      continue
    }

    if ($ch -eq '"' -or $ch -eq "'") {
      $inString = $true
      $stringQuote = $ch
      $verbatimString = ($ch -eq '"' -and $i -gt 0 -and $Text[$i - 1] -eq '@')
      continue
    }

    if ($ch -eq '/' -and $i + 1 -lt $Text.Length) {
      if ($Text[$i + 1] -eq '/') {
        $newline = $Text.IndexOf("`n", $i + 2)
        if ($newline -lt 0) {
          return -1
        }
        $i = $newline
        continue
      }

      if ($Text[$i + 1] -eq '*') {
        $commentEnd = $Text.IndexOf('*/', $i + 2, [System.StringComparison]::Ordinal)
        if ($commentEnd -lt 0) {
          return -1
        }
        $i = $commentEnd + 1
        continue
      }
    }

    if ($ch -eq '<') {
      $depth++
      continue
    }

    if ($ch -ne '>') {
      continue
    }

    $depth--
    if ($depth -eq 0) {
      return $i
    }

    if ($depth -lt 0) {
      return -1
    }
  }

  return -1
}

function Test-HasAmbiguousLowercaseCommaAngle {
  Param(
    [string]$Text
  )

  for ($i = 0; $i -lt $Text.Length; $i++) {
    if ($Text[$i] -ne '<') {
      continue
    }

    $previousIndex = Get-PreviousNonTriviaIndex -Text $Text -Index ($i - 1)
    if ($previousIndex -lt 0) {
      continue
    }

    if (($i - $previousIndex - 1) -gt 0) {
      continue
    }

    $previous = $Text[$previousIndex]
    if (-not ([char]::IsLetterOrDigit($previous) -or $previous -eq '_')) {
      continue
    }

    $tokenStart = $previousIndex
    while (
      $tokenStart -gt 0 -and
      ([char]::IsLetterOrDigit($Text[$tokenStart - 1]) -or $Text[$tokenStart - 1] -eq '_')
    ) {
      $tokenStart--
    }
    if (-not [char]::IsLower($Text[$tokenStart])) {
      continue
    }

    $closeIndex = Get-MatchingAngleCloseIndex -Text $Text -OpenAngleIndex $i
    if ($closeIndex -lt 0) {
      continue
    }

    $angleContent = $Text.Substring($i + 1, $closeIndex - $i - 1)
    if (-not $angleContent.Contains(',')) {
      continue
    }

    $nextIndex = Get-NextNonTriviaIndex -Text $Text -Index ($closeIndex + 1)
    if ($nextIndex -ge $Text.Length) {
      continue
    }

    if (('(', ')', '[', ']', '{', '}', '.', ',', ';', '?') -contains $Text[$nextIndex]) {
      return $true
    }
  }

  return $false
}

function Get-PreviousNonTriviaIndex {
  Param(
    [string]$Text,
    [int]$Index
  )

  $cursor = $Index
  while ($cursor -ge 0) {
    while ($cursor -ge 0 -and [char]::IsWhiteSpace($Text[$cursor])) {
      $cursor--
    }

    $lineStart = $Text.LastIndexOf("`n", [Math]::Max(0, $cursor))
    $lineStart = if ($lineStart -lt 0) { 0 } else { $lineStart + 1 }
    $lineCommentStart = $Text.LastIndexOf('//', [Math]::Max(0, $cursor), [System.StringComparison]::Ordinal)
    if ($lineCommentStart -ge $lineStart) {
      $cursor = $lineCommentStart - 1
      continue
    }

    if ($cursor -le 0 -or $Text[$cursor] -ne '/' -or $Text[$cursor - 1] -ne '*') {
      return $cursor
    }

    if ($cursor -lt 2) {
      return $cursor
    }

    $commentStart = $Text.LastIndexOf('/*', $cursor - 2, [System.StringComparison]::Ordinal)
    if ($commentStart -lt 0) {
      return $cursor
    }
    $cursor = $commentStart - 1
  }

  return $cursor
}

function Get-NextNonTriviaIndex {
  Param(
    [string]$Text,
    [int]$Index
  )

  $cursor = $Index
  while ($cursor -lt $Text.Length) {
    while ($cursor -lt $Text.Length -and [char]::IsWhiteSpace($Text[$cursor])) {
      $cursor++
    }

    if ($cursor + 1 -ge $Text.Length -or $Text[$cursor] -ne '/') {
      return $cursor
    }

    if ($Text[$cursor + 1] -eq '/') {
      $newline = $Text.IndexOf("`n", $cursor + 2)
      if ($newline -lt 0) {
        return $Text.Length
      }
      $cursor = $newline + 1
      continue
    }

    if ($Text[$cursor + 1] -eq '*') {
      $commentEnd = $Text.IndexOf('*/', $cursor + 2, [System.StringComparison]::Ordinal)
      if ($commentEnd -lt 0) {
        return $cursor
      }
      $cursor = $commentEnd + 2
      continue
    }

    return $cursor
  }

  return $cursor
}

function Get-LineNumberAtIndex {
  Param(
    [string]$Text,
    [int]$Index
  )

  if ($Index -le 0) {
    return 1
  }

  $lineNumber = 1
  $limit = [Math]::Min($Index, $Text.Length)
  for ($i = 0; $i -lt $limit; $i++) {
    if ($Text[$i] -eq "`n") {
      $lineNumber++
    }
  }

  return $lineNumber
}

function Get-TestCaseSourceBody {
  Param(
    [string[]]$Lines,
    [string[]]$ScrubbedLines,
    [string]$SourceName
  )

  $escapedSourceName = [regex]::Escape($SourceName)
  $sourceDeclarationPattern = [regex](
    "(?:IEnumerable\s*<\s*TestCaseData\s*>|IEnumerable|TestCaseData\s*\[\]|List\s*<\s*TestCaseData\s*>)\s+$escapedSourceName\b"
  )

  for ($lineIndex = 0; $lineIndex -lt $ScrubbedLines.Count; $lineIndex++) {
    if ($ScrubbedLines[$lineIndex] -match 'TestCaseSource') { continue }
    if (-not $sourceDeclarationPattern.IsMatch($ScrubbedLines[$lineIndex])) { continue }

    $braceDepth = 0
    $bodyStart = -1
    for ($bodyIndex = $lineIndex; $bodyIndex -lt $ScrubbedLines.Count; $bodyIndex++) {
      $scrubbedLine = $ScrubbedLines[$bodyIndex]
      for ($charIndex = 0; $charIndex -lt $scrubbedLine.Length; $charIndex++) {
        if ($scrubbedLine[$charIndex] -eq '{') {
          if ($bodyStart -lt 0) { $bodyStart = $bodyIndex }
          $braceDepth++
        } elseif ($scrubbedLine[$charIndex] -eq '}') {
          if ($bodyStart -ge 0) {
            $braceDepth--
            if ($braceDepth -eq 0) {
              return [pscustomobject]@{
                Text = [string]::Join("`n", $Lines[$bodyStart..$bodyIndex])
                ScrubbedText = [string]::Join("`n", $ScrubbedLines[$bodyStart..$bodyIndex])
                StartLine = $bodyStart + 1
              }
            }
          }
        }
      }

      if ($bodyStart -lt 0 -and $scrubbedLine -match ';') {
        return [pscustomobject]@{
          Text = [string]::Join("`n", $Lines[$lineIndex..$bodyIndex])
          ScrubbedText = [string]::Join("`n", $ScrubbedLines[$lineIndex..$bodyIndex])
          StartLine = $lineIndex + 1
        }
      }
    }
  }

  return $null
}

function Get-TestCaseDataChains {
  Param(
    [string]$Text,
    [int]$StartLine
  )

  $chains = @()
  $matches = [regex]::Matches($Text, 'new\s+TestCaseData\s*\(')
  foreach ($match in $matches) {
    $depth = 0
    $endIndex = $Text.Length - 1
    for ($charIndex = $match.Index; $charIndex -lt $Text.Length; $charIndex++) {
      $char = $Text[$charIndex]
      if ($char -eq '(' -or $char -eq '[' -or $char -eq '{') {
        $depth++
        continue
      }
      if ($char -eq ')' -or $char -eq ']' -or $char -eq '}') {
        if ($depth -gt 0) {
          $depth--
          continue
        }
        $endIndex = $charIndex
        break
      }
      if (($char -eq ';' -or $char -eq ',') -and $depth -eq 0) {
        $endIndex = $charIndex
        break
      }
    }

    $prefix = $Text.Substring(0, $match.Index)
    $sourceLine = $StartLine + (($prefix -split "`n").Length) - 1
    $chains += [pscustomobject]@{
      Text = $Text.Substring($match.Index, $endIndex - $match.Index)
      Line = $sourceLine
    }
  }

  return $chains
}

function Get-TestAttributeBlockForMethod {
  Param(
    [string[]]$Lines,
    [string[]]$ScrubbedLines,
    [int]$MethodLineIndex
  )

  $originalParts = New-Object System.Collections.Generic.List[string]
  $scrubbedParts = New-Object System.Collections.Generic.List[string]

  $methodLine = $ScrubbedLines[$MethodLineIndex]
  $methodMatch = $coroutineMethodPattern.Match($methodLine)
  if ($methodMatch.Success -and $methodMatch.Index -gt 0) {
    $inlineOriginal = $Lines[$MethodLineIndex].Substring(0, $methodMatch.Index)
    $inlineScrubbed = $methodLine.Substring(0, $methodMatch.Index)
    if (-not [string]::IsNullOrWhiteSpace($inlineScrubbed)) {
      $originalParts.Insert(0, $inlineOriginal)
      $scrubbedParts.Insert(0, $inlineScrubbed)
    }
  }

  $lineIndex = $MethodLineIndex - 1
  while ($lineIndex -ge 0) {
    $above = $Lines[$lineIndex]
    $aboveScrubbed = $ScrubbedLines[$lineIndex]
    if ([string]::IsNullOrWhiteSpace($aboveScrubbed)) {
      $lineIndex--
      continue
    }
    if ($above -match '^\s*//') {
      $lineIndex--
      continue
    }

    $joinedOriginal = $above
    $joinedScrubbed = $aboveScrubbed
    $top = $lineIndex
    $openBr = ([regex]::Matches($joinedScrubbed, '\[')).Count - ([regex]::Matches($joinedScrubbed, '\]')).Count
    $openPr = ([regex]::Matches($joinedScrubbed, '\(')).Count - ([regex]::Matches($joinedScrubbed, '\)')).Count
    while (($openBr -ne 0 -or $openPr -ne 0) -and $top -gt 0) {
      $top--
      $joinedOriginal = "$($Lines[$top])`n$joinedOriginal"
      $joinedScrubbed = "$($ScrubbedLines[$top])`n$joinedScrubbed"
      $openBr = ([regex]::Matches($joinedScrubbed, '\[')).Count - ([regex]::Matches($joinedScrubbed, '\]')).Count
      $openPr = ([regex]::Matches($joinedScrubbed, '\(')).Count - ([regex]::Matches($joinedScrubbed, '\)')).Count
    }

    $flat = ($joinedScrubbed -replace "\r?\n",' ').Trim()
    if (-not $anyAttributeLinePattern.IsMatch($flat)) { break }

    $originalParts.Insert(0, $joinedOriginal)
    $scrubbedParts.Insert(0, $joinedScrubbed)
    $lineIndex = $top - 1
  }

  return [pscustomobject]@{
    OriginalText = [string]::Join("`n", $originalParts)
    ScrubbedText = [string]::Join("`n", $scrubbedParts)
  }
}

function Get-TestCaseSourceNamesFromAttributeBlock {
  Param(
    [string]$AttributeText
  )

  $sourceNames = @()
  $matches = [regex]::Matches(
    $AttributeText,
    '(?ms)\bTestCaseSource(?:Attribute)?\s*\(\s*(?:nameof\s*\(\s*(?<methodName>\w+)\s*\)|"(?<stringName>[^"]+)")'
  )
  foreach ($match in $matches) {
    $sourceName = $match.Groups['methodName'].Value
    if ([string]::IsNullOrWhiteSpace($sourceName)) {
      $sourceName = $match.Groups['stringName'].Value
    }
    if (-not [string]::IsNullOrWhiteSpace($sourceName)) {
      $sourceNames += $sourceName
    }
  }
  return $sourceNames
}

$violations = @()
# Non-blocking guidance (currently UNH009 asset-churn): reported every run but
# does NOT fail the build, so pre-existing churn is surfaced for cleanup without
# forcing a risky mass-conversion of fixtures to a batched base.
$advisories = @()

# A List rather than `$filesToScan += ...`: `+=` on a PowerShell array copies the whole array every
# time, so the -Paths branch was quadratic. With every test file passed explicitly it took 193 s
# against 77 s for the enumerate-everything branch -- the caller with the MOST information was the
# slowest. Resolve-Path is a cmdlet call per file on top of that; GetFullPath is a string operation.
$filesToScanList = [System.Collections.Generic.List[string]]::new()
if ($Paths -and $Paths.Count -gt 0) {
  foreach ($p in $Paths) {
    $candidatePath = $p -replace '\\','/'
    if ($candidatePath -notlike '*.cs') { continue }
    # IsPathRooted first: `Join-Path '/repo' '/abs/path'` yields '/repo/abs/path', so joining an
    # absolute caller path unconditionally mangles it into one that does not exist -- and the file
    # is then skipped silently, which is the failure this whole change set is about. Resolve-Path,
    # which this replaced, handled both forms.
    $full = if ([System.IO.Path]::IsPathRooted($candidatePath)) {
      [System.IO.Path]::GetFullPath($candidatePath)
    } else {
      [System.IO.Path]::GetFullPath((Join-Path (Get-Location).Path $candidatePath))
    }
    if ([System.IO.File]::Exists($full)) {
      $filesToScanList.Add($full)
    } else {
      Write-Info "Skipping path '$p' because it was not found."
    }
  }
} else {
  foreach ($root in $testRoots) {
    if (-not (Test-Path $root)) { continue }
    # [IO.Directory]::EnumerateFiles rather than Get-ChildItem -Recurse -Include, which
    # enumerates everything and post-filters: 0.8 s against 28.5 s over this repository's C# files
    # on the devcontainer's 9p mount. The Sort-Object -Unique below already fixes the order.
    $filesToScanList.AddRange([System.IO.Directory]::EnumerateFiles(
      (Resolve-Path -LiteralPath $root).Path,
      '*.cs',
      [System.IO.SearchOption]::AllDirectories
    ))
  }
}

$filesToScan = $filesToScanList | Sort-Object -Unique

foreach ($file in $filesToScan) {
  if ($file -like '*.meta') { continue }
  $rel = Get-RelativePath $file
  if ($rel -match '(^|/)[^/]*~/') { continue }
  if (Is-AllowlistedFile $rel) { continue }

  # ReadAllLines rather than Get-Content: it always answers a string[], so the array
  # semantics Set-StrictMode needs come for free -- Get-Content answers $null for an empty
  # file and a bare [string] for a single-line one, and .Count throws on both.
  $content = [System.IO.File]::ReadAllLines($file)
  $text = $content -join "`n"

  if ($FixNullChecks) {
    $rawText = [System.IO.File]::ReadAllText($file)
    $fixResult = Fix-UnityNullAssertions -Text $rawText
    if ($fixResult.Modified) {
      Write-Info "Auto-fixed Unity null assertions in $rel"
      [System.IO.File]::WriteAllText($file, $fixResult.Text, [System.Text.UTF8Encoding]::new($false))
    }
    foreach ($remaining in @([regex]::Matches($fixResult.Text, '(?m)^\s*Assert\.Is(Not)?Null\s*\('))) {
      $violations += (@{
        Path=$rel; Line=(Get-LineNumberAtIndex -Text $fixResult.Text -Index $remaining.Index); Message='UNH005: Assert.IsNull/Assert.IsNotNull is forbidden and could not be auto-fixed; use Assert.IsTrue(expr == null) or Assert.IsTrue(expr != null)'
      })
    }
    continue
  }

  # Scrubbed view: string literals and comments (including multi-line block
  # comments via comment-stripping.ps1) replaced with whitespace, preserving
  # line count and column offsets. Used by per-line pattern checks so that
  # e.g. `Object.Destroy(x)` inside a `/* ... */` comment or a string does
  # not trip UNH001. Falls back to raw content on unexpected length drift.
  # NOTE: an if/else expression that produces an @(...)-wrapped array
  # unwraps it to a bare string when the array has length 1 under certain
  # pipeline conditions, which then fails the `.Count` access under
  # StrictMode. Build the array imperatively and re-wrap to guarantee
  # array semantics for downstream `.Count` / indexing access.
  $commentMaskedText = Get-CsCommentMaskedText $text
  $commentMaskedContent = @($commentMaskedText -split "`n")
  $commentMaskedContent = @($commentMaskedContent)
  if ($commentMaskedContent.Count -ne $content.Count) { $commentMaskedContent = $content }

  $scrubbedText = Remove-CsStringLiteralsFromCommentMaskedText $commentMaskedText
  if ($null -eq $scrubbedText) {
    $scrubbedContent = $content
  } else {
    $scrubbedContent = @($scrubbedText -split "`n")
  }
  $scrubbedContent = @($scrubbedContent)
  if ($scrubbedContent.Count -ne $content.Count) { $scrubbedContent = $content }

  foreach ($destroy in $destroyPattern.Matches($scrubbedText)) {
    $lineIndex = Get-LineNumberAtIndex -Text $scrubbedText -Index $destroy.Index
    if ($content[$lineIndex - 1] -match 'UNH-SUPPRESS') { continue }
    $argument = if ($scrubbedText.Length -eq $commentMaskedText.Length -and $scrubbedText.Length -eq $text.Length) {
      Get-InvocationArgumentText -Text $scrubbedText -OriginalText $commentMaskedText -Start ($destroy.Index + $destroy.Length)
    } else { '' }
    $allowed = $false
    if (-not [string]::IsNullOrWhiteSpace($argument)) {
      $searchStart = [Math]::Max(0, $lineIndex - 100)
      $precedingLines = @($scrubbedContent[$searchStart..($lineIndex - 1)])
      $column = $destroy.Index - ($scrubbedText.LastIndexOf("`n", $destroy.Index) + 1)
      $precedingLines[-1] = $precedingLines[-1].Substring(0, $column)
      $precedingCode = $precedingLines -join "`n"
      $precedingOriginalCode = $commentMaskedText.Substring($destroy.Index - $precedingCode.Length, $precedingCode.Length)
      foreach ($track in [regex]::Matches($precedingCode, '\bTrack\s*\(')) {
        $tracked = Get-InvocationArgumentText -Text $precedingCode -OriginalText $precedingOriginalCode -Start ($track.Index + $track.Length)
        if ([string]::IsNullOrWhiteSpace($tracked)) { continue }
        $trackedExpressions = @($tracked)
        $assignment = [regex]::Match($precedingCode.Substring(0, $track.Index), '(?<![\w.@])(?<variable>@?[A-Za-z_]\w*)\s*=\s*$')
        if ($assignment.Success) { $trackedExpressions += $assignment.Groups['variable'].Value }
        foreach ($expression in $trackedExpressions) {
          if ($argument.StartsWith($expression, [StringComparison]::Ordinal)) {
            $remaining = $argument.Substring($expression.Length).TrimStart()
            if ($remaining.Length -eq 0 -or $remaining.StartsWith(',')) { $allowed = $true; break }
          }
        }
        if ($allowed) { break }
      }
    }
    if (-not $allowed) {
      $violations += (@{
        Path=$rel; Line=$lineIndex; Message="UNH001: Avoid direct destroy in tests; track object and let teardown clean up (or add // UNH-SUPPRESS)"
      })
    }
  }

  # Check untracked new allocations via assignment (var = new Type(...))
  $assignMatches = $createAssignObjectPattern.Matches($text)
  foreach ($am in $assignMatches) {
    $var = $am.Groups['var'].Value
    if ([string]::IsNullOrWhiteSpace($var)) { continue }
    # Find the index of this match in terms of line
    $prefix = $text.Substring(0, $am.Index)
    $lineNo = ($prefix -split "`n").Length
    # Skip if line has UNH-SUPPRESS
    if ($content[$lineNo-1] -match 'UNH-SUPPRESS') { continue }
    # Look ahead 10 lines for Track(var)
    $endLine = [Math]::Min($content.Count, $lineNo + 10)
    $found = $false
    for ($j = $lineNo; $j -le $endLine; $j++) {
      if ($content[$j-1] -match "Track\s*\(\s*$var\b") { $found = $true; break }
    }
    if (-not $found) {
      $violations += (@{
        Path=$rel; Line=$lineNo; Message="UNH002: Unity object allocation should be tracked: add Track($var)"
      })
    }
  }

  # Check inline Track(new ...) OK; but find bare inline new ... in args without Track
  if ($text -match '\bnew\s+(GameObject|Texture2D|Material|Mesh|Camera)\s*\(') {
    # If Track(new ...) not present at all, flag a generic warning at file level
    if (-not $createInlineTrackPattern.IsMatch($text)) {
      # locate first occurrence for line number
      $m = [regex]::Match($text, '\bnew\s+(GameObject|Texture2D|Material|Mesh|Camera)\s*\(')
      $lineNo = (($text.Substring(0, $m.Index)) -split "`n").Length
      # Skip if line has UNH-SUPPRESS
      if ($content[$lineNo-1] -match 'UNH-SUPPRESS') { continue }
      $violations += (@{
        Path=$rel; Line=$lineNo; Message="UNH002: Inline Unity object creation should be passed to Track(new …)"
      })
    }
  }

  # Check ScriptableObject.CreateInstance<T>() assigned, ensure tracked
  $soMatches = $createSoAssignPattern.Matches($text)
  foreach ($sm in $soMatches) {
    $var = $sm.Groups['var'].Value
    if ([string]::IsNullOrWhiteSpace($var)) { continue }
    $prefix = $text.Substring(0, $sm.Index)
    $lineNo = ($prefix -split "`n").Length
    # Skip if line or next few lines have UNH-SUPPRESS (multi-line statements)
    $checkEnd = [Math]::Min($content.Count, $lineNo + 2)
    $suppressed = $false
    for ($s = $lineNo - 1; $s -lt $checkEnd; $s++) {
      if ($content[$s] -match 'UNH-SUPPRESS') { $suppressed = $true; break }
    }
    if ($suppressed) { continue }
    $found = $false
    $endLine = [Math]::Min($content.Count, $lineNo + 10)
    for ($j = $lineNo; $j -le $endLine; $j++) {
      if ($content[$j-1] -match "Track\s*\(\s*$var\b") { $found = $true; break }
    }
    if (-not $found) {
      $violations += (@{
        Path=$rel; Line=$lineNo; Message="UNH002: ScriptableObject instance should be tracked: add Track($var)"
      })
    }
  }

  # UNH004: Check for underscores in TestName values
  $lineIndex = 0
  foreach ($line in $content) {
    $lineIndex++
    if ($line -match 'UNH-SUPPRESS') { continue }
    if ($testNameUnderscorePattern.IsMatch($line)) {
      $violations += (@{
        Path=$rel; Line=$lineIndex; Message="UNH004: TestName contains underscore. Use PascalCase or dot notation (e.g., 'Input.Null.ReturnsFalse')"
      })
    }
  }

  # UNH004: Check for underscores in SetName() calls
  $lineIndex = 0
  foreach ($line in $content) {
    $lineIndex++
    if ($line -match 'UNH-SUPPRESS') { continue }
    if ($setNameUnderscorePattern.IsMatch($line)) {
      $violations += (@{
        Path=$rel; Line=$lineIndex; Message="UNH004: SetName() contains underscore. Use PascalCase or dot notation (e.g., 'Input.Null.ReturnsFalse')"
      })
    }
  }

  # UNH004: Check for underscores in TestCaseSource method names
  $lineIndex = 0
  foreach ($line in $content) {
    $lineIndex++
    if ($line -match 'UNH-SUPPRESS') { continue }
    $sourceMatch = $testCaseSourcePattern.Match($line)
    if ($sourceMatch.Success) {
      $methodName = $sourceMatch.Groups['methodName'].Value
      if ([string]::IsNullOrWhiteSpace($methodName)) {
        $methodName = $sourceMatch.Groups['stringName'].Value
      }
      if (-not [string]::IsNullOrWhiteSpace($methodName) -and $methodName -match '_') {
        $violations += (@{
          Path=$rel; Line=$lineIndex; Message="UNH004: TestCaseSource method '$methodName' contains underscore. Use PascalCase (e.g., 'EdgeCaseTestData')"
        })
      }
    }
  }

  # UNH004: Check for underscores in method names decorated with
  # [Test], [TestCase(...)], [TestCaseSource(...)], or [UnityTest]. The Unity
  # runtime test TestNamingConventionTests.TestMethodNamesDoNotContainUnderscores
  # catches this at test time, but we also enforce it here so the pre-commit
  # hook blocks the violation before it ever reaches CI.
  #
  # Walker strategy: walk upward from the signature line over attribute blocks.
  # Multi-line attribute arguments (e.g. "[TestCase(\n    1,\n    2)]") are
  # handled by bracket-balance joining: when we see a line that doesn't close
  # its own brackets, we keep accumulating lines upward until the '[' and '(' on
  # that block are all matched. That reconstructed logical line is then tested
  # against the test-attribute and any-attribute patterns. Trailing "// reason"
  # comments on attribute lines and standalone "// explanation" comment lines
  # between attributes and the signature are tolerated.
  for ($i = 0; $i -lt $content.Count; $i++) {
    $line = $content[$i]
    $declMatch = $methodDeclPattern.Match($line)
    if (-not $declMatch.Success) { continue }
    $methodName = $declMatch.Groups['name'].Value
    if ($methodName -notmatch '_') { continue }
    # Avoid false positives on keywords that the regex's modifier-greedy match
    # could theoretically align to (belt-and-braces; the modifier list is fixed).
    if ($methodName -in @('if','for','foreach','while','switch','using','return','new','base','this')) { continue }

    $isTest = $false
    $attrLine = -1
    # For inline/prefix matching, scrub the signature line so that "[" or "("
    # inside string/char literals can't fool the test-attribute regex.
    $lineScrubbed = Remove-CsStringLiteralsAndLineComments $line
    # Bound the scan to the portion of the signature line BEFORE the method
    # declaration's opening '('. $methodDeclPattern matches up to and
    # including that opening paren, so taking Substring(0, Index + Length)
    # yields the attribute/modifier/return-type/name prefix and EXCLUDES any
    # parameter-level attributes (e.g. "void Foo(int x, [Test] int y)" has a
    # C# parameter attribute that is NOT a test-declaration attribute).
    # Without this bound, $inlineTestAttributeAnywherePattern would raise a
    # false UNH004 on such methods.
    $lineScrubbedPrefix = $lineScrubbed.Substring(0, $declMatch.Index + $declMatch.Length)
    # Same-line prefix: "[Test] public void Foo_Bar() { }" (anchored) OR a
    # stacked-inline form where the test attribute is not the first bracket,
    # e.g. "[Category(\"Fast\")][Test] public void Foo()". The scrubber has
    # already blanked string/char literals, so a non-anchored search cannot
    # be tricked by "[Test]" appearing inside a string. The anchored form is
    # retained alongside the anywhere form for clarity/robustness: it asserts
    # '^\s*\[' at the prefix start, which matters if the bounded prefix is
    # ever extended to start mid-line.
    if ($inlineTestAttributePattern.IsMatch($lineScrubbedPrefix) -or $inlineTestAttributeAnywherePattern.IsMatch($lineScrubbedPrefix)) {
      $isTest = $true
      $attrLine = $i
    } else {
      # Walk upward over attribute-only blocks (stacked attributes are allowed
      # in any order) until we find a test attribute, a non-attribute line,
      # or the top of the file. Attribute blocks may span multiple physical
      # lines when their arguments wrap; we accumulate lines upward until the
      # bracket balance of the joined block is zero.
      #
      # Bracket/comment analysis is done on a SCRUBBED copy of each line
      # (strings/chars blanked, comments stripped) so that "[", "]", "(", ")",
      # and "//" inside literals can't bypass the walker. Reported line
      # numbers still reference the ORIGINAL source lines.
      $j = $i - 1
      while ($j -ge 0) {
        $above = $content[$j]
        $aboveScrubbed = Remove-CsStringLiteralsAndLineComments $above
        if ([string]::IsNullOrWhiteSpace($aboveScrubbed)) { $j--; continue }
        # Single-line comments (both "//" and "///") between attributes and
        # the signature are allowed. After scrubbing, pure-comment lines
        # become blank, so this branch mainly catches any residual whitespace
        # check above; keep it for robustness against lines beginning with "//".
        if ($above -match '^\s*//') { $j--; continue }

        # If this line already balances its own brackets, treat it as a single
        # logical line. Otherwise walk upward accumulating until balance hits 0.
        $joinedScrubbed = $aboveScrubbed
        $top = $j
        $openBr = ([regex]::Matches($joinedScrubbed, '\[')).Count - ([regex]::Matches($joinedScrubbed, '\]')).Count
        $openPr = ([regex]::Matches($joinedScrubbed, '\(')).Count - ([regex]::Matches($joinedScrubbed, '\)')).Count
        while (($openBr -ne 0 -or $openPr -ne 0) -and $top -gt 0) {
          $top--
          $prevScrubbed = Remove-CsStringLiteralsAndLineComments $content[$top]
          $joinedScrubbed = "$prevScrubbed`n$joinedScrubbed"
          $openBr = ([regex]::Matches($joinedScrubbed, '\[')).Count - ([regex]::Matches($joinedScrubbed, '\]')).Count
          $openPr = ([regex]::Matches($joinedScrubbed, '\(')).Count - ([regex]::Matches($joinedScrubbed, '\)')).Count
        }
        # Collapse to a single-line string for the regex match. The scrubbed
        # text has already had //-comments stripped, so no extra strip pass.
        $flat = ($joinedScrubbed -replace "\r?\n",' ').Trim()

        # Match the test-attribute anchored pattern OR the non-anchored
        # "anywhere" variant so that stacked attribute blocks like
        # "[Category(\"Fast\")][Test]" on a line ABOVE the signature are
        # detected when [Test] is not first. Using the anywhere pattern is
        # safe here because $flat is attribute-only reconstructed text — no
        # method parameter list is included — so the parameter-attribute
        # false-positive concern that bounds the same-line check does NOT
        # apply to the walker.
        if ($testAttributeLinePattern.IsMatch($flat) -or $inlineTestAttributeAnywherePattern.IsMatch($flat)) {
          $isTest = $true
          $attrLine = $top
          break
        }
        if ($anyAttributeLinePattern.IsMatch($flat)) {
          $j = $top - 1
          continue
        }
        # Anything else terminates the attribute block.
        break
      }
    }
    if (-not $isTest) { continue }
    # UNH-SUPPRESS honored on either the method signature line or any line of
    # the attribute block (including multi-line continuations and comments).
    $suppressed = ($line -match 'UNH-SUPPRESS')
    if (-not $suppressed -and $attrLine -ge 0) {
      for ($k = $attrLine; $k -le $i; $k++) {
        if ($content[$k] -match 'UNH-SUPPRESS') { $suppressed = $true; break }
      }
    }
    if ($suppressed) { continue }
    $violations += (@{
      Path=$rel; Line=($i + 1); Message="UNH004: Test method name '$methodName' contains underscore. Use PascalCase."
    })
  }

  # UNH006: Unity coroutine tests with TestCaseSource must use
  # TestCaseData.Returns(null), otherwise NUnit reports:
  # "Method has non-void return value, but no result is expected."
  for ($lineIndex = 0; $lineIndex -lt $scrubbedContent.Count; $lineIndex++) {
    if ($content[$lineIndex] -match 'UNH-SUPPRESS') { continue }
    if (-not $coroutineMethodPattern.IsMatch($scrubbedContent[$lineIndex])) { continue }

    $attributeBlock = Get-TestAttributeBlockForMethod -Lines $content -ScrubbedLines $scrubbedContent -MethodLineIndex $lineIndex
    if (-not $unityTestAttributePattern.IsMatch($attributeBlock.ScrubbedText)) { continue }

    $sourceNames = Get-TestCaseSourceNamesFromAttributeBlock -AttributeText $attributeBlock.OriginalText
    foreach ($sourceName in $sourceNames) {
      $sourceBody = Get-TestCaseSourceBody -Lines $content -ScrubbedLines $scrubbedContent -SourceName $sourceName
      if ($null -eq $sourceBody) { continue }

      $chains = Get-TestCaseDataChains -Text $sourceBody.ScrubbedText -StartLine $sourceBody.StartLine
      foreach ($chain in $chains) {
        if ($testCaseDataReturnsNullPattern.IsMatch($chain.Text)) { continue }

        $violations += (@{
          Path=$rel; Line=$chain.Line; Message="UNH006: TestCaseData used by [UnityTest] coroutine source '$sourceName' must call .Returns(null)."
        })
      }
    }
  }

  # UNH005: Check for Assert.IsNull (should use Assert.IsTrue(x == null) for Unity null checks)
  $lineIndex = 0
  foreach ($line in $content) {
    $lineIndex++
    if ($line -match 'UNH-SUPPRESS') { continue }
    if ($assertIsNullPattern.IsMatch($line)) {
      $violations += (@{
        Path=$rel; Line=$lineIndex; Message="UNH005: Use Assert.IsTrue(x == null) instead of Assert.IsNull(x) for Unity object null checks"
      })
    }
  }

  # UNH005: Check for Assert.IsNotNull (should use Assert.IsTrue(x != null) for Unity null checks)
  $lineIndex = 0
  foreach ($line in $content) {
    $lineIndex++
    if ($line -match 'UNH-SUPPRESS') { continue }
    if ($assertIsNotNullPattern.IsMatch($line)) {
      $violations += (@{
        Path=$rel; Line=$lineIndex; Message="UNH005: Use Assert.IsTrue(x != null) instead of Assert.IsNotNull(x) for Unity object null checks"
      })
    }
  }

  # Enforce CommonTestBase inheritance only if file creates Unity objects and is under Runtime/ or Editor/
  $createsUnity = ($assignMatches.Count -gt 0) -or ($text -match '\bnew\s+(GameObject|Texture2D|Material|Mesh|Camera)\s*\(') -or ($soMatches.Count -gt 0)
  if ($createsUnity) {
    # Check for direct or indirect inheritance (CommonTestBase or any base that inherits it)
    $usesBase = ($text -match ':\s*(CommonTestBase|AttributeTagsTestBase|TagsTestBase|EditorCommonTestBase|SpriteSheetExtractorTestBase|BatchedEditorTestBase|DetectAssetChangeTestBase|RelationalExactBindingTestBase)')
    # Check for file-level UNH-SUPPRESS UNH003 comment
    $hasSuppress = ($text -match 'UNH-SUPPRESS.*UNH003|UNH-SUPPRESS:\s*Complex|UNH-SUPPRESS:\s*This IS the CommonTestBase')
    if (-not $usesBase -and -not $hasSuppress) {
      # Only enforce for test classes; skip helper-only files
      if ($text -match '\bnamespace\s+WallstopStudios') {
        $violations += (@{
          Path=$rel; Line=1; Message="UNH003: Test classes creating Unity objects should inherit CommonTestBase (Editor or Runtime variant)"
        })
      }
    }
  }

  # ---- Test performance budgets (UNH007 / UNH008 / UNH009) ----
  # A fixture is "perf-tagged" when it declares the Performance or Stress
  # category; those fixtures are EXCLUDED from the fast CI matrix
  # (UH_UNITY_TEST_CATEGORY="!Performance;!Stress") and run only in the
  # dedicated benchmark job, so heavy work is allowed there.
  # Match both the short `[Category("Performance")]` and fully-qualified
  # `[NUnit.Framework.Category("Performance")]` / `...CategoryAttribute(...)` forms.
  # Use a COMMENT-MASKED (but NOT string-blanked) view: masking comments stops a
  # commented-out `// [Category("Performance")]` from satisfying the rule, while
  # preserving string contents keeps the "Performance"/"Stress" category name
  # visible (the full $scrubbedText would blank it).
  $categoryRegex = '\[\s*(?:NUnit\.Framework\.)?Category(?:Attribute)?\(\s*"(Performance|Stress)"\s*\)\s*\]'
  $commentMaskedText = [string]::Join("`n", (Get-CommentMaskedLines -Lines ($text -split "`n", -1) -Language 'csharp'))
  $perfCategory = [regex]::IsMatch($commentMaskedText, $categoryRegex)

  # UNH008: a fixture that LOOKS like a benchmark (lives under a Performance/
  # folder or is named *PerformanceTests / *BenchmarkTests) MUST carry the
  # Performance or Stress category, otherwise the fast matrix would run it.
  $looksPerf = ($rel -match '(^|/)Performance/') -or [regex]::IsMatch($scrubbedText, '\bclass\s+\w*(Performance|Benchmark)\w*Tests\b')
  $isTestFile = $testFileAttributePattern.IsMatch($scrubbedText)
  $isRuntimeTagsTest = ($rel -match '^Tests/Runtime/Tags/')
  if ($looksPerf -and $isTestFile -and -not $perfCategory -and ($text -notmatch 'UNH-SUPPRESS.*UNH008')) {
    $violations += (@{
      Path=$rel; Line=1; Message='UNH008: Performance/benchmark fixture must declare [Category("Performance")] or [Category("Stress")] so the main CI matrix (which runs !Performance;!Stress) excludes it'
    })
  }

  # UNH009 (ADVISORY, non-blocking): per-test AssetDatabase.Refresh()/
  # SaveAndReimport() churns the asset importer on every test. Prefer
  # BatchedEditorTestBase (batches and defers a single refresh to
  # OneTimeTearDown). Reported as guidance only — converting an existing
  # fixture to a batched base can change timing-dependent behaviour and must be
  # validated in the editor, so this never fails the build. Infra/base files
  # (Tests/Core/**, *TestBase.cs) legitimately manage refreshes and are skipped.
  $isInfra = ($rel -match '(^|/)Tests/Core/') -or ($rel -match 'TestBase\.cs$')
  $batchedBase = ($text -match ':\s*(BatchedEditorTestBase|SpriteSheetExtractorTestBase|DetectAssetChangeTestBase)\b')
  if (-not $batchedBase -and -not $isInfra) {
    $lineIndex = 0
    foreach ($line in $content) {
      $lineIndex++
      if ($line -match 'UNH-SUPPRESS') { continue }
      $scrubbedLine = $scrubbedContent[$lineIndex - 1]
      if ([regex]::IsMatch($scrubbedLine, 'AssetDatabase\.Refresh\s*\(|\.SaveAndReimport\s*\(')) {
        $advisories += (@{
          Path=$rel; Line=$lineIndex; Message='UNH009: per-test AssetDatabase.Refresh()/SaveAndReimport() churns imports; prefer BatchedEditorTestBase (advisory)'
        })
      }
    }
  }

  # UNH010 (ADVISORY, non-blocking): real-time waits block the serial test clock.
  # A literal `new WaitForSeconds(x)` / `Task.Delay(n)` / `Thread.Sleep(n)` burns
  # wall-clock on EVERY run; prefer frame-stepping (`yield return null`), a
  # deterministic completion signal (TaskCompletionSource / ManualResetEventSlim),
  # or an injectable clock. Reported as guidance (legitimate frame-timing exists and
  # conversion must be validated in the editor); the per-fixture wall-clock budget
  # (scripts/unity/report-slow-tests.ps1 -FailOverBudget) is the HARD gate.
  # `Task.Delay(n, ct)` is intentionally NOT matched (cancellation-test fodder, not a
  # blocking wait). Infra/base files (Tests/Core/**, *TestBase.cs) are skipped.
  if ($isTestFile -and -not $perfCategory -and -not $isInfra) {
    # Only LITERAL durations are matched. Leading-dot literals (`.5f`), const/variable
    # args (`WaitForSeconds(delay)`), and expression args (`Task.Delay(1000 * 5)`) are
    # intentionally out of scope - they are rarer and need human judgement, and this
    # rule is advisory (the wall-clock budget gate is the hard backstop).
    $waitRegex = 'new\s+WaitForSeconds(?:Realtime)?\s*\(\s*[0-9][0-9.]*f?\s*\)|\bThread\.Sleep\s*\(\s*[0-9]+\s*\)|\bTask\.Delay\s*\(\s*[0-9]+\s*\)'
    $lineIndex = 0
    foreach ($line in $content) {
      $lineIndex++
      if ($line -match 'UNH-SUPPRESS') { continue }
      $scrubbedLine = $scrubbedContent[$lineIndex - 1]
      $waitMatch = [regex]::Match($scrubbedLine, $waitRegex)
      if ($waitMatch.Success) {
        if ($isRuntimeTagsTest -and $waitMatch.Value -match 'WaitForSeconds') { continue }
        $advisories += (@{
          Path=$rel; Line=$lineIndex; Message="UNH010: real-time wait '$($waitMatch.Value.Trim())' blocks the serial test clock; prefer frame-stepping/deterministic completion/injectable clock (advisory)"
        })
      }
    }
  }

  # UNH013: Tags runtime tests exercise effect duration, periodic, and
  # behavior-tick logic that must not depend on Unity's imprecise real-time wait
  # instructions. Use EffectHandler's deterministic test seams for handler time
  # math; suppress only when the test is explicitly about Unity lifecycle timing.
  if ($isRuntimeTagsTest -and -not $perfCategory) {
    $tagsWaitAliases = @()
    foreach ($aliasMatch in $tagsWaitAliasPattern.Matches($scrubbedText)) {
      $tagsWaitAliases += [regex]::Escape($aliasMatch.Groups['alias'].Value)
    }
    foreach ($aliasMatch in $tagsUnityEngineAliasPattern.Matches($scrubbedText)) {
      $tagsWaitAliases += (
        [regex]::Escape($aliasMatch.Groups['alias'].Value) +
        '\s*(?:\.|::)\s*WaitForSeconds(?:Realtime)?'
      )
    }
    $tagsWaitPatterns = New-Object System.Collections.Generic.List[regex]
    $tagsWaitPatterns.Add($tagsWaitInstructionPattern)
    if ($tagsWaitAliases.Count -gt 0) {
      $tagsWaitPatterns.Add([regex]('\bnew\s+(?:' + ($tagsWaitAliases -join '|') + ')\s*\('))
    }

    $reportedTagsWaitMatches = @{}
    foreach ($tagsWaitPattern in $tagsWaitPatterns) {
      foreach ($waitMatch in $tagsWaitPattern.Matches($scrubbedText)) {
        $lineIndex = Get-LineNumberAtIndex -Text $scrubbedText -Index $waitMatch.Index
        $endLineIndex = Get-LineNumberAtIndex -Text $scrubbedText -Index ($waitMatch.Index + [Math]::Max($waitMatch.Length - 1, 0))
        $matchKey = "$($waitMatch.Index):$($waitMatch.Length)"
        if ($reportedTagsWaitMatches.ContainsKey($matchKey)) { continue }
        $reportedTagsWaitMatches[$matchKey] = $true
        if (
          Test-CodeSpecificSuppressionInLineRange `
            -Lines $content `
            -CommentMaskedLines $commentMaskedContent `
            -StartLine $lineIndex `
            -EndLine $endLineIndex `
            -Code 'UNH013'
        ) {
          continue
        }
        $violations += (@{
          Path=$rel; Line=$lineIndex; Message='UNH013: Tests/Runtime/Tags tests must not use WaitForSeconds/WaitForSecondsRealtime; prefer deterministic handler clock seams or add // UNH-SUPPRESS UNH013 with justification'
        })
      }
    }
  }

  # UNH011: editor-only references in PLAYER-compiled test code must be guarded by
  # `#if UNITY_EDITOR`. Assemblies without an editor-only asmdef includePlatforms list
  # compile into the standalone player; the editor-only assemblies
  # (UnityEditor.*, WallstopStudios.UnityHelpers.Editor) are stripped there,
  # so any unguarded reference is a CS0234 that aborts the WHOLE standalone leg before a
  # single test runs (no results.xml). This catches that class in <1s without a player
  # build. The standalone leg remains the ultimate backstop.
  #   A line is "editor-guarded" when enclosed by an `#if`/`#elif` whose condition
  # mentions UNITY_EDITOR (positively), or by the `#else` of an `#if !UNITY_EDITOR`.
  # Directive + token detection both run on the comment/string-SCRUBBED view, so a
  # `// uses UnityEditor` comment or an `InternalsVisibleTo("…Editor")` string literal
  # (both legal in player code) cannot trip the rule.
  if ((-not (Test-EditorOnlyAssemblyDefinition $file $rel)) -and ($text -notmatch 'UNH-SUPPRESS.*UNH011')) {
    $editorStack = New-Object System.Collections.Generic.List[object]
    $lineIndex = 0
    foreach ($line in $content) {
      $lineIndex++
      $sl = $scrubbedContent[$lineIndex - 1]
      $t = $sl.Trim()
      if ($t -match '^#\s*if\s+(.+)$' -or $t -match '^#\s*elif\s+(.+)$') {
        $cond = $Matches[1]
        $negated = ($cond -cmatch '!\s*UNITY_EDITOR')
        $frame = @{ Active = (($cond -cmatch 'UNITY_EDITOR') -and -not $negated); Negated = $negated }
        if ($t -match '^#\s*elif' -and $editorStack.Count -gt 0) {
          $editorStack[$editorStack.Count - 1] = $frame
        } else {
          $editorStack.Add($frame) | Out-Null
        }
        continue
      }
      if ($t -match '^#\s*else\b') {
        if ($editorStack.Count -gt 0) {
          $editorStack[$editorStack.Count - 1] = @{ Active = $editorStack[$editorStack.Count - 1].Negated; Negated = $false }
        }
        continue
      }
      if ($t -match '^#\s*endif\b') {
        if ($editorStack.Count -gt 0) { $editorStack.RemoveAt($editorStack.Count - 1) }
        continue
      }
      $guarded = $false
      foreach ($frame in $editorStack) { if ($frame.Active) { $guarded = $true; break } }
      if ($guarded) { continue }
      if ($line -match 'UNH-SUPPRESS') { continue }
      if ($sl -cmatch '\bUnityEditor' -or $sl -cmatch 'WallstopStudios\.UnityHelpers\.Editor\b') {
        $violations += (@{
          Path=$rel; Line=$lineIndex; Message='UNH011: editor-only reference in player-compiled test code must be inside #if UNITY_EDITOR (else CS0234 aborts the standalone leg)'
        })
      }
    }
  }

  # UNH012: a `[UnityTest]` PlayMode coroutine must never `yield return` a
  # WaitForEndOfFrame. Under `-batchmode -nographics` (the headless CI legs)
  # there is no end-of-frame callback, so the yield NEVER resumes: the test
  # hangs until the run is force-killed and Unity emits a misleading total=0
  # results.xml that aborts the whole PlayMode leg. Two such tests already
  # broke CI; this lint is the <1s pre-Unity guard so it can't recur.
  #   Matched on the SCRUBBED line so a `WaitForEndOfFrame` inside a string or
  # comment can't trip the rule. Two alternations cover the realistic forms:
  #   (a) `yield\s+return ... WaitForEndOfFrame` -- a same-line yield of a field
  #       or property, e.g. `yield return Buffers.WaitForEndOfFrame;`.
  #   (b) `new WaitForEndOfFrame(` anywhere -- constructing one in a test has no
  #       purpose but to yield it, and this catches the `new` even when csharpier
  #       wraps the statement across lines (`yield return\n new WaitForEndOfFrame();`)
  #       or it is hoisted to a local (`var w = new WaitForEndOfFrame(); yield return w;`).
  # A BARE field reference without `yield return`/`new` (e.g.
  # `Assert.NotNull(Buffers.WaitForEndOfFrame)` in Tests/Runtime/Utils/BuffersTests.cs,
  # which legitimately exercises the singleton field) is intentionally NOT matched.
  # `new WaitForEndOfFrameXyz(` is not matched (word/`(` boundary). The production
  # helper is batchmode-safe, so `yield return null` is the drop-in replacement.
  $yieldWaitForEndOfFramePattern = [regex]'(?:yield\s+return\b[^;]*\bWaitForEndOfFrame\b)|(?:\bnew\s+WaitForEndOfFrame\s*\()'
  $lineIndex = 0
  foreach ($line in $content) {
    $lineIndex++
    if ($line -match 'UNH-SUPPRESS') { continue }
    $scrubbedLine = $scrubbedContent[$lineIndex - 1]
    if ($yieldWaitForEndOfFramePattern.IsMatch($scrubbedLine)) {
      $violations += (@{
        Path=$rel; Line=$lineIndex; Message="UNH012: [UnityTest] must not 'yield return' WaitForEndOfFrame; it never resumes under -batchmode -nographics and aborts the PlayMode run (total=0 results.xml). Use 'yield return null' (the production helper is batchmode-safe)."
      })
    }
  }

  # UNH007: an enormous literal loop bound in a non-perf test belongs in a
  # Performance/Stress fixture (excluded from the fast suite) or should be
  # reduced. Const/field bounds (e.g. `< SampleCount`) are intentionally NOT
  # matched — only raw literals.
  if (-not $perfCategory) {
    $lineIndex = 0
    foreach ($line in $content) {
      $lineIndex++
      if ($line -match 'UNH-SUPPRESS') { continue }
      $scrubbedLine = $scrubbedContent[$lineIndex - 1]
      $loopMatch = [regex]::Match($scrubbedLine, '\bfor\s*\([^;]*;[^;]*<\s*=?\s*([0-9][0-9_]{2,})')
      if ($loopMatch.Success) {
        $boundText = $loopMatch.Groups[1].Value -replace '_', ''
        [long]$bound = 0
        if ([long]::TryParse($boundText, [ref]$bound) -and $bound -ge 50000) {
          $violations += (@{
            Path=$rel; Line=$lineIndex; Message="UNH007: loop of $bound iterations in a non-perf test; tag the fixture [Category(`"Stress`")]/[Category(`"Performance`")], reduce the count, or add // UNH-SUPPRESS"
          })
        }
      }
    }
  }
}

if ($FixNullChecks -and $violations.Count -eq 0) {
  exit 0
}

if ($advisories.Count -gt 0) {
  Write-Host "Test performance advisories (non-blocking): $($advisories.Count)" -ForegroundColor DarkYellow
  foreach ($a in $advisories) {
    Write-Host ("  {0}:{1}: {2}" -f $a.Path, $a.Line, $a.Message) -ForegroundColor DarkYellow
  }
}

if ($violations.Count -gt 0) {
  Write-Host "Test lifecycle lint failed:" -ForegroundColor Red
  foreach ($v in $violations) {
    Write-Host ("{0}:{1}: {2}" -f $v.Path, $v.Line, $v.Message) -ForegroundColor Yellow
  }
  exit 1
} else {
  Write-Info "No issues found in test code."
  exit 0
}
