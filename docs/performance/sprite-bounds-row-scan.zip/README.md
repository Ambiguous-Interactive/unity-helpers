# Sprite bounds row-scan capture

Unity 6000.6.7f1, Windows x64 Editor Mono, release code optimization.
Three fresh-process baseline/candidate pairs; six workloads per process,
64 warm calls, >=20 ms calibrated batches and 21 retained timing rounds.
Each process passed six independent shape controls and exited zero with
both output streams complete. The capture binds the bounds source, loaded
method IL and module identity, and the produced runtime assembly hash.

To replay, use a disposable checkout containing the recorded timing fixture.
Replace Runtime/Utils/SpriteArtBounds.cs with either source snapshot.
Run scripts/unity/run-ci-tests.ps1 with PlayMode, the Runtime test assembly,
filter WallstopStudios.UnityHelpers.Tests.Utils.SpriteArtBoundsTimingTests,
and category Performance in a new owned project. Capture unity.log and XML.
Alternate the arms in fresh processes. Require six BOUNDS-ROWS and six
BOUNDS-IDENTITY records, six passing cases, raw process exit zero and both
stream ends. Preserve every sample; compare shapes within one backend.

The raw values are nanoseconds per call. Input textures are 256 by 256.
Pattern 0 is opaque, 1 is a single visible column, 2 is transparent.
The sprite path includes its pixel read; the mask path borrows existing data.
Earlier captures lost NUnit Progress output and are excluded from timings.
This does not qualify IL2CPP or a universal speed improvement.
