$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
@{pid=$PID;startUtc=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content(Join-Path $PSScriptRoot 'windows-tooling-final-identity.json')
Push-Location $repository
$code=1
try {
 $env:UV_PROJECT_ENVIRONMENT=Join-Path ([IO.Path]::GetTempPath()) 'uh-python-20261113b-buffers'
 $env:PYTHONUTF8='0';$env:PYTHONIOENCODING='cp1252'
 $sources=@('scripts/run_node_bin.py','scripts/tests/test_node_bin.py','scripts/run-node-bin.js','scripts/tests/fixtures/node-bin-original.json','scripts/python~/pyproject.toml','scripts/python~/uv.lock','scripts/cli_encoding.py','scripts/typecheck_controls.py','scripts/tests/test_typecheck_controls.py','scripts/typecheck-controls.js','scripts/tests/test-typecheck-controls.js','scripts/tests/fixtures/typecheck-controls-original.json','scripts/run-prettier.js','scripts/typecheck-control-sources/analyzers.cs.template','scripts/typecheck-control-sources/compiler.cs.template','scripts/typecheck-control-sources/excluded-loops.cs.template')
 $before=@{};foreach($s in $sources){$before[$s]=(Get-FileHash $s).Hash}
 & uv run --quiet --project scripts/python~ --locked --python 3.11 python -c 'import sys,locale;print(sys.version);print(locale.getencoding());print(sys.flags.utf8_mode)' *> (Join-Path $PSScriptRoot 'windows-tooling-final-environment.log')
 if($LASTEXITCODE -ne 0){throw 'Python environment inspection failed'}
 & uv run --quiet --project scripts/python~ --locked --python 3.11 pytest scripts/tests/test_node_bin.py scripts/tests/test_check_registries.py scripts/tests/test_typecheck_controls.py -q *> (Join-Path $PSScriptRoot 'windows-tooling-final-tests.log')
 if($LASTEXITCODE -ne 0){throw 'Windows launcher controls failed'}
 & uv run --quiet --project scripts/python~ --locked --python 3.11 python scripts/python~/check.py *> (Join-Path $PSScriptRoot 'windows-tooling-final-strict.log')
 if($LASTEXITCODE -ne 0){throw 'Windows strict scope failed'}
 & node scripts/tests/test-lint-markdown.mjs *> (Join-Path $PSScriptRoot 'windows-tooling-final-markdown.log')
 if($LASTEXITCODE -ne 0){throw 'Windows Markdown runner controls failed'}
 & node scripts/tests/test-read-stdin-sync.js *> (Join-Path $PSScriptRoot 'windows-tooling-final-stdin.log')
 if($LASTEXITCODE -ne 0){throw 'Windows stdin controls failed'}
 $after=@{};foreach($s in $sources){$after[$s]=(Get-FileHash $s).Hash;if($after[$s] -ne $before[$s]){throw 'Sources changed'}}
 $code=0
} catch { $_|Out-String|Set-Content(Join-Path $PSScriptRoot 'windows-tooling-final-controller.log') }
finally { Pop-Location;@{exitCode=$code;before=$before;after=$after;completedUtc=[DateTime]::UtcNow}|ConvertTo-Json -Depth 6|Set-Content(Join-Path $PSScriptRoot 'windows-tooling-final-result.json') }
exit $code
